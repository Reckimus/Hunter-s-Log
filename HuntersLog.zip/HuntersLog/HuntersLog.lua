-- HuntersLog
-- A persistent record of your hunter's career: pets, kills, distances, records,
-- trophies, hunting grounds, bestiary entries, traps, achievements, and pet personality.

HuntersLogDB = HuntersLogDB or {}

-- ============================================================
-- DATABASE
-- ============================================================

local function EnsureDB()
    if type(HuntersLogDB) ~= "table" then HuntersLogDB = {} end
    if type(HuntersLogDB.minimap) ~= "table" then HuntersLogDB.minimap = { angle = 220 } end
    if type(HuntersLogDB.pets) ~= "table" then HuntersLogDB.pets = {} end
    if type(HuntersLogDB.records) ~= "table" then HuntersLogDB.records = {} end
    if type(HuntersLogDB.totals) ~= "table" then HuntersLogDB.totals = {} end
    if type(HuntersLogDB.journal) ~= "table" then HuntersLogDB.journal = {} end
    if type(HuntersLogDB.zones) ~= "table" then HuntersLogDB.zones = {} end
    if type(HuntersLogDB.bestiary) ~= "table" then HuntersLogDB.bestiary = {} end
    if type(HuntersLogDB.traps) ~= "table" then HuntersLogDB.traps = {} end
    if type(HuntersLogDB.achievements) ~= "table" then HuntersLogDB.achievements = {} end
    if type(HuntersLogDB.trophies) ~= "table" then HuntersLogDB.trophies = {} end
    if type(HuntersLogDB.settings) ~= "table" then
        HuntersLogDB.settings = { emoteEnabled = true }
    end
    if HuntersLogDB.settings.emoteEnabled == nil then HuntersLogDB.settings.emoteEnabled = true end
end
EnsureDB()

local _, playerClass = UnitClass("player")
local IS_HUNTER = (playerClass == "HUNTER")
local PLAYER_NAME = nil

local PET_EMOTE_COOLDOWN = 180       -- 3 minutes between flavor emotes
local PET_AMBIENT_CHECK_INTERVAL = 10
local PET_AMBIENT_CHANCE = 0.35
local PET_DAMAGE_KILL_WINDOW = 12
local KILL_TRACK_TTL = 60
local lastPetEmote = 0

local MaybeEmote -- forward declaration

-- ============================================================
-- HELPERS
-- ============================================================

local function SafeText(v, fallback)
    if v == nil or v == "" then return fallback or "?" end
    return tostring(v)
end

local function FormatHours(secs)
    if not secs or secs <= 0 then return "0m" end
    local h = math.floor(secs / 3600)
    local m = math.floor((secs % 3600) / 60)
    if h > 0 then return string.format("%dh %dm", h, m) end
    return string.format("%dm", m)
end

local function FormatNumber(n)
    if not n or n == 0 then return "0" end
    if n >= 1000000 then return string.format("%.2fM", n / 1000000) end
    if n >= 10000 then return string.format("%.1fK", n / 1000) end
    return tostring(math.floor(n))
end

local function UnitsToYards(units)
    return (units or 0) * 3000
end

local function UnitsToMiles(units)
    return UnitsToYards(units) / 5280
end

local function FormatDistance(units)
    if not units or units <= 0 then return "0 yd" end
    local yards = UnitsToYards(units)
    if yards >= 5280 then return string.format("%.2f mi", yards / 5280) end
    if yards >= 1000 then return string.format("%.0f yd", yards) end
    return string.format("%d yd", math.floor(yards))
end

local function FormatTimestamp(ts)
    if not ts or ts == 0 then return "?" end
    return date("%Y-%m-%d", ts)
end

local function AddJournalEntry(kind, text)
    EnsureDB()
    table.insert(HuntersLogDB.journal, 1, { when = time(), kind = kind, text = text })
    while #HuntersLogDB.journal > 700 do table.remove(HuntersLogDB.journal) end
end

local function PrintHL(msg, color)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage((color or "|cffff8800") .. "Hunter's Log:|r " .. msg)
    else
        print("Hunter's Log: " .. msg)
    end
end

local function GetLocationKind()
    local _, instType = IsInInstance()
    if instType == "party" or instType == "raid" then return "dungeon" end
    if IsResting and IsResting() then return "town" end
    return "world"
end

local function GetZoneName()
    return GetRealZoneText() or GetZoneText() or "Unknown"
end

local function GetPetHealthPct()
    if not UnitExists("pet") then return nil end
    local hp = UnitHealth("pet") or 0
    local maxHp = UnitHealthMax("pet") or 0
    if maxHp <= 0 then return nil end
    return hp / maxHp
end

local function IsPetAlive()
    return UnitExists("pet") and not UnitIsDead("pet")
end

local function HasCombatFlag(flags, flag)
    if not flags or not flag or not bit or not bit.band then return false end
    return bit.band(flags, flag) ~= 0
end

local function IsMyPlayerCombatSource(srcGUID, srcName, srcFlags)
    local playerGUID = UnitGUID("player")
    if playerGUID and srcGUID == playerGUID then return true end

    -- Some private servers/client builds can report odd GUIDs in the combat log.
    -- Fall back to the source name plus the "mine/player" combat-log flags.
    local playerName = UnitName("player")
    if playerName and srcName == playerName then
        if HasCombatFlag(srcFlags, COMBATLOG_OBJECT_AFFILIATION_MINE) or
           HasCombatFlag(srcFlags, COMBATLOG_OBJECT_TYPE_PLAYER) then
            return true
        end
    end
    return false
end

local function IsMyPetCombatSource(srcGUID, srcName, srcFlags)
    local petGUID = UnitGUID("pet")
    if petGUID and srcGUID == petGUID then return true end

    local petName = UnitExists("pet") and UnitName("pet") or nil
    if petName and srcName == petName then
        -- Name match while we have an active pet is a very useful fallback on
        -- 3.3.5 private servers where pet GUIDs are not always stable.
        return true
    end

    -- Official combat-log flags path: source is a pet controlled by/affiliated with us.
    if HasCombatFlag(srcFlags, COMBATLOG_OBJECT_TYPE_PET) and
       (HasCombatFlag(srcFlags, COMBATLOG_OBJECT_AFFILIATION_MINE) or
        HasCombatFlag(srcFlags, COMBATLOG_OBJECT_CONTROL_PLAYER)) then
        return true
    end
    return false
end

-- ============================================================
-- ENSURE RECORDS
-- ============================================================

local function EnsurePetRecord(name)
    EnsureDB()
    if not name or name == "" then name = "Unknown Pet" end
    local p = HuntersLogDB.pets[name]
    if type(p) ~= "table" then
        p = {
            firstTamed = time(), totalSeconds = 0,
            kills = 0, deaths = 0, totalDamage = 0, fights = 0,
            bestDPS = 0, bestCrit = 0,
        }
        HuntersLogDB.pets[name] = p
    end
    p.firstTamed = p.firstTamed or time()
    p.totalSeconds = p.totalSeconds or 0
    p.kills = p.kills or 0
    p.deaths = p.deaths or 0
    p.totalDamage = p.totalDamage or 0
    p.fights = p.fights or 0
    p.bestDPS = p.bestDPS or 0
    p.bestCrit = p.bestCrit or 0
    p.dungeonSeconds = p.dungeonSeconds or 0
    p.townSeconds = p.townSeconds or 0
    p.worldSeconds = p.worldSeconds or 0
    p.distance = p.distance or 0
    p.survivalKills = p.survivalKills or 0
    p.bestSurvivalStreak = p.bestSurvivalStreak or 0
    p.lowHealthKills = p.lowHealthKills or 0
    p.lastKillAt = p.lastKillAt or 0
    p.lastDeathAt = p.lastDeathAt or 0
    p.lastZone = p.lastZone or ""
    if type(p.zones) ~= "table" then p.zones = {} end
    if type(p.loyaltyMilestones) ~= "table" then p.loyaltyMilestones = {} end
    return p
end

local function EnsureTotals()
    EnsureDB()
    local t = HuntersLogDB.totals
    t.arrowsFired = t.arrowsFired or 0
    t.bulletsFired = t.bulletsFired or 0
    t.thrownFired = t.thrownFired or 0
    t.mountedDistance = t.mountedDistance or 0
    t.footDistance = t.footDistance or 0
    t.petKills = t.petKills or 0
    t.playerKills = t.playerKills or 0
    t.petDeaths = t.petDeaths or 0
    t.playerDeaths = t.playerDeaths or 0
    t.totalDamageDealt = t.totalDamageDealt or 0
    t.totalPetDamage = t.totalPetDamage or 0
    t.sessionsPlayed = t.sessionsPlayed or 0
    t.rangedHits = t.rangedHits or 0
    t.rangedCrits = t.rangedCrits or 0
    t.rangedMisses = t.rangedMisses or 0
    t.closeCallKills = t.closeCallKills or 0
    t.petLastStandKills = t.petLastStandKills or 0
    t.loneWolfKills = t.loneWolfKills or 0
    t.eliteKills = t.eliteKills or 0
    t.rareKills = t.rareKills or 0
    t.trapKills = t.trapKills or 0
    t.trophyKills = t.trophyKills or 0
    return t
end

local function EnsureRecords()
    EnsureDB()
    local r = HuntersLogDB.records
    r.highestCrit  = r.highestCrit  or { amount = 0 }
    r.highestDPS   = r.highestDPS   or { amount = 0 }
    r.fastestKill  = r.fastestKill  or { seconds = 0 }
    r.longestFight = r.longestFight or { seconds = 0 }
    r.bestPetCrit  = r.bestPetCrit  or { amount = 0 }
    return r
end

local function EnsureZoneRecord(zone)
    EnsureDB()
    zone = SafeText(zone, "Unknown")
    local z = HuntersLogDB.zones[zone]
    if type(z) ~= "table" then
        z = { firstVisit = time(), kills = 0, playerKills = 0, petKills = 0, deaths = 0, petDeaths = 0,
              distance = 0, timeSeconds = 0, biggestCrit = 0, biggestCritTarget = nil, pets = {} }
        HuntersLogDB.zones[zone] = z
    end
    z.firstVisit = z.firstVisit or time()
    z.kills = z.kills or 0
    z.playerKills = z.playerKills or 0
    z.petKills = z.petKills or 0
    z.deaths = z.deaths or 0
    z.petDeaths = z.petDeaths or 0
    z.distance = z.distance or 0
    z.timeSeconds = z.timeSeconds or 0
    z.biggestCrit = z.biggestCrit or 0
    if type(z.pets) ~= "table" then z.pets = {} end
    return z
end

local function EnsureBestiaryRecord(name)
    EnsureDB()
    name = SafeText(name, "Unknown Beast")
    local b = HuntersLogDB.bestiary[name]
    if type(b) ~= "table" then
        b = { firstSeen = time(), firstSeenZone = GetZoneName(), kills = 0, petKills = 0, playerKills = 0 }
        HuntersLogDB.bestiary[name] = b
    end
    b.firstSeen = b.firstSeen or time()
    b.firstSeenZone = b.firstSeenZone or GetZoneName()
    b.lastSeen = b.lastSeen or time()
    b.lastSeenZone = b.lastSeenZone or GetZoneName()
    b.kills = b.kills or 0
    b.petKills = b.petKills or 0
    b.playerKills = b.playerKills or 0
    return b
end

local function EnsureTrapRecord(name)
    EnsureDB()
    name = SafeText(name, "Unknown Trap")
    local tr = HuntersLogDB.traps[name]
    if type(tr) ~= "table" then
        tr = { casts = 0, affected = 0, kills = 0, damage = 0, firstUsed = time(), lastUsed = 0 }
        HuntersLogDB.traps[name] = tr
    end
    tr.casts = tr.casts or 0
    tr.affected = tr.affected or 0
    tr.kills = tr.kills or 0
    tr.damage = tr.damage or 0
    tr.firstUsed = tr.firstUsed or time()
    tr.lastUsed = tr.lastUsed or 0
    return tr
end

-- ============================================================
-- PET BOND, PERSONALITY, MOOD
-- ============================================================

local function GetPetBondInfo(p)
    if type(p) ~= "table" then return "Stranger", 0, 0 end
    local hours = (p.totalSeconds or 0) / 3600
    local dungeonHours = (p.dungeonSeconds or 0) / 3600
    local score = math.floor(hours * 2 + (p.kills or 0) / 8 + dungeonHours * 3 + (p.bestSurvivalStreak or 0) / 20 - (p.deaths or 0) * 2)
    if score < 0 then score = 0 end
    if score >= 300 then return "Legendary Partner", 5, score end
    if score >= 140 then return "Bloodbound", 4, score end
    if score >= 60 then return "Trusted", 3, score end
    if score >= 15 then return "Companion", 2, score end
    return "Stranger", 1, score
end

local function GetPetPersonality(name, p)
    if type(p) ~= "table" then return "Unknown" end
    if (p.kills or 0) >= 100 and (p.kills or 0) >= ((p.deaths or 0) + 1) * 20 then return "Bloodthirsty" end
    if (p.bestSurvivalStreak or 0) >= 100 then return "Survivor" end
    if (p.dungeonSeconds or 0) > 3600 and (p.dungeonSeconds or 0) > (p.worldSeconds or 0) and (p.dungeonSeconds or 0) > (p.townSeconds or 0) then return "Dungeon Beast" end
    if (p.townSeconds or 0) > 3600 and (p.townSeconds or 0) > (p.worldSeconds or 0) and (p.townSeconds or 0) > (p.dungeonSeconds or 0) then return "Town Lounger" end
    if UnitsToMiles(p.distance or 0) >= 10 then return "Wanderer" end
    if (p.deaths or 0) >= 10 then return "Loyal Guardian" end
    return "Steady Companion"
end

local function GetPetMood(name, p)
    if not activePet or not name or activePet.name ~= name then return "Resting" end
    if not UnitExists("pet") then return "Away" end
    if UnitIsDead("pet") then return "Fallen" end
    local pct = GetPetHealthPct()
    if pct and pct <= 0.30 then return "Wounded" end
    local now = time()
    if (p.lastDeathAt or 0) > 0 and now - p.lastDeathAt < 900 then return "Shaken" end
    if (p.lastKillAt or 0) > 0 and now - p.lastKillAt < 180 then return "Proud" end
    local loc = GetLocationKind()
    if loc == "dungeon" then return "Alert" end
    if loc == "town" then return "Resting" end
    if (p.totalSeconds or 0) > 3600 and (p.deaths or 0) == 0 then return "Content" end
    return "Ready"
end

local PET_LOYALTY_MILESTONES = {
    { key = "bond_1h",    seconds = 1 * 3600,     title = "Trusted Companion", text = "%s has spent an hour at your side. The bond is beginning to feel real." },
    { key = "bond_10h",   seconds = 10 * 3600,    title = "Battle-Bound",      text = "%s has fought beside you for ten hours. It watches your movements before you even give a command." },
    { key = "bond_25h",   seconds = 25 * 3600,    title = "Loyal Friend",      text = "%s has become more than a pet. Wherever you go, it chooses to follow." },
    { key = "bond_100h",  seconds = 100 * 3600,   title = "Old Hunting Partner", text = "%s has shared one hundred hours of roads, dungeons, and battle with you." },
    { key = "bond_500h",  seconds = 500 * 3600,   title = "Legendary Bond",    text = "%s is part of your legend now. Bards should know this beast's name." },
}

local function CheckPetLoyaltyMilestones(name, petRecord)
    if not name or type(petRecord) ~= "table" then return end
    if type(petRecord.loyaltyMilestones) ~= "table" then petRecord.loyaltyMilestones = {} end
    for _, m in ipairs(PET_LOYALTY_MILESTONES) do
        if not petRecord.loyaltyMilestones[m.key] and (petRecord.totalSeconds or 0) >= m.seconds then
            petRecord.loyaltyMilestones[m.key] = time()
            AddJournalEntry("bond", string.format("%s: " .. m.text, m.title, name))
            if MaybeEmote then MaybeEmote("loyalty") end
        end
    end
end

-- ============================================================
-- ACHIEVEMENTS
-- ============================================================

local ACHIEVEMENTS = {
    { key = "first_blood",       name = "First Blood",        desc = "Your pet earns its first killing blow." },
    { key = "pack_leader",       name = "Pack Leader",        desc = "Spend 10 hours with one pet." },
    { key = "beastmaster",       name = "Beastmaster",        desc = "Reach 100 pet kills." },
    { key = "long_hunt",         name = "The Long Hunt",      desc = "Travel 10 miles on foot or mount." },
    { key = "arrowstorm",        name = "Arrowstorm",         desc = "Fire 5,000 arrows, bullets, or thrown weapons." },
    { key = "close_call",        name = "Close Call",         desc = "Win a fight while your pet is under 10% health." },
    { key = "dungeon_companion", name = "Dungeon Companion",  desc = "Spend 5 hours in dungeons with one pet." },
    { key = "lone_wolf",         name = "Lone Wolf",          desc = "Kill 25 enemies without a pet active." },
    { key = "old_friend",        name = "Old Friend",         desc = "Keep a pet in your log for 30 days." },
    { key = "last_stand",        name = "Last Stand",         desc = "Your pet gets a killing blow while under 20% health." },
    { key = "trap_apprentice",   name = "Trap Apprentice",    desc = "Place 25 traps." },
    { key = "trap_master",       name = "Trap Master",        desc = "Place 250 traps." },
    { key = "big_game",          name = "Big Game Hunter",    desc = "Defeat an elite, rare, or boss enemy." },
    { key = "wild_chronicle",    name = "Wild Chronicle",     desc = "Record 25 creatures in your bestiary." },
    { key = "trophy_hunter",     name = "Trophy Hunter",      desc = "Record 10 trophy kills." },
}

local function IsAchievementUnlocked(key)
    EnsureDB()
    return type(HuntersLogDB.achievements[key]) == "table"
end

local function UnlockAchievement(key)
    if IsAchievementUnlocked(key) then return false end
    local ach
    for _, a in ipairs(ACHIEVEMENTS) do if a.key == key then ach = a; break end end
    if not ach then return false end
    HuntersLogDB.achievements[key] = { when = time(), name = ach.name }
    AddJournalEntry("achievement", "Achievement earned: " .. ach.name .. " - " .. ach.desc)
    PrintHL("|cffffff00Achievement earned:|r " .. ach.name)
    return true
end

local function CountTableEntries(tbl)
    local n = 0
    if type(tbl) == "table" then for _ in pairs(tbl) do n = n + 1 end end
    return n
end

local function CountBestiaryEntries()
    EnsureDB()
    local n = 0
    for _, b in pairs(HuntersLogDB.bestiary) do
        if type(b) == "table" and ((b.kills or 0) > 0 or b.tamed or b.beastLore) then
            n = n + 1
        end
    end
    return n
end

local function TotalTrapCasts()
    local total = 0
    EnsureDB()
    for _, tr in pairs(HuntersLogDB.traps) do
        if type(tr) == "table" then total = total + (tr.casts or 0) end
    end
    return total
end

local function CheckAchievements()
    if not IS_HUNTER then return end
    local t = EnsureTotals()
    if t.petKills >= 1 then UnlockAchievement("first_blood") end
    if t.petKills >= 100 then UnlockAchievement("beastmaster") end
    if UnitsToMiles((t.footDistance or 0) + (t.mountedDistance or 0)) >= 10 then UnlockAchievement("long_hunt") end
    if ((t.arrowsFired or 0) + (t.bulletsFired or 0) + (t.thrownFired or 0)) >= 5000 then UnlockAchievement("arrowstorm") end
    if (t.closeCallKills or 0) >= 1 then UnlockAchievement("close_call") end
    if (t.petLastStandKills or 0) >= 1 then UnlockAchievement("last_stand") end
    if (t.loneWolfKills or 0) >= 25 then UnlockAchievement("lone_wolf") end
    if (t.eliteKills or 0) + (t.rareKills or 0) >= 1 then UnlockAchievement("big_game") end
    if CountBestiaryEntries() >= 25 then UnlockAchievement("wild_chronicle") end
    if (t.trophyKills or 0) >= 10 then UnlockAchievement("trophy_hunter") end
    local casts = TotalTrapCasts()
    if casts >= 25 then UnlockAchievement("trap_apprentice") end
    if casts >= 250 then UnlockAchievement("trap_master") end

    local now = time()
    for _, p in pairs(HuntersLogDB.pets) do
        if type(p) == "table" then
            if (p.totalSeconds or 0) >= 10 * 3600 then UnlockAchievement("pack_leader") end
            if (p.dungeonSeconds or 0) >= 5 * 3600 then UnlockAchievement("dungeon_companion") end
            if (p.firstTamed or now) <= now - (30 * 24 * 3600) then UnlockAchievement("old_friend") end
        end
    end
end

-- ============================================================
-- PET TIME AND DISTANCE
-- ============================================================

local activePet = nil  -- { name, startTime }
local lastPetContext = nil
local lastZoneTick = nil

local function BankPetTime()
    if not activePet then return end
    EnsureDB()
    local now = GetTime()
    local elapsed = now - (activePet.startTime or now)
    if elapsed > 0 then
        local p = EnsurePetRecord(activePet.name)
        p.totalSeconds = p.totalSeconds + elapsed
        local loc = lastPetContext or GetLocationKind()
        if loc == "dungeon" then p.dungeonSeconds = (p.dungeonSeconds or 0) + elapsed
        elseif loc == "town" then p.townSeconds = (p.townSeconds or 0) + elapsed
        else p.worldSeconds = (p.worldSeconds or 0) + elapsed end
        p.lastZone = GetZoneName()
        CheckPetLoyaltyMilestones(activePet.name, p)
    end
    activePet.startTime = now
    lastPetContext = GetLocationKind()
end

local function StartPet(name)
    if not name or name == "" then return end
    activePet = { name = name, startTime = GetTime() }
    lastPetContext = GetLocationKind()
    EnsureDB()
    if type(HuntersLogDB.pets[name]) ~= "table" then
        EnsurePetRecord(name)
        AddJournalEntry("tame", "Met " .. name .. " in " .. GetZoneName())
        local b = EnsureBestiaryRecord(name)
        b.tamed = true
        b.tamedAt = b.tamedAt or time()
        b.tamedZone = b.tamedZone or GetZoneName()
    end
end

local function StopPet()
    BankPetTime()
    activePet = nil
    lastPetContext = nil
end

local function CheckHunterPet()
    if not IS_HUNTER then return end
    if UnitExists("pet") then
        local name = UnitName("pet")
        if name and name ~= "Unknown" then
            if not activePet or activePet.name ~= name then
                StopPet()
                StartPet(name)
            end
            return
        end
    end
    if activePet then StopPet() end
end

local lastPos = nil -- { x, y, zone }
local function UpdateDistance()
    if not IS_HUNTER then return end
    local _, instType = IsInInstance()
    if instType ~= "none" then lastPos = nil; return end
    if WorldMapFrame and WorldMapFrame:IsShown() then return end

    local x, y = GetPlayerMapPosition("player")
    if not x or not y or (x == 0 and y == 0) then lastPos = nil; return end

    local zone = GetZoneName()
    if not lastPos or lastPos.zone ~= zone then
        lastPos = { x = x, y = y, zone = zone }
        return
    end

    local dx = x - lastPos.x
    local dy = y - lastPos.y
    local d = math.sqrt(dx * dx + dy * dy)

    if d > 0.05 then
        lastPos = { x = x, y = y, zone = zone }
        return
    end

    if d > 0 then
        local t = EnsureTotals()
        if IsMounted() then t.mountedDistance = t.mountedDistance + d else t.footDistance = t.footDistance + d end
        local z = EnsureZoneRecord(zone)
        z.distance = (z.distance or 0) + d
        if activePet then
            local p = EnsurePetRecord(activePet.name)
            p.distance = (p.distance or 0) + d
            p.zones[zone] = (p.zones[zone] or 0) + d
        end
    end
    lastPos.x = x
    lastPos.y = y
end

local function UpdateZoneTime(elapsed)
    if not IS_HUNTER or not elapsed or elapsed <= 0 then return end
    local zone = GetZoneName()
    local z = EnsureZoneRecord(zone)
    z.timeSeconds = (z.timeSeconds or 0) + elapsed
end

-- ============================================================
-- TARGET INFO, BESTIARY, TROPHIES
-- ============================================================

local mobInfoByGUID = {}

local function CaptureUnitInfo(unit)
    if not UnitExists(unit) then return nil end
    local guid = UnitGUID(unit)
    local name = UnitName(unit)
    if not guid or not name then return nil end
    local info = mobInfoByGUID[guid] or {}
    info.name = name
    info.level = UnitLevel(unit)
    info.classification = UnitClassification(unit)
    info.creatureType = UnitCreatureType(unit)
    info.zone = GetZoneName()
    info.when = GetTime()
    if UnitIsPlayer(unit) then info.isPlayer = true end
    mobInfoByGUID[guid] = info

    if not info.isPlayer and name then
        local b = EnsureBestiaryRecord(name)
        b.lastSeen = time()
        b.lastSeenZone = info.zone
        b.level = info.level or b.level
        b.classification = info.classification or b.classification
        b.creatureType = info.creatureType or b.creatureType
        if info.creatureType == "Beast" then b.isBeast = true end
        if info.classification == "rare" or info.classification == "rareelite" then b.rare = true end
        if info.classification == "elite" or info.classification == "rareelite" or info.classification == "worldboss" then b.elite = true end
    end
    return info
end

local function GetMobInfo(guid, name)
    if guid and UnitGUID("target") == guid then return CaptureUnitInfo("target") end
    local info = guid and mobInfoByGUID[guid]
    if not info and name then info = { name = name, zone = GetZoneName() } end
    return info
end

local function RecordBestiarySeen(name, info)
    if not name then return end
    local b = EnsureBestiaryRecord(name)
    -- Do not count combat-log hits as "seen". The Bestiary now displays kills only,
    -- while this function simply keeps creature metadata fresh for lore/tame/trophy info.
    b.lastSeen = time()
    b.lastSeenZone = GetZoneName()
    if info then
        b.level = info.level or b.level
        b.classification = info.classification or b.classification
        b.creatureType = info.creatureType or b.creatureType
        if info.creatureType == "Beast" then b.isBeast = true end
        if info.classification == "rare" or info.classification == "rareelite" then b.rare = true end
        if info.classification == "elite" or info.classification == "rareelite" or info.classification == "worldboss" then b.elite = true end
    end
end

local function RecordBestiaryKill(name, who, info)
    if not name then return end
    local b = EnsureBestiaryRecord(name)
    b.kills = (b.kills or 0) + 1
    b.lastKilled = time()
    b.lastSeen = time()
    b.lastSeenZone = GetZoneName()
    if who == "pet" then b.petKills = (b.petKills or 0) + 1 else b.playerKills = (b.playerKills or 0) + 1 end
    if info then
        b.level = info.level or b.level
        b.classification = info.classification or b.classification
        b.creatureType = info.creatureType or b.creatureType
        if info.creatureType == "Beast" then b.isBeast = true end
        if info.classification == "rare" or info.classification == "rareelite" then b.rare = true end
        if info.classification == "elite" or info.classification == "rareelite" or info.classification == "worldboss" then b.elite = true end
    end
end

local function IsTrophyClassification(classification)
    return classification == "elite" or classification == "rare" or classification == "rareelite" or classification == "worldboss"
end

local function RecordTrophyKill(dstName, who, petName, info)
    if not dstName then return end
    local classification = info and info.classification
    if not IsTrophyClassification(classification) then return end

    local t = EnsureTotals()
    if classification == "rare" or classification == "rareelite" then t.rareKills = (t.rareKills or 0) + 1 end
    if classification == "elite" or classification == "rareelite" or classification == "worldboss" then t.eliteKills = (t.eliteKills or 0) + 1 end
    t.trophyKills = (t.trophyKills or 0) + 1

    local zone = GetZoneName()
    local text
    if who == "pet" and petName then
        text = string.format("Trophy kill: %s helped bring down %s in %s.", petName, dstName, zone)
    else
        text = string.format("Trophy kill: defeated %s in %s.", dstName, zone)
    end
    AddJournalEntry("trophy", text)
    table.insert(HuntersLogDB.trophies, 1, { when = time(), name = dstName, zone = zone, who = who, pet = petName, classification = classification })
    while #HuntersLogDB.trophies > 100 do table.remove(HuntersLogDB.trophies) end
end

-- ============================================================
-- TRAP TRACKING
-- ============================================================

local HUNTER_TRAPS = {
    ["Freezing Trap"] = true,
    ["Frost Trap"] = true,
    ["Explosive Trap"] = true,
    ["Immolation Trap"] = true,
    ["Snake Trap"] = true,
    ["Freezing Trap Effect"] = true,
    ["Frost Trap Aura"] = true,
}

local function NormalizeTrapName(spellName)
    if not spellName then return nil end
    if HUNTER_TRAPS[spellName] then
        if spellName == "Freezing Trap Effect" then return "Freezing Trap" end
        if spellName == "Frost Trap Aura" then return "Frost Trap" end
        return spellName
    end
    if string.find(spellName, "Trap") then return spellName end
    return nil
end

local function RecordTrapCast(spellName)
    local trap = NormalizeTrapName(spellName)
    if not trap then return end
    local tr = EnsureTrapRecord(trap)
    tr.casts = (tr.casts or 0) + 1
    tr.lastUsed = time()
    tr.lastZone = GetZoneName()
    AddJournalEntry("trap", "Set " .. trap .. " in " .. GetZoneName())
end

local function RecordTrapAffected(spellName)
    local trap = NormalizeTrapName(spellName)
    if not trap then return end
    local tr = EnsureTrapRecord(trap)
    tr.affected = (tr.affected or 0) + 1
end

local function RecordTrapDamage(spellName, amount)
    local trap = NormalizeTrapName(spellName)
    if not trap then return end
    local tr = EnsureTrapRecord(trap)
    tr.damage = (tr.damage or 0) + (amount or 0)
end

local function RecordTrapKill(spellName, dstName)
    local trap = NormalizeTrapName(spellName)
    if not trap then return end
    local tr = EnsureTrapRecord(trap)
    tr.kills = (tr.kills or 0) + 1
    EnsureTotals().trapKills = EnsureTotals().trapKills + 1
    AddJournalEntry("trapkill", trap .. " finished off " .. SafeText(dstName, "an enemy") .. " in " .. GetZoneName())
end

-- ============================================================
-- COMBAT TRACKING
-- ============================================================

local fight = {
    active = false,
    startTime = 0,
    playerDamage = 0,
    petDamage = 0,
    petName = nil,
    target = nil,
}

local function StartFight()
    if fight.active then return end
    fight.active = true
    fight.startTime = GetTime()
    fight.playerDamage = 0
    fight.petDamage = 0
    fight.petName = activePet and activePet.name or nil
    fight.target = nil
end

local function EndFight()
    if not fight.active then return end
    local elapsed = GetTime() - fight.startTime
    if elapsed > 0 then
        local r = EnsureRecords()
        local totalDmg = fight.playerDamage + fight.petDamage
        local dps = totalDmg / elapsed
        if dps > (r.highestDPS.amount or 0) then
            r.highestDPS = { amount = dps, fightTime = elapsed, target = fight.target, when = time() }
        end
        if elapsed > (r.longestFight.seconds or 0) and totalDmg > 0 then
            r.longestFight = { seconds = elapsed, target = fight.target, when = time() }
        end
        if fight.petName and fight.petDamage > 0 then
            local p = EnsurePetRecord(fight.petName)
            p.fights = (p.fights or 0) + 1
            p.totalDamage = (p.totalDamage or 0) + fight.petDamage
            local petDps = fight.petDamage / elapsed
            if petDps > (p.bestDPS or 0) then p.bestDPS = petDps end
        end
    end
    fight.active = false
end

local lastDamageByGUID = {}
local lastDamageByName = {}
local creditedKillGUIDs = {}

local PET_LAST_STAND_LINES = {
    "%s fell defending you in %s.",
    "%s gave everything in %s and would not back down.",
    "%s collapsed at your side in %s. A hunter remembers.",
    "%s's last growl faded into the noise of battle in %s.",
}

local function PruneKillTracking()
    local now = GetTime()
    for guid, rec in pairs(lastDamageByGUID) do
        if not rec or (now - (rec.when or 0)) > KILL_TRACK_TTL then lastDamageByGUID[guid] = nil end
    end
    for name, rec in pairs(lastDamageByName) do
        if not rec or (now - (rec.when or 0)) > KILL_TRACK_TTL then lastDamageByName[name] = nil end
    end
    for guid, when in pairs(creditedKillGUIDs) do
        if (now - (when or 0)) > KILL_TRACK_TTL then creditedKillGUIDs[guid] = nil end
    end
end

local function TrackLastDamage(dstGUID, dstName, owner, spellName, trapName)
    if not owner then return end
    local rec = {
        who = owner,
        petName = activePet and activePet.name or UnitName("pet"),
        dstName = dstName,
        spellName = spellName,
        trapName = trapName,
        when = GetTime(),
    }
    if dstGUID then lastDamageByGUID[dstGUID] = rec end
    if dstName then lastDamageByName[string.lower(dstName)] = rec end
end

local function GetRecentDamageRecord(dstGUID, dstName)
    local rec = dstGUID and lastDamageByGUID[dstGUID] or nil
    if not rec and dstName then rec = lastDamageByName[string.lower(dstName)] end
    if rec and (GetTime() - (rec.when or 0)) <= PET_DAMAGE_KILL_WINDOW then return rec end
    return nil
end

local function UpdateFastestKill(dstName)
    if fight.active then
        local elapsed = GetTime() - fight.startTime
        local r = EnsureRecords()
        if elapsed > 0 and ((r.fastestKill.seconds or 0) == 0 or elapsed < r.fastestKill.seconds) then
            r.fastestKill = { seconds = elapsed, target = dstName, when = time() }
        end
    end
end

local function AddPetLastStandJournal()
    local petName = activePet and activePet.name or UnitName("pet") or "Your pet"
    local zone = GetZoneName()
    local line = string.format(PET_LAST_STAND_LINES[math.random(#PET_LAST_STAND_LINES)], petName, zone)
    AddJournalEntry("petdeath", line)
    if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cffff6666" .. line .. "|r") end
end

local function CreditKillOnce(dstGUID, dstName, who, petName, rec)
    if not who then return false end
    local killKey = dstGUID or ("noguid:" .. SafeText(dstName, "unknown") .. ":" .. tostring(math.floor(GetTime() * 10)))
    if creditedKillGUIDs[killKey] then return false end
    creditedKillGUIDs[killKey] = GetTime()

    local t = EnsureTotals()
    local zone = EnsureZoneRecord(GetZoneName())
    zone.kills = (zone.kills or 0) + 1

    local info = GetMobInfo(dstGUID, dstName)
    RecordBestiaryKill(dstName, who, info)

    if who == "pet" then
        t.petKills = t.petKills + 1
        zone.petKills = (zone.petKills or 0) + 1
        local name = petName or (activePet and activePet.name)
        if name then
            local p = EnsurePetRecord(name)
            p.kills = (p.kills or 0) + 1
            p.survivalKills = (p.survivalKills or 0) + 1
            if p.survivalKills > (p.bestSurvivalStreak or 0) then p.bestSurvivalStreak = p.survivalKills end
            p.lastKillAt = time()
            p.lastZone = GetZoneName()
            zone.pets[name] = (zone.pets[name] or 0) + 1
            local pct = GetPetHealthPct()
            if pct and pct <= 0.20 then
                p.lowHealthKills = (p.lowHealthKills or 0) + 1
                t.petLastStandKills = (t.petLastStandKills or 0) + 1
                AddJournalEntry("laststand", name .. " landed a killing blow while barely standing.")
            end
        end
        if MaybeEmote then MaybeEmote("kill", SafeText(dstName, "the target")) end
    elseif who == "player" then
        t.playerKills = t.playerKills + 1
        zone.playerKills = (zone.playerKills or 0) + 1
        if not UnitExists("pet") then t.loneWolfKills = (t.loneWolfKills or 0) + 1 end
    else
        return false
    end

    local pct = GetPetHealthPct()
    if pct and pct <= 0.10 then
        t.closeCallKills = (t.closeCallKills or 0) + 1
        AddJournalEntry("closecall", "Close call: won against " .. SafeText(dstName, "an enemy") .. " while your pet was badly wounded.")
    end

    if rec and rec.trapName then RecordTrapKill(rec.trapName, dstName) end
    RecordTrophyKill(dstName, who, petName, info)
    UpdateFastestKill(dstName)
    CheckAchievements()
    return true
end

local function HandleCombatLog(...)
    local _, subevent, srcGUID, srcName, srcFlags, dstGUID, dstName = ...
    if not subevent then return end

    local playerGUID = UnitGUID("player")
    local petGUID = UnitGUID("pet")
    local isPlayer = IsMyPlayerCombatSource(srcGUID, srcName, srcFlags)
    local isPet = IsMyPetCombatSource(srcGUID, srcName, srcFlags)

    if dstGUID and UnitGUID("target") == dstGUID then CaptureUnitInfo("target") end

    -- Deaths often have no useful source GUID, so handle UNIT_DIED before source filtering.
    if subevent == "UNIT_DIED" then
        if dstGUID == playerGUID then
            local t = EnsureTotals()
            t.playerDeaths = t.playerDeaths + 1
            EnsureZoneRecord(GetZoneName()).deaths = EnsureZoneRecord(GetZoneName()).deaths + 1
            AddJournalEntry("death", "Died in " .. GetZoneName())
            return
        elseif dstGUID == petGUID then
            local t = EnsureTotals()
            t.petDeaths = t.petDeaths + 1
            local z = EnsureZoneRecord(GetZoneName())
            z.petDeaths = (z.petDeaths or 0) + 1
            if activePet then
                local p = EnsurePetRecord(activePet.name)
                p.deaths = (p.deaths or 0) + 1
                p.lastDeathAt = time()
                p.survivalKills = 0
            end
            AddPetLastStandJournal()
            return
        end
        local rec = GetRecentDamageRecord(dstGUID, dstName)
        if rec then
            CreditKillOnce(dstGUID or (dstName and ("name:" .. string.lower(dstName))), dstName or rec.dstName, rec.who, rec.petName, rec)
        end
        if dstGUID then lastDamageByGUID[dstGUID] = nil end
        if dstName then lastDamageByName[string.lower(dstName)] = nil end
        PruneKillTracking()
        return
    end

    if subevent == "SPELL_CAST_SUCCESS" and isPlayer then
        local spellName = select(10, ...)
        if spellName == "Beast Lore" then
            local info = CaptureUnitInfo("target")
            local name = dstName or (info and info.name) or UnitName("target")
            if name then
                local b = EnsureBestiaryRecord(name)
                b.beastLore = (b.beastLore or 0) + 1
                b.lastBeastLore = time()
                RecordBestiarySeen(name, info)
                AddJournalEntry("beastlore", "Studied " .. name .. " with Beast Lore in " .. GetZoneName())
            end
        else
            RecordTrapCast(spellName)
        end
    end

    if subevent == "SPELL_AURA_APPLIED" and isPlayer then
        local spellName = select(10, ...)
        RecordTrapAffected(spellName)
    end

    if not isPlayer and not isPet then return end

    local amount, isCrit, spellName
    if subevent == "SWING_DAMAGE" then
        amount = select(9, ...)
        isCrit = select(15, ...)
    elseif subevent == "RANGE_DAMAGE" or subevent == "SPELL_DAMAGE" or subevent == "SPELL_PERIODIC_DAMAGE" then
        spellName = select(10, ...)
        amount = select(12, ...)
        isCrit = select(18, ...)
    elseif subevent == "RANGE_MISSED" then
        if isPlayer then EnsureTotals().rangedMisses = EnsureTotals().rangedMisses + 1 end
    end

    local trapName = NormalizeTrapName(spellName)
    if trapName and amount and amount > 0 then RecordTrapDamage(trapName, amount) end

    if amount and amount > 0 then
        local info = GetMobInfo(dstGUID, dstName)
        RecordBestiarySeen(dstName, info)
        if not fight.active then StartFight() end
        if not fight.target and dstName then fight.target = dstName end

        if isPlayer then
            TrackLastDamage(dstGUID, dstName, "player", spellName, trapName)
            fight.playerDamage = fight.playerDamage + amount
            local t = EnsureTotals()
            t.totalDamageDealt = t.totalDamageDealt + amount
            if subevent == "RANGE_DAMAGE" then
                t.rangedHits = t.rangedHits + 1
                if isCrit then t.rangedCrits = t.rangedCrits + 1 end
            end
            if isCrit then
                local r = EnsureRecords()
                if amount > (r.highestCrit.amount or 0) then
                    r.highestCrit = { amount = amount, spell = spellName or "Auto Shot", target = dstName, when = time(), zone = GetZoneName() }
                    AddJournalEntry("crit", string.format("Critical hit for %s on %s%s", FormatNumber(amount), SafeText(dstName, "target"), spellName and " (" .. spellName .. ")" or ""))
                end
                local z = EnsureZoneRecord(GetZoneName())
                if amount > (z.biggestCrit or 0) then
                    z.biggestCrit = amount
                    z.biggestCritTarget = dstName
                end
            end
        elseif isPet then
            TrackLastDamage(dstGUID, dstName, "pet", spellName, nil)
            fight.petDamage = fight.petDamage + amount
            EnsureTotals().totalPetDamage = EnsureTotals().totalPetDamage + amount
            if isCrit then
                local name = activePet and activePet.name or srcName
                if name then
                    local p = EnsurePetRecord(name)
                    if amount > (p.bestCrit or 0) then p.bestCrit = amount end
                    local r = EnsureRecords()
                    if amount > (r.bestPetCrit.amount or 0) then
                        r.bestPetCrit = { amount = amount, pet = name, target = dstName, when = time() }
                    end
                end
            end
        end
    end

    if subevent == "PARTY_KILL" then
        -- On many 3.3.5/private-server builds, PARTY_KILL is credited to the
        -- player even when the pet dealt the actual finishing blow. Prefer the
        -- recent last-damage owner, then fall back to source GUID/flags.
        local rec = GetRecentDamageRecord(dstGUID, dstName)
        if rec then
            CreditKillOnce(dstGUID or (dstName and ("name:" .. string.lower(dstName))), dstName or rec.dstName, rec.who, rec.petName, rec)
        elseif isPet then
            CreditKillOnce(dstGUID, dstName, "pet", activePet and activePet.name or srcName, nil)
        elseif isPlayer then
            CreditKillOnce(dstGUID, dstName, "player", nil, nil)
        end
        PruneKillTracking()
    end
end

-- ============================================================
-- AMMO TRACKING
-- ============================================================

local function ClassifyAmmoFromWeapon()
    local link = GetInventoryItemLink("player", 18)
    if not link then return "arrow" end
    local _, _, _, _, _, _, subType = GetItemInfo(link)
    if subType == "Bows" or subType == "Crossbows" then return "arrow"
    elseif subType == "Guns" then return "bullet"
    elseif subType == "Thrown" then return "thrown" end
    return "arrow"
end

local function CountAmmoShot()
    if not IS_HUNTER then return end
    local kind = ClassifyAmmoFromWeapon()
    local t = EnsureTotals()
    if kind == "arrow" then t.arrowsFired = t.arrowsFired + 1
    elseif kind == "bullet" then t.bulletsFired = t.bulletsFired + 1
    elseif kind == "thrown" then t.thrownFired = t.thrownFired + 1 end
    CheckAchievements()
end

-- ============================================================
-- PET FLAVOR EMOTES
-- ============================================================

local PET_EMOTES = {
    combatStart = {
        "%s growls and bares teeth at %s.",
        "%s tenses, ready to leap at %s.",
        "%s circles %s warily.",
        "%s lets out a low warning at %s.",
    },
    kill = {
        "%s stands over the fallen %s, panting.",
        "%s sniffs at the still form of %s.",
        "%s claims its kill - %s lies defeated.",
        "%s shakes off the fight with %s.",
    },
    lowHealth = {
        "%s whimpers, hurt but still fighting.",
        "%s stumbles, wounded but still loyal.",
        "%s grits its teeth and presses on.",
    },
    ambientTown = {
        "%s pads quietly through %s, nose twitching at every shop door.",
        "%s watches the town crowd with bright, curious eyes.",
        "%s gives a soft huff, unimpressed by civilized comforts in %s.",
        "%s settles for a moment, content to rest where you rest.",
    },
    ambientWorld = {
        "%s sniffs the wind in %s and seems to choose the next trail before you do.",
        "%s trots ahead, then looks back to make sure you are following.",
        "%s watches the horizon, alert for movement beyond the grass.",
        "%s bumps your hand, then returns to watching the wilds.",
    },
    ambientDungeon = {
        "%s lowers its body and moves carefully through %s.",
        "%s lets out a quiet warning growl. Something in %s smells wrong.",
        "%s keeps close, ears sharp in the dark halls of %s.",
        "%s stares into the shadows, waiting for your signal.",
    },
    loyalty = {
        "%s leans against you for a moment. The bond feels stronger.",
        "%s looks up at you with complete trust.",
        "%s stays close, not because it must, but because it chooses to.",
    },
}

local PERSONALITY_EMOTES = {
    ["Bloodthirsty"] = {
        "%s looks far too pleased with itself after all the hunting in %s.",
        "%s licks its chops and searches %s for the next fight.",
    },
    ["Survivor"] = {
        "%s moves carefully through %s, every scar remembered.",
        "%s watches danger before danger notices you.",
    },
    ["Dungeon Beast"] = {
        "%s watches the tunnel ahead. This one has learned what waits in the dark.",
        "%s seems more comfortable in %s than any beast should be.",
    },
    ["Town Lounger"] = {
        "%s looks comfortable enough to claim a spot by the inn fire.",
        "%s gives %s the patient stare of a beast waiting for you to finish shopping.",
    },
    ["Wanderer"] = {
        "%s studies the road through %s like an old map.",
        "%s keeps walking before you even give the command.",
    },
    ["Loyal Guardian"] = {
        "%s stays close enough to throw itself between you and trouble.",
        "%s watches your back with grim patience.",
    },
}

function MaybeEmote(category, ...)
    if not IS_HUNTER then return end
    EnsureDB()
    if not HuntersLogDB.settings.emoteEnabled then return end
    if not activePet then return end
    local now = GetTime()
    if (now - lastPetEmote) < PET_EMOTE_COOLDOWN then return end

    local pool = PET_EMOTES[category]
    if category and string.find(category, "ambient") then
        local p = EnsurePetRecord(activePet.name)
        local personality = GetPetPersonality(activePet.name, p)
        if PERSONALITY_EMOTES[personality] and math.random() <= 0.45 then pool = PERSONALITY_EMOTES[personality] end
    end
    if not pool or #pool == 0 then return end
    local template = pool[math.random(#pool)]
    local msg = string.format(template, activePet.name, ...)
    DEFAULT_CHAT_FRAME:AddMessage("|cffff8800" .. msg .. "|r")
    lastPetEmote = now
end

local function GetAmbientPetCategory()
    local loc = GetLocationKind()
    if loc == "dungeon" then return "ambientDungeon" end
    if loc == "town" then return "ambientTown" end
    return "ambientWorld"
end

local function TryAmbientPetEmote()
    if not IS_HUNTER or not activePet then return end
    if not IsPetAlive() then return end
    local now = GetTime()
    if (now - lastPetEmote) < PET_EMOTE_COOLDOWN then return end
    if math.random() > PET_AMBIENT_CHANCE then return end
    MaybeEmote(GetAmbientPetCategory(), GetZoneName())
end

-- ============================================================
-- MINIMAP BUTTON
-- ============================================================

local OUR_BUTTON_NAME = "HuntersLogButton"
local minimapBtn

local function CreateMinimapButton()
    if minimapBtn then return minimapBtn end
    local btn = CreateFrame("Button", OUR_BUTTON_NAME, Minimap)
    btn:SetSize(31, 31)
    btn:SetFrameStrata("MEDIUM")
    btn:SetFrameLevel(8)
    btn:RegisterForClicks("AnyUp")
    btn:RegisterForDrag("LeftButton")
    btn:SetMovable(true)

    local icon = btn:CreateTexture(nil, "BACKGROUND")
    icon:SetSize(20, 20)
    icon:SetPoint("CENTER", 0, 1)
    icon:SetTexture("Interface\\Icons\\Ability_Hunter_BeastTraining")
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    local border = btn:CreateTexture(nil, "OVERLAY")
    border:SetSize(54, 54)
    border:SetPoint("TOPLEFT", 0, 0)
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    btn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    local function UpdatePos()
        EnsureDB()
        local angle = math.rad(HuntersLogDB.minimap.angle or 220)
        local r = 80
        btn:ClearAllPoints()
        btn:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * r, math.sin(angle) * r)
    end
    UpdatePos()

    btn:SetScript("OnDragStart", function(self)
        self:LockHighlight()
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            cx, cy = cx / scale, cy / scale
            EnsureDB()
            HuntersLogDB.minimap.angle = math.deg(math.atan2(cy - my, cx - mx))
            UpdatePos()
        end)
    end)
    btn:SetScript("OnDragStop", function(self)
        self:UnlockHighlight()
        self:SetScript("OnUpdate", nil)
    end)

    btn:SetScript("OnClick", function(self, button)
        if button == "RightButton" then
            HuntersLogDB.settings.emoteEnabled = not HuntersLogDB.settings.emoteEnabled
            PrintHL("flavor emotes " .. (HuntersLogDB.settings.emoteEnabled and "enabled" or "disabled"))
        else
            HuntersLog_TogglePanel()
        end
    end)

    btn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("|cffffd200Hunter's Log|r")
        GameTooltip:AddLine("Pets: " .. CountTableEntries(HuntersLogDB.pets) .. "  Beasts: " .. CountBestiaryEntries())
        local r = EnsureRecords()
        if r.highestCrit.amount > 0 then GameTooltip:AddLine("Highest crit: " .. FormatNumber(r.highestCrit.amount)) end
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("|cffffffffLeft-click:|r Open log")
        GameTooltip:AddLine("|cffffffffRight-click:|r Toggle pet emotes")
        GameTooltip:AddLine("|cffffffffDrag:|r Reposition")
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function() GameTooltip:Hide() end)

    minimapBtn = btn
    return btn
end

-- ============================================================
-- PANEL
-- ============================================================

local panel
local currentTab = "overview"
local CONTENT_W = 650

local function GetFavoritePetForZone(z)
    local best, n = nil, 0
    if type(z) == "table" and type(z.pets) == "table" then
        for pet, count in pairs(z.pets) do
            if count > n then best, n = pet, count end
        end
    end
    return best or "-"
end

local function CreatePanel()
    if panel then return panel end
    EnsureDB()

    local p = CreateFrame("Frame", "HuntersLogPanel", UIParent)
    p:SetSize(720, 520)
    p:SetPoint("CENTER")
    p:SetFrameStrata("DIALOG")
    p:SetMovable(true); p:EnableMouse(true)
    p:RegisterForDrag("LeftButton")
    p:SetScript("OnDragStart", p.StartMoving)
    p:SetScript("OnDragStop", p.StopMovingOrSizing)
    p:Hide()

    p:SetBackdrop({
        bgFile = "Interface\\FrameGeneral\\UI-Background-Rock",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 32, edgeSize = 16,
        insets = { left = 4, right = 4, top = 4, bottom = 4 }
    })
    p:SetBackdropColor(0.06, 0.06, 0.06, 0.95)
    p:SetBackdropBorderColor(0.7, 0.6, 0.4, 1)

    local header = CreateFrame("Frame", nil, p)
    header:SetPoint("TOPLEFT", 4, -4)
    header:SetPoint("TOPRIGHT", -4, -4)
    header:SetHeight(56)
    local headerBg = header:CreateTexture(nil, "ARTWORK")
    headerBg:SetTexture("Interface\\Buttons\\WHITE8X8")
    headerBg:SetVertexColor(0.15, 0.10, 0.06, 0.95)
    headerBg:SetPoint("TOPLEFT", 4, -4)
    headerBg:SetPoint("BOTTOMRIGHT", -4, 4)

    local portrait = header:CreateTexture(nil, "OVERLAY")
    portrait:SetSize(44, 44)
    portrait:SetPoint("TOPLEFT", 8, -6)
    portrait:SetTexture("Interface\\Icons\\Ability_Hunter_BeastTraining")
    portrait:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    local title = header:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", portrait, "TOPRIGHT", 12, -4)
    title:SetText("Hunter's Log")
    title:SetTextColor(1, 0.82, 0)

    local sub = header:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -4)
    sub:SetText("|cffaaaaaaA hunter life chronicle for " .. (PLAYER_NAME or "you") .. "|r")

    local close = CreateFrame("Button", nil, p, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -2, -2)

    local content = CreateFrame("ScrollFrame", "HuntersLogScroll", p, "UIPanelScrollFrameTemplate")
    content:SetPoint("TOPLEFT", 14, -68)
    content:SetPoint("BOTTOMRIGHT", -32, 40)

    local body = CreateFrame("Frame", nil, content)
    body:SetSize(CONTENT_W, 1)
    content:SetScrollChild(body)
    p.body = body
    p.lines = {}

    local tabs = {}
    local tabDefs = {
        { "overview", "Overview" }, { "pets", "Pets" }, { "records", "Records" }, { "grounds", "Grounds" },
        { "bestiary", "Beasts" }, { "traps", "Traps" }, { "achievements", "Achieve" }, { "journal", "Journal" },
    }
    local function MakeTab(id, label, idx)
        local tab = CreateFrame("Button", "HuntersLogTab" .. idx, p, "CharacterFrameTabButtonTemplate")
        tab:SetID(idx)
        tab:SetText(label)
        if idx == 1 then tab:SetPoint("TOPLEFT", p, "BOTTOMLEFT", 10, 6)
        else tab:SetPoint("LEFT", tabs[idx - 1], "RIGHT", -16, 0) end
        PanelTemplates_TabResize(tab, 0)
        tab:SetScript("OnClick", function()
            currentTab = id
            if panel then panel:Refresh() end
        end)
        tabs[idx] = tab
        return tab
    end
    for idx, def in ipairs(tabDefs) do MakeTab(def[1], def[2], idx) end

    local function NewRow()
        local row = CreateFrame("Frame", nil, body)
        row:SetSize(CONTENT_W, 18)
        row.cols = {}
        for c = 1, 7 do
            local fs = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            fs:SetJustifyH("LEFT")
            row.cols[c] = fs
        end
        return row
    end

    function p:GetRow(idx)
        local row = self.lines[idx]
        if not row then row = NewRow(); self.lines[idx] = row end
        row:Show()
        for _, fs in ipairs(row.cols) do fs:SetText(""); fs:Hide() end
        return row
    end

    function p:HideAllRows()
        for _, row in ipairs(self.lines) do row:Hide() end
    end

    local function SetTextRow(row, idx, text, indent)
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", body, "TOPLEFT", indent or 0, -(idx - 1) * 18)
        local fs = row.cols[1]
        fs:ClearAllPoints()
        fs:SetPoint("LEFT", row, "LEFT", 0, 0)
        fs:SetWidth(CONTENT_W - (indent or 0))
        fs:SetJustifyH("LEFT")
        fs:SetText(text or "")
        fs:Show()
    end

    local function SetColumnRow(row, idx, specs)
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", body, "TOPLEFT", 0, -(idx - 1) * 18)
        for c, spec in ipairs(specs) do
            local fs = row.cols[c]
            if fs then
                fs:ClearAllPoints()
                fs:SetPoint("LEFT", row, "LEFT", spec.x or 0, 0)
                fs:SetWidth(spec.w or 100)
                fs:SetJustifyH(spec.justify or "LEFT")
                fs:SetText(spec.text or "")
                fs:Show()
            end
        end
    end

    function p:Refresh()
        EnsureDB()
        BankPetTime()
        self:HideAllRows()

        for idx, tab in ipairs(tabs) do
            if tabDefs[idx][1] == currentTab then PanelTemplates_SelectTab(tab) else PanelTemplates_DeselectTab(tab) end
        end

        local r = EnsureRecords()
        local t = EnsureTotals()
        local i = 0
        local function addText(text, indent) i = i + 1; SetTextRow(self:GetRow(i), i, text, indent) end
        local function addKV(label, value, valueColor)
            i = i + 1
            SetColumnRow(self:GetRow(i), i, {
                { x = 0,   w = 190, text = label, justify = "LEFT" },
                { x = 190, w = 440, text = (valueColor or "|cffffffff") .. (value or "") .. "|r", justify = "LEFT" },
            })
        end

        if currentTab == "overview" then
            addText("|cffffd200=== Career ===|r")
            addKV("Pets known:", tostring(CountTableEntries(HuntersLogDB.pets)))
            addKV("Bestiary entries:", tostring(CountBestiaryEntries()))
            addKV("Player kills:", FormatNumber(t.playerKills))
            addKV("Pet kills:", FormatNumber(t.petKills))
            addKV("Trophy kills:", FormatNumber(t.trophyKills))
            addKV("Player deaths:", FormatNumber(t.playerDeaths))
            addKV("Pet deaths:", FormatNumber(t.petDeaths))
            addText("")
            addText("|cffffd200=== Active Pet ===|r")
            if activePet then
                local pp = EnsurePetRecord(activePet.name)
                local bond = GetPetBondInfo(pp)
                addKV("Name:", activePet.name)
                addKV("Bond:", bond .. "  |cffaaaaaa(" .. GetPetPersonality(activePet.name, pp) .. ")|r")
                addKV("Mood:", GetPetMood(activePet.name, pp))
                addKV("Time together:", FormatHours(pp.totalSeconds or 0))
            else
                addKV("Active pet:", "none", "|cff999999")
            end
            addText("")
            addText("|cffffd200=== Hunter Habits ===|r")
            local totalKills = (t.playerKills or 0) + (t.petKills or 0)
            local petShare = totalKills > 0 and ((t.petKills or 0) * 100 / totalKills) or 0
            local hitTotal = (t.rangedHits or 0) + (t.rangedMisses or 0)
            local critRate = (t.rangedHits or 0) > 0 and ((t.rangedCrits or 0) * 100 / (t.rangedHits or 0)) or 0
            local missRate = hitTotal > 0 and ((t.rangedMisses or 0) * 100 / hitTotal) or 0
            addKV("Pet kill share:", string.format("%.1f%%", petShare))
            addKV("Ranged crit rate:", string.format("%.1f%%", critRate))
            addKV("Ranged miss rate:", string.format("%.1f%%", missRate))
            addKV("Lone wolf kills:", FormatNumber(t.loneWolfKills))
            addText("")
            addText("|cffffd200=== Ammunition ===|r")
            addKV("Arrows fired:", FormatNumber(t.arrowsFired))
            addKV("Bullets fired:", FormatNumber(t.bulletsFired))
            addKV("Thrown:", FormatNumber(t.thrownFired))
            addText("")
            addText("|cffffd200=== Distance ===|r")
            addKV("On foot:", FormatDistance(t.footDistance))
            addKV("Mounted:", FormatDistance(t.mountedDistance))

        elseif currentTab == "pets" then
            addText("|cffffd200=== Stable Roster Memories ===|r")
            i = i + 1
            SetColumnRow(self:GetRow(i), i, {
                { x = 0,   w = 120, text = "|cff999999Name|r" },
                { x = 120, w = 100, text = "|cff999999Bond|r" },
                { x = 220, w = 115, text = "|cff999999Personality|r" },
                { x = 335, w = 75,  text = "|cff999999Time|r" },
                { x = 410, w = 75,  text = "|cff999999K/D|r" },
                { x = 485, w = 70,  text = "|cff999999Crit|r", justify = "RIGHT" },
                { x = 560, w = 70,  text = "|cff999999DPS|r", justify = "RIGHT" },
            })
            local list = {}
            for n, pp in pairs(HuntersLogDB.pets) do if type(pp) == "table" then table.insert(list, { n, pp }) end end
            table.sort(list, function(a, b) return (a[2].totalSeconds or 0) > (b[2].totalSeconds or 0) end)
            for _, e in ipairs(list) do
                local n, pp = e[1], e[2]
                local marker = (activePet and activePet.name == n) and "|cff00ff00*|r " or "  "
                local bond = GetPetBondInfo(pp)
                i = i + 1
                SetColumnRow(self:GetRow(i), i, {
                    { x = 0,   w = 120, text = marker .. "|cffffffff" .. n .. "|r" },
                    { x = 120, w = 100, text = "|cffffffff" .. bond .. "|r" },
                    { x = 220, w = 115, text = "|cffaaaaaa" .. GetPetPersonality(n, pp) .. "|r" },
                    { x = 335, w = 75,  text = "|cffaaaaaa" .. FormatHours(pp.totalSeconds or 0) .. "|r" },
                    { x = 410, w = 75,  text = string.format("|cffffffff%d|r / |cffff8888%d|r", pp.kills or 0, pp.deaths or 0) },
                    { x = 485, w = 70,  text = "|cffffffff" .. FormatNumber(pp.bestCrit or 0) .. "|r", justify = "RIGHT" },
                    { x = 560, w = 70,  text = string.format("|cffffffff%.0f|r", pp.bestDPS or 0), justify = "RIGHT" },
                })
                if activePet and activePet.name == n then
                    addText("Mood: |cffffffff" .. GetPetMood(n, pp) .. "|r    Favorite zone: |cffaaaaaa" .. SafeText(pp.lastZone, "?") .. "|r", 16)
                end
            end
            if #list == 0 then addText("|cff999999No pets recorded yet.|r") end

        elseif currentTab == "records" then
            addText("|cffffd200=== Personal Records ===|r")
            if r.highestCrit.amount > 0 then
                addKV("Highest crit:", FormatNumber(r.highestCrit.amount))
                addText(string.format("    |cffaaaaaa%s on %s, %s|r", r.highestCrit.spell or "?", r.highestCrit.target or "?", FormatTimestamp(r.highestCrit.when)))
            else addKV("Highest crit:", "none yet", "|cff999999") end
            if r.bestPetCrit.amount > 0 then
                addKV("Best pet crit:", FormatNumber(r.bestPetCrit.amount) .. " |cffaaaaaaby " .. SafeText(r.bestPetCrit.pet, "pet") .. "|r")
            else addKV("Best pet crit:", "none yet", "|cff999999") end
            if r.highestDPS.amount > 0 then
                addKV("Highest DPS:", string.format("%.0f", r.highestDPS.amount) .. string.format(" |cffaaaaaaover %.1fs|r", r.highestDPS.fightTime or 0))
                addText(string.format("    |cffaaaaaavs %s, %s|r", r.highestDPS.target or "?", FormatTimestamp(r.highestDPS.when)))
            else addKV("Highest DPS:", "none yet", "|cff999999") end
            if r.fastestKill.seconds > 0 then addKV("Fastest kill:", string.format("%.1fs", r.fastestKill.seconds) .. " |cffaaaaaavs " .. (r.fastestKill.target or "?") .. "|r")
            else addKV("Fastest kill:", "none yet", "|cff999999") end
            if r.longestFight.seconds > 0 then addKV("Longest fight:", string.format("%.1fs", r.longestFight.seconds) .. " |cffaaaaaavs " .. (r.longestFight.target or "?") .. "|r") end
            addText("")
            addText("|cffffd200=== Recent Trophies ===|r")
            local shown = 0
            for _, tr in ipairs(HuntersLogDB.trophies) do
                shown = shown + 1
                addText(string.format("|cffaaaaaa%s|r  %s in %s", date("%m-%d", tr.when), SafeText(tr.name, "?"), SafeText(tr.zone, "?")))
                if shown >= 8 then break end
            end
            if shown == 0 then addText("|cff999999No trophy kills yet.|r") end

        elseif currentTab == "grounds" then
            addText("|cffffd200=== Hunting Grounds ===|r")
            i = i + 1
            SetColumnRow(self:GetRow(i), i, {
                { x = 0,   w = 170, text = "|cff999999Zone|r" },
                { x = 170, w = 70,  text = "|cff999999Kills|r", justify = "RIGHT" },
                { x = 250, w = 80,  text = "|cff999999Pet Kills|r", justify = "RIGHT" },
                { x = 340, w = 80,  text = "|cff999999Deaths|r", justify = "RIGHT" },
                { x = 430, w = 90,  text = "|cff999999Distance|r", justify = "RIGHT" },
                { x = 530, w = 110, text = "|cff999999Fav Pet|r" },
            })
            local list = {}
            for zn, zz in pairs(HuntersLogDB.zones) do if type(zz) == "table" then table.insert(list, { zn, zz }) end end
            table.sort(list, function(a, b) return ((a[2].kills or 0) + (a[2].distance or 0) * 100) > ((b[2].kills or 0) + (b[2].distance or 0) * 100) end)
            for _, e in ipairs(list) do
                local zn, zz = e[1], e[2]
                i = i + 1
                SetColumnRow(self:GetRow(i), i, {
                    { x = 0,   w = 170, text = "|cffffffff" .. zn .. "|r" },
                    { x = 170, w = 70,  text = FormatNumber(zz.kills or 0), justify = "RIGHT" },
                    { x = 250, w = 80,  text = FormatNumber(zz.petKills or 0), justify = "RIGHT" },
                    { x = 340, w = 80,  text = FormatNumber((zz.deaths or 0) + (zz.petDeaths or 0)), justify = "RIGHT" },
                    { x = 430, w = 90,  text = FormatDistance(zz.distance or 0), justify = "RIGHT" },
                    { x = 530, w = 110, text = "|cffaaaaaa" .. GetFavoritePetForZone(zz) .. "|r" },
                })
            end
            if #list == 0 then addText("|cff999999No hunting grounds recorded yet.|r") end

        elseif currentTab == "bestiary" then
            addText("|cffffd200=== Bestiary ===|r")
            i = i + 1
            SetColumnRow(self:GetRow(i), i, {
                { x = 0,   w = 210, text = "|cff999999Creature|r" },
                { x = 210, w = 105, text = "|cff999999Type|r" },
                { x = 325, w = 80,  text = "|cff999999Kills|r", justify = "RIGHT" },
                { x = 420, w = 90,  text = "|cff999999Tamed|r" },
                { x = 520, w = 125, text = "|cff999999First Zone|r" },
            })
            local list = {}
            for bn, bb in pairs(HuntersLogDB.bestiary) do
                if type(bb) == "table" and ((bb.kills or 0) > 0 or bb.tamed or bb.beastLore) then
                    table.insert(list, { bn, bb })
                end
            end
            table.sort(list, function(a, b) return (a[2].kills or 0) > (b[2].kills or 0) end)
            for _, e in ipairs(list) do
                local bn, bb = e[1], e[2]
                local note = bb.rare and "|cffff66ffRare|r" or (bb.elite and "|cffffaa00Elite|r" or (bb.beastLore and "|cff88ff88Lore|r" or ""))
                i = i + 1
                SetColumnRow(self:GetRow(i), i, {
                    { x = 0,   w = 210, text = "|cffffffff" .. bn .. "|r" },
                    { x = 210, w = 105, text = "|cffaaaaaa" .. SafeText(bb.creatureType, "?") .. "|r" },
                    { x = 325, w = 80,  text = FormatNumber(bb.kills or 0), justify = "RIGHT" },
                    { x = 420, w = 90,  text = bb.tamed and "|cff00ff00yes|r" or note },
                    { x = 520, w = 125, text = "|cffaaaaaa" .. SafeText(bb.firstSeenZone, "?") .. "|r" },
                })
            end
            if #list == 0 then addText("|cff999999No beasts recorded yet.|r") end

        elseif currentTab == "traps" then
            addText("|cffffd200=== Trap Tracker ===|r")
            addKV("Total traps placed:", FormatNumber(TotalTrapCasts()))
            addKV("Trap kills:", FormatNumber(t.trapKills))
            addText("")
            i = i + 1
            SetColumnRow(self:GetRow(i), i, {
                { x = 0,   w = 180, text = "|cff999999Trap|r" },
                { x = 190, w = 80,  text = "|cff999999Casts|r", justify = "RIGHT" },
                { x = 280, w = 80,  text = "|cff999999Affected|r", justify = "RIGHT" },
                { x = 370, w = 80,  text = "|cff999999Kills|r", justify = "RIGHT" },
                { x = 460, w = 90,  text = "|cff999999Damage|r", justify = "RIGHT" },
                { x = 560, w = 80,  text = "|cff999999Last Used|r" },
            })
            local list = {}
            for tn, tr in pairs(HuntersLogDB.traps) do if type(tr) == "table" then table.insert(list, { tn, tr }) end end
            table.sort(list, function(a, b) return (a[2].casts or 0) > (b[2].casts or 0) end)
            for _, e in ipairs(list) do
                local tn, tr = e[1], e[2]
                i = i + 1
                SetColumnRow(self:GetRow(i), i, {
                    { x = 0,   w = 180, text = "|cffffffff" .. tn .. "|r" },
                    { x = 190, w = 80,  text = FormatNumber(tr.casts or 0), justify = "RIGHT" },
                    { x = 280, w = 80,  text = FormatNumber(tr.affected or 0), justify = "RIGHT" },
                    { x = 370, w = 80,  text = FormatNumber(tr.kills or 0), justify = "RIGHT" },
                    { x = 460, w = 90,  text = FormatNumber(tr.damage or 0), justify = "RIGHT" },
                    { x = 560, w = 80,  text = tr.lastUsed and tr.lastUsed > 0 and date("%m-%d", tr.lastUsed) or "-" },
                })
            end
            if #list == 0 then addText("|cff999999No traps recorded yet.|r") end

        elseif currentTab == "achievements" then
            addText("|cffffd200=== Hunter Achievements ===|r")
            local unlocked = 0
            for _, a in ipairs(ACHIEVEMENTS) do if IsAchievementUnlocked(a.key) then unlocked = unlocked + 1 end end
            addKV("Progress:", unlocked .. " / " .. #ACHIEVEMENTS)
            addText("")
            for _, a in ipairs(ACHIEVEMENTS) do
                local got = HuntersLogDB.achievements[a.key]
                local mark = got and "|cff00ff00[Done]|r " or "|cff777777[----]|r "
                addText(mark .. "|cffffffff" .. a.name .. "|r - |cffaaaaaa" .. a.desc .. "|r")
                if got then addText("    |cff777777Earned " .. date("%Y-%m-%d", got.when) .. "|r") end
            end

        elseif currentTab == "journal" then
            addText("|cffffd200=== Journal ===|r")
            local count = 0
            for _, e in ipairs(HuntersLogDB.journal) do
                count = count + 1
                i = i + 1
                SetColumnRow(self:GetRow(i), i, {
                    { x = 0,   w = 90,  text = "|cff999999" .. date("%m-%d %H:%M", e.when) .. "|r" },
                    { x = 100, w = 540, text = e.text or "" },
                })
                if count >= 150 then addText("|cff666666(showing latest 150 entries)|r"); break end
            end
            if count == 0 then addText("|cff999999Your story has yet to be written.|r") end
        end

        body:SetHeight(math.max(1, i * 18 + 10))
    end

    p:HookScript("OnShow", function(self) self:Refresh() end)
    p:SetScript("OnKeyDown", function(self, key) if key == "ESCAPE" then self:Hide() end end)
    p:HookScript("OnShow", function(self) self:EnableKeyboard(true) end)
    p:HookScript("OnHide", function(self) self:EnableKeyboard(false) end)

    panel = p
    return p
end

function HuntersLog_TogglePanel()
    local p = CreatePanel()
    if p:IsShown() then p:Hide() else p:Show() end
end

local panelTicker = CreateFrame("Frame")
panelTicker.acc = 0
panelTicker:SetScript("OnUpdate", function(self, elapsed)
    if not panel or not panel:IsShown() then return end
    self.acc = self.acc + elapsed
    if self.acc >= 1 then self.acc = 0; EnsureDB(); panel:Refresh() end
end)

-- ============================================================
-- TICKER
-- ============================================================

local mainTicker = CreateFrame("Frame")
mainTicker.acc = 0
mainTicker.distAcc = 0
mainTicker.ambientAcc = 0
mainTicker.achAcc = 0
mainTicker:SetScript("OnUpdate", function(self, elapsed)
    self.acc = self.acc + elapsed
    self.distAcc = self.distAcc + elapsed
    self.ambientAcc = self.ambientAcc + elapsed
    self.achAcc = self.achAcc + elapsed

    if self.distAcc >= 0.5 then self.distAcc = 0; UpdateDistance() end
    if self.acc >= 5 then
        local tickElapsed = self.acc
        self.acc = 0
        EnsureDB()
        CheckHunterPet()
        BankPetTime()
        UpdateZoneTime(tickElapsed)
        if UnitExists("target") then CaptureUnitInfo("target") end
        if IsPetAlive() then
            local pct = GetPetHealthPct()
            if pct and pct <= 0.30 then MaybeEmote("lowHealth") end
        end
    end
    if self.ambientAcc >= PET_AMBIENT_CHECK_INTERVAL then self.ambientAcc = 0; TryAmbientPetEmote() end
    if self.achAcc >= 30 then self.achAcc = 0; CheckAchievements() end
end)

-- ============================================================
-- EVENTS
-- ============================================================

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("PLAYER_ENTERING_WORLD")
f:RegisterEvent("PLAYER_TARGET_CHANGED")
f:RegisterEvent("UNIT_PET")
f:RegisterEvent("PLAYER_LOGOUT")
f:RegisterEvent("PLAYER_REGEN_ENABLED")
f:RegisterEvent("PLAYER_REGEN_DISABLED")
f:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
f:RegisterEvent("UNIT_RANGEDDAMAGE")
f:RegisterEvent("START_AUTOREPEAT_SPELL")
f:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")

f:SetScript("OnEvent", function(self, event, ...)
    EnsureDB()
    if event == "PLAYER_LOGIN" then
        if not IS_HUNTER then
            print("|cff999999Hunter's Log: not loaded (this character is not a hunter).|r")
            return
        end
        PLAYER_NAME = UnitName("player")
        EnsureTotals().sessionsPlayed = EnsureTotals().sessionsPlayed + 1
        CreateMinimapButton()
        CheckHunterPet()
        CheckAchievements()
        PrintHL("loaded. Click the minimap button or type |cffffff00/hl|r.")
        return
    end
    if not IS_HUNTER then return end

    if event == "PLAYER_ENTERING_WORLD" then
        CheckHunterPet()
        EnsureZoneRecord(GetZoneName())
        lastPetEmote = 0
        return
    end
    if event == "PLAYER_TARGET_CHANGED" then
        CaptureUnitInfo("target")
        return
    end
    if event == "UNIT_PET" then
        local unit = ...
        if unit == "player" then CheckHunterPet() end
        return
    end
    if event == "PLAYER_LOGOUT" then
        StopPet()
        EndFight()
        return
    end
    if event == "PLAYER_REGEN_DISABLED" then
        StartFight()
        MaybeEmote("combatStart", UnitName("target") or "an enemy")
        return
    end
    if event == "PLAYER_REGEN_ENABLED" then
        EndFight()
        return
    end
    if event == "UNIT_SPELLCAST_SUCCEEDED" then
        local unit, spell = ...
        if unit == "player" and spell == "Beast Lore" then
            local info = CaptureUnitInfo("target")
            local name = info and info.name or UnitName("target")
            if name then
                local b = EnsureBestiaryRecord(name)
                b.beastLore = (b.beastLore or 0) + 1
                b.lastBeastLore = time()
                RecordBestiarySeen(name, info)
                AddJournalEntry("beastlore", "Studied " .. name .. " with Beast Lore in " .. GetZoneName())
            end
        end
        return
    end
    if event == "COMBAT_LOG_EVENT_UNFILTERED" then
        HandleCombatLog(...)
        local subevent = select(2, ...)
        local srcGUID = select(3, ...)
        if subevent == "RANGE_DAMAGE" and srcGUID == UnitGUID("player") then CountAmmoShot() end
        return
    end
end)

-- ============================================================
-- RESUME + SLASH
-- ============================================================

local function GetMostUsedPet()
    local best, secs = nil, 0
    for n, p in pairs(HuntersLogDB.pets) do
        if type(p) == "table" and (p.totalSeconds or 0) > secs then best, secs = n, p.totalSeconds or 0 end
    end
    return best, secs
end

local function GetFavoriteHuntingGround()
    local best, score = nil, -1
    for z, rec in pairs(HuntersLogDB.zones) do
        if type(rec) == "table" then
            local s = (rec.kills or 0) + UnitsToMiles(rec.distance or 0)
            if s > score then best, score = z, s end
        end
    end
    return best
end

local function PrintResume()
    local t = EnsureTotals()
    local r = EnsureRecords()
    local pet, secs = GetMostUsedPet()
    local ground = GetFavoriteHuntingGround()
    local petText = pet and (pet .. " - " .. FormatHours(secs)) or "none"
    local bondText = ""
    if pet then
        local p = EnsurePetRecord(pet)
        local bond = GetPetBondInfo(p)
        bondText = " | Bond: " .. bond .. " | " .. GetPetPersonality(pet, p)
    end
    local line1 = string.format("%s, Hunter - %s kills, %s pet kills, %s ammo fired", PLAYER_NAME or UnitName("player") or "Hunter", FormatNumber((t.playerKills or 0) + (t.petKills or 0)), FormatNumber(t.petKills or 0), FormatNumber((t.arrowsFired or 0) + (t.bulletsFired or 0) + (t.thrownFired or 0)))
    local line2 = string.format("Longest companion: %s%s | Biggest crit: %s | Favorite ground: %s", petText, bondText, FormatNumber(r.highestCrit.amount or 0), ground or "unknown")
    DEFAULT_CHAT_FRAME:AddMessage("|cffff8800Hunter's Resume:|r " .. line1)
    DEFAULT_CHAT_FRAME:AddMessage("|cffff8800Hunter's Resume:|r " .. line2)
end

SLASH_HUNTERSLOG1 = "/hl"
SLASH_HUNTERSLOG2 = "/hunterslog"
SlashCmdList["HUNTERSLOG"] = function(msg)
    msg = msg and msg:lower() or ""
    EnsureDB()
    if not IS_HUNTER then
        print("|cff999999Hunter's Log only works on hunters.|r")
        return
    end
    if msg == "emote" then
        HuntersLogDB.settings.emoteEnabled = not HuntersLogDB.settings.emoteEnabled
        PrintHL("flavor emotes " .. (HuntersLogDB.settings.emoteEnabled and "enabled" or "disabled"))
        return
    end
    if msg == "test" then
        lastPetEmote = 0
        MaybeEmote(GetAmbientPetCategory(), GetZoneName())
        return
    end
    if msg == "resume" then
        PrintResume()
        return
    end
    if msg == "help" then
        PrintHL("/hl opens the log. /hl emote toggles pet chatter. /hl test forces one pet line. /hl resume prints your hunter resume.")
        return
    end
    HuntersLog_TogglePanel()
end
