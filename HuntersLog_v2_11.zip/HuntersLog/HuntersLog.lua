-- HuntersLog
-- A persistent record of your hunter's career: pets, kills, distances, records,
-- trophies, hunting grounds, bestiary entries, traps, achievements, and pet personality.

HuntersLogDB = HuntersLogDB or {}

-- ============================================================
-- DATABASE
-- ============================================================

local function EnsureDB()
    if type(HuntersLogDB) ~= "table" then HuntersLogDB = {} end
    if type(HuntersLogDB.minimap) ~= "table" then HuntersLogDB.minimap = { angle = 220 } end
    if type(HuntersLogDB.pets) ~= "table" then HuntersLogDB.pets = {} end
    if type(HuntersLogDB.records) ~= "table" then HuntersLogDB.records = {} end
    if type(HuntersLogDB.totals) ~= "table" then HuntersLogDB.totals = {} end
    if type(HuntersLogDB.journal) ~= "table" then HuntersLogDB.journal = {} end
    if type(HuntersLogDB.zones) ~= "table" then HuntersLogDB.zones = {} end
    if type(HuntersLogDB.bestiary) ~= "table" then HuntersLogDB.bestiary = {} end
    if type(HuntersLogDB.traps) ~= "table" then HuntersLogDB.traps = {} end
    if type(HuntersLogDB.achievements) ~= "table" then HuntersLogDB.achievements = {} end
    if type(HuntersLogDB.trophies) ~= "table" then HuntersLogDB.trophies = {} end
    if type(HuntersLogDB.settings) ~= "table" then
        HuntersLogDB.settings = { emoteEnabled = true }
    end
    if HuntersLogDB.settings.emoteEnabled == nil then HuntersLogDB.settings.emoteEnabled = true end
    if HuntersLogDB.settings.loreTooltipEnabled == nil then HuntersLogDB.settings.loreTooltipEnabled = true end
    if HuntersLogDB.settings.bestiaryFilter == nil then HuntersLogDB.settings.bestiaryFilter = "all" end
    if HuntersLogDB.settings.bestiarySort == nil then HuntersLogDB.settings.bestiarySort = "kills" end
    if HuntersLogDB.settings.achievementToasts == nil then HuntersLogDB.settings.achievementToasts = true end
    if HuntersLogDB.settings.petTitlesEnabled == nil then HuntersLogDB.settings.petTitlesEnabled = true end
    if HuntersLogDB.settings.petMemorialScreenshots == nil then HuntersLogDB.settings.petMemorialScreenshots = true end
end
EnsureDB()

local _, playerClass = UnitClass("player")
local IS_HUNTER = (playerClass == "HUNTER")
local PLAYER_NAME = nil

local PET_EMOTE_COOLDOWN = 180       -- 3 minutes between flavor emotes
local PET_AMBIENT_CHECK_INTERVAL = 10
local PET_AMBIENT_CHANCE = 0.35
local PET_DAMAGE_KILL_WINDOW = 12
local KILL_TRACK_TTL = 60
local lastPetEmote = 0

local MaybeEmote -- forward declaration
local ApplyPetTitleOverride -- forward declaration
local CaptureBestiaryModelSnapshot -- forward declaration
local activePet = nil  -- { name, startTime }; forward-declared so pet systems share the same state

-- ============================================================
-- HELPERS
-- ============================================================

local function SafeText(v, fallback)
    if v == nil or v == "" then return fallback or "?" end
    return tostring(v)
end

local function ShortText(text, maxLen)
    text = SafeText(text, "")
    maxLen = maxLen or 18
    if string.len(text) <= maxLen then return text end
    if maxLen <= 3 then return string.sub(text, 1, maxLen) end
    return string.sub(text, 1, maxLen - 3) .. "..."
end

local function FormatHours(secs)
    if not secs or secs <= 0 then return "0m" end
    local h = math.floor(secs / 3600)
    local m = math.floor((secs % 3600) / 60)
    if h > 0 then return string.format("%dh %dm", h, m) end
    return string.format("%dm", m)
end

local function FormatNumber(n)
    if not n or n == 0 then return "0" end
    if n >= 1000000 then return string.format("%.2fM", n / 1000000) end
    if n >= 10000 then return string.format("%.1fK", n / 1000) end
    return tostring(math.floor(n))
end

local function UnitsToYards(units)
    return (units or 0) * 3000
end

local function UnitsToMiles(units)
    return UnitsToYards(units) / 5280
end

local function FormatDistance(units)
    if not units or units <= 0 then return "0 yd" end
    local yards = UnitsToYards(units)
    if yards >= 5280 then return string.format("%.2f mi", yards / 5280) end
    if yards >= 1000 then return string.format("%.0f yd", yards) end
    return string.format("%d yd", math.floor(yards))
end

local function FormatTimestamp(ts)
    if not ts or ts == 0 then return "?" end
    return date("%Y-%m-%d", ts)
end

local function AddJournalEntry(kind, text)
    EnsureDB()
    table.insert(HuntersLogDB.journal, 1, { when = time(), kind = kind, text = text })
    while #HuntersLogDB.journal > 700 do table.remove(HuntersLogDB.journal) end
end

local function PrintHL(msg, color)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage((color or "|cffff8800") .. "Hunter's Log:|r " .. msg)
    else
        print("Hunter's Log: " .. msg)
    end
end

local achievementToast
local achievementToastQueue = {}

local function GetAchievementIcon(ach)
    return (ach and ach.icon) or "Interface\\Icons\\Achievement_General"
end

local ACHIEVEMENT_TOAST_Y = -165

local function AnchorAchievementToast(frame, yOffset)
    -- Built-in achievement alerts appear near the upper center of the screen.
    -- Keep Hunter's Log toasts in that same area instead of sliding in from the right.
    frame:ClearAllPoints()
    frame:SetPoint("TOP", UIParent, "TOP", 0, yOffset or ACHIEVEMENT_TOAST_Y)
end

local function CreateAchievementToast()
    if achievementToast then return achievementToast end
    local f = CreateFrame("Frame", "HuntersLogAchievementToast", UIParent)
    f:SetSize(360, 72)
    AnchorAchievementToast(f, ACHIEVEMENT_TOAST_Y + 50)
    f:SetFrameStrata("DIALOG")
    f:SetFrameLevel(90)
    f:Hide()
    f:SetAlpha(0)
    f:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 14,
        insets = { left = 4, right = 4, top = 4, bottom = 4 }
    })
    f:SetBackdropColor(0.05, 0.04, 0.02, 0.96)
    f:SetBackdropBorderColor(1, 0.75, 0.20, 1)

    f.icon = f:CreateTexture(nil, "ARTWORK")
    f.icon:SetSize(44, 44)
    f.icon:SetPoint("LEFT", 14, 0)
    f.icon:SetTexture("Interface\\Icons\\Achievement_General")
    f.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    f.title:SetPoint("TOPLEFT", f.icon, "TOPRIGHT", 12, 2)
    f.title:SetPoint("RIGHT", f, "RIGHT", -12, 0)
    f.title:SetJustifyH("LEFT")
    f.title:SetTextColor(1, 0.82, 0)
    f.title:SetText("Achievement Earned")

    f.desc = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    f.desc:SetPoint("TOPLEFT", f.title, "BOTTOMLEFT", 0, -4)
    f.desc:SetPoint("RIGHT", f, "RIGHT", -12, 0)
    f.desc:SetJustifyH("LEFT")
    f.desc:SetTextColor(0.86, 0.86, 0.86)
    f.desc:SetText("Hunter's Log")

    f.shine = f:CreateTexture(nil, "OVERLAY")
    f.shine:SetTexture("Interface\\Cooldown\\star4")
    f.shine:SetBlendMode("ADD")
    f.shine:SetSize(78, 78)
    f.shine:SetPoint("CENTER", f.icon, "CENTER", 0, 0)
    f.shine:SetVertexColor(1, 0.8, 0.2, 0.65)

    f.elapsed = 0
    f:SetScript("OnUpdate", function(self, elapsed)
        self.elapsed = (self.elapsed or 0) + elapsed
        local t = self.elapsed
        if t < 0.25 then
            local p = t / 0.25
            self:SetAlpha(p)
            AnchorAchievementToast(self, ACHIEVEMENT_TOAST_Y + 40 - (40 * p))
        elseif t < 4.25 then
            self:SetAlpha(1)
            AnchorAchievementToast(self, ACHIEVEMENT_TOAST_Y)
        elseif t < 5.0 then
            local p = (t - 4.25) / 0.75
            self:SetAlpha(1 - p)
            AnchorAchievementToast(self, ACHIEVEMENT_TOAST_Y - (20 * p))
        else
            self:Hide()
            self:SetAlpha(0)
            if #achievementToastQueue > 0 then
                local nextAch = table.remove(achievementToastQueue, 1)
                ShowAchievementToast(nextAch)
            end
        end
    end)
    achievementToast = f
    return f
end

function ShowAchievementToast(ach)
    if not ach then return end
    EnsureDB()
    if not HuntersLogDB.settings.achievementToasts then return end
    local f = CreateAchievementToast()
    if f:IsShown() then
        table.insert(achievementToastQueue, ach)
        return
    end
    f.icon:SetTexture(GetAchievementIcon(ach))
    f.title:SetText("Achievement Earned: " .. SafeText(ach.name, "Hunter's Log"))
    f.desc:SetText(SafeText(ach.desc, "A new hunter milestone has been recorded."))
    f.elapsed = 0
    AnchorAchievementToast(f, ACHIEVEMENT_TOAST_Y + 40)
    f:SetAlpha(0)
    f:Show()
    if PlaySoundFile then
        PlaySoundFile("Sound\\Interface\\LevelUp.wav")
    elseif PlaySound then
        PlaySound("LEVELUPSOUND")
    end
end

local function GetLocationKind()
    local _, instType = IsInInstance()
    if instType == "party" or instType == "raid" then return "dungeon" end
    if IsResting and IsResting() then return "town" end
    return "world"
end

local function GetZoneName()
    return GetRealZoneText() or GetZoneText() or "Unknown"
end

local function GetPetHealthPct()
    if not UnitExists("pet") then return nil end
    local hp = UnitHealth("pet") or 0
    local maxHp = UnitHealthMax("pet") or 0
    if maxHp <= 0 then return nil end
    return hp / maxHp
end

local function IsPetAlive()
    return UnitExists("pet") and not UnitIsDead("pet")
end

local function HasCombatFlag(flags, flag)
    if not flags or not flag or not bit or not bit.band then return false end
    return bit.band(flags, flag) ~= 0
end

local function IsMyPlayerCombatSource(srcGUID, srcName, srcFlags)
    local playerGUID = UnitGUID("player")
    if playerGUID and srcGUID == playerGUID then return true end

    -- Some private servers/client builds can report odd GUIDs in the combat log.
    -- Fall back to the source name plus the "mine/player" combat-log flags.
    local playerName = UnitName("player")
    if playerName and srcName == playerName then
        if HasCombatFlag(srcFlags, COMBATLOG_OBJECT_AFFILIATION_MINE) or
           HasCombatFlag(srcFlags, COMBATLOG_OBJECT_TYPE_PLAYER) then
            return true
        end
    end
    return false
end

local function IsMyPetCombatSource(srcGUID, srcName, srcFlags)
    local petGUID = UnitGUID("pet")
    if petGUID and srcGUID and srcGUID == petGUID then return true end

    -- Never treat another player's pet/guardian as ours just because it is
    -- player-controlled. This was causing other hunters' pets and random
    -- summons/totems to be added to the Stable Roster.
    if not UnitExists("pet") then return false end

    local petName = UnitName("pet")
    if petName and srcName == petName then
        -- Name fallback is only allowed for our current pet name, and rejected
        -- if the combat log clearly says the source belongs to someone else.
        if HasCombatFlag(srcFlags, COMBATLOG_OBJECT_AFFILIATION_OUTSIDER) or
           HasCombatFlag(srcFlags, COMBATLOG_OBJECT_AFFILIATION_PARTY) or
           HasCombatFlag(srcFlags, COMBATLOG_OBJECT_AFFILIATION_RAID) then
            return false
        end
        return true
    end

    -- Official flag path: the source must be a pet AND affiliated with me.
    -- Do not accept COMBATLOG_OBJECT_CONTROL_PLAYER by itself; that also
    -- matches other players' pets.
    if HasCombatFlag(srcFlags, COMBATLOG_OBJECT_TYPE_PET) and
       HasCombatFlag(srcFlags, COMBATLOG_OBJECT_AFFILIATION_MINE) then
        return true
    end
    return false
end

-- ============================================================
-- ENSURE RECORDS
-- ============================================================

local function EnsurePetRecord(name)
    EnsureDB()
    if not name or name == "" then name = "Unknown Pet" end
    local p = HuntersLogDB.pets[name]
    if type(p) ~= "table" then
        p = {
            firstTamed = time(), totalSeconds = 0,
            kills = 0, deaths = 0, totalDamage = 0, fights = 0,
            bestDPS = 0, bestCrit = 0,
        }
        HuntersLogDB.pets[name] = p
    end
    p.firstTamed = p.firstTamed or time()
    p.totalSeconds = p.totalSeconds or 0
    p.kills = p.kills or 0
    p.deaths = p.deaths or 0
    p.totalDamage = p.totalDamage or 0
    p.fights = p.fights or 0
    p.bestDPS = p.bestDPS or 0
    p.bestCrit = p.bestCrit or 0
    p.dungeonSeconds = p.dungeonSeconds or 0
    p.townSeconds = p.townSeconds or 0
    p.worldSeconds = p.worldSeconds or 0
    p.distance = p.distance or 0
    p.survivalKills = p.survivalKills or 0
    p.bestSurvivalStreak = p.bestSurvivalStreak or 0
    p.lowHealthKills = p.lowHealthKills or 0
    p.lastKillAt = p.lastKillAt or 0
    p.lastDeathAt = p.lastDeathAt or 0
    p.lastZone = p.lastZone or ""
    if type(p.zones) ~= "table" then p.zones = {} end
    if type(p.loyaltyMilestones) ~= "table" then p.loyaltyMilestones = {} end
    return p
end

local function MarkPetRecordOwned(name, p)
    if not name then return p end
    p = p or EnsurePetRecord(name)
    p.playerOwned = true
    p.ownerName = PLAYER_NAME or UnitName("player") or p.ownerName
    p.firstSeenAsOwnPet = p.firstSeenAsOwnPet or time()
    return p
end

local function IsOwnedPetRecord(name, p)
    if type(p) ~= "table" then return false end
    if p.playerOwned then return true end
    if activePet and activePet.name == name then return true end
    -- Old saves from before this ownership flag are treated as yours only if
    -- they actually accumulated time with you. Zero-time combat-log records
    -- were usually other players' pets/guardians and should be ignored.
    if (p.totalSeconds or 0) > 0 then return true end
    return false
end

local function CountOwnedPets()
    EnsureDB()
    local n = 0
    for name, p in pairs(HuntersLogDB.pets) do
        if IsOwnedPetRecord(name, p) then n = n + 1 end
    end
    return n
end

local function CleanForeignPetRecords()
    EnsureDB()
    local removed = 0
    local currentName = activePet and activePet.name or (UnitExists("pet") and UnitName("pet")) or nil
    for name, p in pairs(HuntersLogDB.pets) do
        if type(p) == "table" and name ~= currentName and not IsOwnedPetRecord(name, p) then
            local noTime = (p.totalSeconds or 0) <= 0 and (p.dungeonSeconds or 0) <= 0 and
                           (p.townSeconds or 0) <= 0 and (p.worldSeconds or 0) <= 0
            -- Old bad records from the loose combat-log pet check usually have
            -- 0 time but may have crit/DPS numbers. If the addon never saw the
            -- unit as YOUR actual UnitPet("player"), remove it from the stable.
            if noTime then
                HuntersLogDB.pets[name] = nil
                removed = removed + 1
            end
        end
    end
    return removed
end


local function EnsureTotals()
    EnsureDB()
    local t = HuntersLogDB.totals
    t.arrowsFired = t.arrowsFired or 0
    t.bulletsFired = t.bulletsFired or 0
    t.thrownFired = t.thrownFired or 0
    t.mountedDistance = t.mountedDistance or 0
    t.footDistance = t.footDistance or 0
    t.petKills = t.petKills or 0
    t.playerKills = t.playerKills or 0
    t.petDeaths = t.petDeaths or 0
    t.playerDeaths = t.playerDeaths or 0
    t.totalDamageDealt = t.totalDamageDealt or 0
    t.totalPetDamage = t.totalPetDamage or 0
    t.sessionsPlayed = t.sessionsPlayed or 0
    t.rangedHits = t.rangedHits or 0
    t.rangedCrits = t.rangedCrits or 0
    t.rangedMisses = t.rangedMisses or 0
    t.closeCallKills = t.closeCallKills or 0
    t.petLastStandKills = t.petLastStandKills or 0
    t.loneWolfKills = t.loneWolfKills or 0
    t.eliteKills = t.eliteKills or 0
    t.rareKills = t.rareKills or 0
    t.trapKills = t.trapKills or 0
    t.trophyKills = t.trophyKills or 0
    return t
end

local function EnsureRecords()
    EnsureDB()
    local r = HuntersLogDB.records
    r.highestCrit  = r.highestCrit  or { amount = 0 }
    r.highestDPS   = r.highestDPS   or { amount = 0 }
    r.fastestKill  = r.fastestKill  or { seconds = 0 }
    r.longestFight = r.longestFight or { seconds = 0 }
    r.bestPetCrit  = r.bestPetCrit  or { amount = 0 }
    return r
end

local function EnsureZoneRecord(zone)
    EnsureDB()
    zone = SafeText(zone, "Unknown")
    local z = HuntersLogDB.zones[zone]
    if type(z) ~= "table" then
        z = { firstVisit = time(), kills = 0, playerKills = 0, petKills = 0, deaths = 0, petDeaths = 0,
              distance = 0, timeSeconds = 0, biggestCrit = 0, biggestCritTarget = nil, pets = {} }
        HuntersLogDB.zones[zone] = z
    end
    z.firstVisit = z.firstVisit or time()
    z.kills = z.kills or 0
    z.playerKills = z.playerKills or 0
    z.petKills = z.petKills or 0
    z.deaths = z.deaths or 0
    z.petDeaths = z.petDeaths or 0
    z.distance = z.distance or 0
    z.timeSeconds = z.timeSeconds or 0
    z.biggestCrit = z.biggestCrit or 0
    if type(z.pets) ~= "table" then z.pets = {} end
    return z
end

local function EnsureBestiaryRecord(name)
    EnsureDB()
    name = SafeText(name, "Unknown Beast")
    local b = HuntersLogDB.bestiary[name]
    if type(b) ~= "table" then
        b = { firstSeen = time(), firstSeenZone = GetZoneName(), kills = 0, petKills = 0, playerKills = 0 }
        HuntersLogDB.bestiary[name] = b
    end
    b.firstSeen = b.firstSeen or time()
    b.firstSeenZone = b.firstSeenZone or GetZoneName()
    b.lastSeen = b.lastSeen or time()
    b.lastSeenZone = b.lastSeenZone or GetZoneName()
    b.kills = b.kills or 0
    b.petKills = b.petKills or 0
    b.playerKills = b.playerKills or 0
    return b
end

local function EnsureTrapRecord(name)
    EnsureDB()
    name = SafeText(name, "Unknown Trap")
    local tr = HuntersLogDB.traps[name]
    if type(tr) ~= "table" then
        tr = { casts = 0, affected = 0, kills = 0, damage = 0, firstUsed = time(), lastUsed = 0 }
        HuntersLogDB.traps[name] = tr
    end
    tr.casts = tr.casts or 0
    tr.affected = tr.affected or 0
    tr.kills = tr.kills or 0
    tr.damage = tr.damage or 0
    tr.firstUsed = tr.firstUsed or time()
    tr.lastUsed = tr.lastUsed or 0
    return tr
end

-- ============================================================
-- PET BOND, PERSONALITY, MOOD
-- ============================================================

local function GetPetBondInfo(p)
    if type(p) ~= "table" then return "Stranger", 0, 0 end
    local hours = (p.totalSeconds or 0) / 3600
    local dungeonHours = (p.dungeonSeconds or 0) / 3600
    local score = math.floor(hours * 2 + (p.kills or 0) / 8 + dungeonHours * 3 + (p.bestSurvivalStreak or 0) / 20 - (p.deaths or 0) * 2)
    if score < 0 then score = 0 end
    if score >= 300 then return "Legendary Partner", 5, score end
    if score >= 140 then return "Bloodbound", 4, score end
    if score >= 60 then return "Trusted", 3, score end
    if score >= 15 then return "Companion", 2, score end
    return "Stranger", 1, score
end

local function GetPetPersonality(name, p)
    if type(p) ~= "table" then return "Unknown" end
    if (p.kills or 0) >= 100 and (p.kills or 0) >= ((p.deaths or 0) + 1) * 20 then return "Bloodthirsty" end
    if (p.bestSurvivalStreak or 0) >= 100 then return "Survivor" end
    if (p.dungeonSeconds or 0) > 3600 and (p.dungeonSeconds or 0) > (p.worldSeconds or 0) and (p.dungeonSeconds or 0) > (p.townSeconds or 0) then return "Dungeon Beast" end
    if (p.townSeconds or 0) > 3600 and (p.townSeconds or 0) > (p.worldSeconds or 0) and (p.townSeconds or 0) > (p.dungeonSeconds or 0) then return "Town Lounger" end
    if UnitsToMiles(p.distance or 0) >= 10 then return "Wanderer" end
    if (p.deaths or 0) >= 10 then return "Loyal Guardian" end
    return "Steady Companion"
end

local function GetPetMood(name, p)
    if not activePet or not name or activePet.name ~= name then return "Resting" end
    if not UnitExists("pet") then return "Away" end
    if UnitIsDead("pet") then return "Fallen" end
    local pct = GetPetHealthPct()
    if pct and pct <= 0.30 then return "Wounded" end
    local now = time()
    if (p.lastDeathAt or 0) > 0 and now - p.lastDeathAt < 900 then return "Shaken" end
    if (p.lastKillAt or 0) > 0 and now - p.lastKillAt < 180 then return "Proud" end
    local loc = GetLocationKind()
    if loc == "dungeon" then return "Alert" end
    if loc == "town" then return "Resting" end
    if (p.totalSeconds or 0) > 3600 and (p.deaths or 0) == 0 then return "Content" end
    return "Ready"
end

local function GetPetTitle(name, p)
    if type(p) ~= "table" then return SafeText(name, "Companion") end
    local base = SafeText(name, "Companion")
    local bond = GetPetBondInfo(p)
    if (p.kills or 0) >= 1000 then return base .. " the Butcherer" end
    if (p.kills or 0) >= 500 then return base .. " the Ruthless" end
    if (p.bestSurvivalStreak or 0) >= 150 then return base .. " the Survivor" end
    if (p.dungeonSeconds or 0) >= 10 * 3600 then return base .. " the Delver" end
    if UnitsToMiles(p.distance or 0) >= 25 then return base .. " the Wanderer" end
    if (p.deaths or 0) == 0 and (p.totalSeconds or 0) >= 5 * 3600 then return base .. " the Unbroken" end
    if bond == "Legendary Partner" then return base .. " the Legendary" end
    if bond == "Bloodbound" then return base .. " the Bloodbound" end
    if bond == "Trusted" then return base .. " the Faithful" end
    return base
end

local function GetActivePetTitle()
    if not activePet or not activePet.name then return nil end
    local p = EnsurePetRecord(activePet.name)
    return GetPetTitle(activePet.name, p)
end

local petTitleHooked = false
local function SetPetFrameTitle()
    EnsureDB()
    local title
    if HuntersLogDB.settings.petTitlesEnabled then title = GetActivePetTitle() end
    title = title or (UnitExists("pet") and UnitName("pet"))
    if not title then return end
    -- Default 3.3.5 pet frame name string. Some UI replacements rename it, so guard everything.
    if PetName and PetName.SetText then PetName:SetText(title) end
    if PetFrame and PetFrame.name and PetFrame.name.SetText then PetFrame.name:SetText(title) end
end

local function AddPetTitleToTooltip(tooltip)
    if not tooltip or not tooltip.GetUnit then return false end
    EnsureDB()
    if not HuntersLogDB.settings.petTitlesEnabled then return false end
    local _, unit = tooltip:GetUnit()
    if not unit or not UnitExists(unit) then return false end
    if UnitExists("pet") and UnitIsUnit and UnitIsUnit(unit, "pet") then
        local title = GetActivePetTitle()
        if title and _G[tooltip:GetName() .. "TextLeft1"] then
            _G[tooltip:GetName() .. "TextLeft1"]:SetText(title)
            local p = EnsurePetRecord(activePet.name)
            tooltip:AddLine("|cffffd200Hunter's Log Title|r")
            tooltip:AddDoubleLine("Bond", GetPetBondInfo(p), 0.8, 0.8, 0.8, 1, 1, 1)
            tooltip:AddDoubleLine("Personality", GetPetPersonality(activePet.name, p), 0.8, 0.8, 0.8, 1, 0.82, 0)
            tooltip:AddDoubleLine("Kills", FormatNumber(p.kills or 0), 0.8, 0.8, 0.8, 1, 1, 1)
            tooltip:Show()
            return true
        end
    end
    return false
end

local function HookPetTitleOverride()
    if petTitleHooked then return end
    petTitleHooked = true
    if hooksecurefunc then
        if PetFrame_Update then hooksecurefunc("PetFrame_Update", SetPetFrameTitle) end
        if UnitFrame_Update and PetFrame then hooksecurefunc("UnitFrame_Update", function(frame) if frame == PetFrame then SetPetFrameTitle() end end) end
    end
end

ApplyPetTitleOverride = SetPetFrameTitle

local PET_LOYALTY_MILESTONES = {
    { key = "bond_1h",    seconds = 1 * 3600,     title = "Trusted Companion", text = "%s has spent an hour at your side. The bond is beginning to feel real." },
    { key = "bond_10h",   seconds = 10 * 3600,    title = "Battle-Bound",      text = "%s has fought beside you for ten hours. It watches your movements before you even give a command." },
    { key = "bond_25h",   seconds = 25 * 3600,    title = "Loyal Friend",      text = "%s has become more than a pet. Wherever you go, it chooses to follow." },
    { key = "bond_100h",  seconds = 100 * 3600,   title = "Old Hunting Partner", text = "%s has shared one hundred hours of roads, dungeons, and battle with you." },
    { key = "bond_500h",  seconds = 500 * 3600,   title = "Legendary Bond",    text = "%s is part of your legend now. Bards should know this beast's name." },
}

local function CheckPetLoyaltyMilestones(name, petRecord)
    if not name or type(petRecord) ~= "table" then return end
    if type(petRecord.loyaltyMilestones) ~= "table" then petRecord.loyaltyMilestones = {} end
    for _, m in ipairs(PET_LOYALTY_MILESTONES) do
        if not petRecord.loyaltyMilestones[m.key] and (petRecord.totalSeconds or 0) >= m.seconds then
            petRecord.loyaltyMilestones[m.key] = time()
            AddJournalEntry("bond", string.format("%s: " .. m.text, m.title, name))
            if MaybeEmote then MaybeEmote("loyalty") end
        end
    end
end

-- ============================================================
-- ACHIEVEMENTS
-- ============================================================

local ACHIEVEMENTS = {
    { key = "first_blood",       name = "First Blood",        desc = "Your pet earns its first killing blow.", icon = "Interface\\Icons\\Ability_Hunter_Pet_Wolf" },
    { key = "first_kill",        name = "First Hunt",         desc = "Record your first kill.", icon = "Interface\\Icons\\Ability_Hunter_SniperShot" },
    { key = "hundred_stalker",   name = "Hundred-Stalker",    desc = "Record 100 total kills.", icon = "Interface\\Icons\\Ability_Hunter_MasterMarksman" },
    { key = "thousand_claw",     name = "Thousand-Claw",      desc = "Record 1,000 total kills.", icon = "Interface\\Icons\\Ability_Hunter_KillCommand" },
    { key = "ten_thousand",      name = "Ten Thousand Reasons", desc = "Record 10,000 total kills.", icon = "Interface\\Icons\\Achievement_BG_KillingBlow_Most" },

    { key = "pack_leader",       name = "Pack Leader",        desc = "Spend 10 hours with one pet.", icon = "Interface\\Icons\\Ability_Hunter_BeastMastery" },
    { key = "inseparable",       name = "Inseparable",        desc = "Spend 100 hours with one pet.", icon = "Interface\\Icons\\Ability_Hunter_ImprovedMendPet" },
    { key = "lifelong_friend",   name = "Lifelong Companion", desc = "Spend 500 hours with one pet.", icon = "Interface\\Icons\\Achievement_Reputation_KirinTor" },
    { key = "stable_keeper",     name = "Stable Keeper",      desc = "Record 5 different pets.", icon = "Interface\\Icons\\INV_Misc_Key_03" },
    { key = "beast_collector",   name = "Beast Collector",    desc = "Record 25 different pets.", icon = "Interface\\Icons\\Ability_Hunter_BeastCall" },
    { key = "beastmaster",       name = "Beastmaster",        desc = "Reach 100 pet kills.", icon = "Interface\\Icons\\Ability_Hunter_AnimalHandler" },
    { key = "loyal_hunter",      name = "Loyal Hunter",       desc = "Reach a 100-kill survival streak with one pet.", icon = "Interface\\Icons\\Ability_Hunter_AspectOfTheMonkey" },
    { key = "old_friend",        name = "Old Friend",         desc = "Keep a pet in your log for 30 days.", icon = "Interface\\Icons\\Spell_Holy_SealOfSacrifice" },
    { key = "last_stand",        name = "Last Stand",         desc = "Your pet gets a killing blow while under 20% health.", icon = "Interface\\Icons\\Ability_Warrior_LastStand" },

    { key = "long_hunt",         name = "The Long Hunt",      desc = "Travel 10 miles on foot or mount.", icon = "Interface\\Icons\\Ability_Hunter_Pathfinding" },
    { key = "cross_country",     name = "Cross-Country",      desc = "Travel 100 total miles.", icon = "Interface\\Icons\\Achievement_Zone_EasternKingdoms_01" },
    { key = "globetrotter",      name = "Globetrotter",       desc = "Record activity in 30 different zones.", icon = "Interface\\Icons\\Achievement_Zone_Kalimdor_01" },
    { key = "wilderness",        name = "Wilderness Wanderer", desc = "Spend 24 hours in the wild with pets.", icon = "Interface\\Icons\\INV_Misc_Map02" },
    { key = "cityfolk",          name = "Cityfolk",           desc = "Spend 10 hours resting in towns with pets.", icon = "Interface\\Icons\\Achievement_Zone_Dalaran" },
    { key = "dungeon_companion", name = "Dungeon Companion",  desc = "Spend 5 hours in dungeons with one pet.", icon = "Interface\\Icons\\Achievement_Dungeon_UlduarRaid_Misc_01" },
    { key = "dungeon_delver",    name = "Dungeon Delver",     desc = "Spend 10 total hours in dungeons with pets.", icon = "Interface\\Icons\\Achievement_Dungeon_ClassicDungeonmaster" },

    { key = "arrowstorm",        name = "Arrowstorm",         desc = "Fire 5,000 arrows, bullets, or thrown weapons.", icon = "Interface\\Icons\\Ability_TheBlackArrow" },
    { key = "quiver_emptier",    name = "Quiver Emptier",     desc = "Fire 10,000 arrows.", icon = "Interface\\Icons\\INV_Ammo_Arrow_02" },
    { key = "munitioneer",       name = "Munitioneer",        desc = "Fire 10,000 total ranged shots.", icon = "Interface\\Icons\\INV_Ammo_Bullet_02" },
    { key = "all_three",         name = "All Three",          desc = "Use arrows, bullets, and thrown weapons at least once.", icon = "Interface\\Icons\\INV_ThrowingKnife_04" },
    { key = "big_one",           name = "The Big One",        desc = "Land a single hit over 5,000 damage.", icon = "Interface\\Icons\\Ability_Hunter_FocusedAim" },
    { key = "pet_big_crit",      name = "Savage Bite",        desc = "Record a pet crit over 1,000 damage.", icon = "Interface\\Icons\\Ability_Druid_Rake" },
    { key = "sharp_eye",         name = "Sharp Eye",          desc = "Record 1,000 ranged hits.", icon = "Interface\\Icons\\Ability_Hunter_ZenArchery" },

    { key = "close_call",        name = "Close Call",         desc = "Win a fight while your pet is under 10% health.", icon = "Interface\\Icons\\Spell_Holy_BlessingOfProtection" },
    { key = "steel_nerves",      name = "Steel Nerves",       desc = "Survive 5 close-call fights.", icon = "Interface\\Icons\\Ability_Hunter_Readiness" },
    { key = "lone_wolf",         name = "Lone Wolf",          desc = "Kill 25 enemies without a pet active.", icon = "Interface\\Icons\\Ability_Hunter_Longevity" },
    { key = "big_game",          name = "Big Game Hunter",    desc = "Defeat an elite, rare, or boss enemy.", icon = "Interface\\Icons\\Achievement_Boss_OssirianTheUnscarred" },
    { key = "headhunter",        name = "Headhunter",         desc = "Defeat 100 elite or rare enemies.", icon = "Interface\\Icons\\INV_Misc_Bone_HumanSkull_01" },
    { key = "rare_memory",       name = "Rare Memory",        desc = "Record 10 rare kills.", icon = "Interface\\Icons\\Achievement_Boss_MutanusTheDevourer" },
    { key = "trophy_hunter",     name = "Trophy Hunter",      desc = "Record 10 trophy kills.", icon = "Interface\\Icons\\INV_Misc_Head_Tiger_01" },

    { key = "trap_apprentice",   name = "Trap Apprentice",    desc = "Place 25 traps.", icon = "Interface\\Icons\\Spell_Frost_ChainsOfIce" },
    { key = "trapper",           name = "Trapper",            desc = "Place 100 traps.", icon = "Interface\\Icons\\Spell_Frost_FreezingBreath" },
    { key = "trap_master",       name = "Trap Master",        desc = "Place 250 traps.", icon = "Interface\\Icons\\Ability_Hunter_TrapLauncher" },
    { key = "trap_legend",       name = "Trap Legend",        desc = "Place 1,000 traps.", icon = "Interface\\Icons\\Ability_Hunter_LockAndLoad" },

    { key = "wild_chronicle",    name = "Wild Chronicle",     desc = "Record 25 creatures in your bestiary.", icon = "Interface\\Icons\\INV_Misc_Book_11" },
    { key = "beast_scholar",     name = "Beast Scholar",      desc = "Study 50 creatures with Beast Lore.", icon = "Interface\\Icons\\Ability_Physical_Taunt" },
}
local function IsAchievementUnlocked(key)
    EnsureDB()
    return type(HuntersLogDB.achievements[key]) == "table"
end

local function UnlockAchievement(key)
    if IsAchievementUnlocked(key) then return false end
    local ach
    for _, a in ipairs(ACHIEVEMENTS) do if a.key == key then ach = a; break end end
    if not ach then return false end
    HuntersLogDB.achievements[key] = { when = time(), name = ach.name, icon = ach.icon }
    AddJournalEntry("achievement", "Achievement earned: " .. ach.name .. " - " .. ach.desc)
    PrintHL("|cffffff00Achievement earned:|r " .. ach.name)
    ShowAchievementToast(ach)
    return true
end

local function CountTableEntries(tbl)
    local n = 0
    if type(tbl) == "table" then for _ in pairs(tbl) do n = n + 1 end end
    return n
end

local function CountBestiaryEntries()
    EnsureDB()
    local n = 0
    for _, b in pairs(HuntersLogDB.bestiary) do
        if type(b) == "table" and ((b.kills or 0) > 0 or b.tamed or b.beastLore) then
            n = n + 1
        end
    end
    return n
end

local function TotalTrapCasts()
    local total = 0
    EnsureDB()
    for _, tr in pairs(HuntersLogDB.traps) do
        if type(tr) == "table" then total = total + (tr.casts or 0) end
    end
    return total
end

local function CountBeastLoreEntries()
    EnsureDB()
    local n = 0
    for _, b in pairs(HuntersLogDB.bestiary) do
        if type(b) == "table" and (b.beastLore or 0) > 0 then n = n + 1 end
    end
    return n
end

local function SumPetSeconds(fieldName)
    EnsureDB()
    local total = 0
    for name, p in pairs(HuntersLogDB.pets) do
        if IsOwnedPetRecord(name, p) then total = total + (p[fieldName] or 0) end
    end
    return total
end

local function MaxPetValue(fieldName)
    EnsureDB()
    local best = 0
    for name, p in pairs(HuntersLogDB.pets) do
        if IsOwnedPetRecord(name, p) and (p[fieldName] or 0) > best then best = p[fieldName] or 0 end
    end
    return best
end

local function CheckAchievements()
    if not IS_HUNTER then return end
    local t = EnsureTotals()
    local totalKills = (t.playerKills or 0) + (t.petKills or 0)
    local totalAmmo = (t.arrowsFired or 0) + (t.bulletsFired or 0) + (t.thrownFired or 0)
    local totalDistance = (t.footDistance or 0) + (t.mountedDistance or 0)
    local r = EnsureRecords()

    if totalKills >= 1 then UnlockAchievement("first_kill") end
    if totalKills >= 100 then UnlockAchievement("hundred_stalker") end
    if totalKills >= 1000 then UnlockAchievement("thousand_claw") end
    if totalKills >= 10000 then UnlockAchievement("ten_thousand") end

    if t.petKills >= 1 then UnlockAchievement("first_blood") end
    if t.petKills >= 100 then UnlockAchievement("beastmaster") end
    if (t.petLastStandKills or 0) >= 1 then UnlockAchievement("last_stand") end
    if (t.closeCallKills or 0) >= 1 then UnlockAchievement("close_call") end
    if (t.closeCallKills or 0) >= 5 then UnlockAchievement("steel_nerves") end
    if (t.loneWolfKills or 0) >= 25 then UnlockAchievement("lone_wolf") end

    if UnitsToMiles(totalDistance) >= 10 then UnlockAchievement("long_hunt") end
    if UnitsToMiles(totalDistance) >= 100 then UnlockAchievement("cross_country") end
    if CountTableEntries(HuntersLogDB.zones) >= 30 then UnlockAchievement("globetrotter") end
    if SumPetSeconds("worldSeconds") >= 24 * 3600 then UnlockAchievement("wilderness") end
    if SumPetSeconds("townSeconds") >= 10 * 3600 then UnlockAchievement("cityfolk") end
    if SumPetSeconds("dungeonSeconds") >= 10 * 3600 then UnlockAchievement("dungeon_delver") end

    if totalAmmo >= 5000 then UnlockAchievement("arrowstorm") end
    if (t.arrowsFired or 0) >= 10000 then UnlockAchievement("quiver_emptier") end
    if totalAmmo >= 10000 then UnlockAchievement("munitioneer") end
    if (t.arrowsFired or 0) > 0 and (t.bulletsFired or 0) > 0 and (t.thrownFired or 0) > 0 then UnlockAchievement("all_three") end
    if (r.highestCrit.amount or 0) >= 5000 then UnlockAchievement("big_one") end
    if (r.bestPetCrit.amount or 0) >= 1000 then UnlockAchievement("pet_big_crit") end
    if (t.rangedHits or 0) >= 1000 then UnlockAchievement("sharp_eye") end

    if (t.eliteKills or 0) + (t.rareKills or 0) >= 1 then UnlockAchievement("big_game") end
    if (t.eliteKills or 0) + (t.rareKills or 0) >= 100 then UnlockAchievement("headhunter") end
    if (t.rareKills or 0) >= 10 then UnlockAchievement("rare_memory") end
    if (t.trophyKills or 0) >= 10 then UnlockAchievement("trophy_hunter") end
    if CountBestiaryEntries() >= 25 then UnlockAchievement("wild_chronicle") end
    if CountBeastLoreEntries() >= 50 then UnlockAchievement("beast_scholar") end

    local casts = TotalTrapCasts()
    if casts >= 25 then UnlockAchievement("trap_apprentice") end
    if casts >= 100 then UnlockAchievement("trapper") end
    if casts >= 250 then UnlockAchievement("trap_master") end
    if casts >= 1000 then UnlockAchievement("trap_legend") end

    if CountOwnedPets() >= 5 then UnlockAchievement("stable_keeper") end
    if CountOwnedPets() >= 25 then UnlockAchievement("beast_collector") end

    local now = time()
    for name, p in pairs(HuntersLogDB.pets) do
        if IsOwnedPetRecord(name, p) then
            if (p.totalSeconds or 0) >= 10 * 3600 then UnlockAchievement("pack_leader") end
            if (p.totalSeconds or 0) >= 100 * 3600 then UnlockAchievement("inseparable") end
            if (p.totalSeconds or 0) >= 500 * 3600 then UnlockAchievement("lifelong_friend") end
            if (p.dungeonSeconds or 0) >= 5 * 3600 then UnlockAchievement("dungeon_companion") end
            if (p.bestSurvivalStreak or 0) >= 100 then UnlockAchievement("loyal_hunter") end
            if (p.firstTamed or now) <= now - (30 * 24 * 3600) then UnlockAchievement("old_friend") end
        end
    end
end
-- ============================================================
-- PET TIME AND DISTANCE
-- ============================================================

activePet = nil
local lastPetContext = nil
local lastZoneTick = nil

local function BankPetTime()
    if not activePet then return end
    EnsureDB()
    local now = GetTime()
    local elapsed = now - (activePet.startTime or now)
    if elapsed > 0 then
        local p = MarkPetRecordOwned(activePet.name)
        p.totalSeconds = p.totalSeconds + elapsed
        local loc = lastPetContext or GetLocationKind()
        if loc == "dungeon" then p.dungeonSeconds = (p.dungeonSeconds or 0) + elapsed
        elseif loc == "town" then p.townSeconds = (p.townSeconds or 0) + elapsed
        else p.worldSeconds = (p.worldSeconds or 0) + elapsed end
        p.lastZone = GetZoneName()
        CheckPetLoyaltyMilestones(activePet.name, p)
    end
    activePet.startTime = now
    lastPetContext = GetLocationKind()
end

local function StartPet(name)
    if not name or name == "" then return end
    activePet = { name = name, startTime = GetTime() }
    lastPetContext = GetLocationKind()
    EnsureDB()
    local p = MarkPetRecordOwned(name)
    if not p.metAsOwnPetLogged then
        p.metAsOwnPetLogged = true
        AddJournalEntry("tame", "Met " .. name .. " in " .. GetZoneName())
        local b = EnsureBestiaryRecord(name)
        b.tamed = true
        b.tamedAt = b.tamedAt or time()
        b.tamedZone = b.tamedZone or GetZoneName()
    end
    if ApplyPetTitleOverride then ApplyPetTitleOverride() end
end

local function StopPet()
    BankPetTime()
    activePet = nil
    lastPetContext = nil
end

local function CheckHunterPet()
    if not IS_HUNTER then return end
    if UnitExists("pet") then
        local name = UnitName("pet")
        if name and name ~= "Unknown" then
            if not activePet or activePet.name ~= name then
                StopPet()
                StartPet(name)
            end
            return
        end
    end
    if activePet then StopPet() end
end

local lastPos = nil -- { x, y, zone }
local function UpdateDistance()
    if not IS_HUNTER then return end
    local _, instType = IsInInstance()
    if instType ~= "none" then lastPos = nil; return end
    if WorldMapFrame and WorldMapFrame:IsShown() then return end

    local x, y = GetPlayerMapPosition("player")
    if not x or not y or (x == 0 and y == 0) then lastPos = nil; return end

    local zone = GetZoneName()
    if not lastPos or lastPos.zone ~= zone then
        lastPos = { x = x, y = y, zone = zone }
        return
    end

    local dx = x - lastPos.x
    local dy = y - lastPos.y
    local d = math.sqrt(dx * dx + dy * dy)

    if d > 0.05 then
        lastPos = { x = x, y = y, zone = zone }
        return
    end

    if d > 0 then
        local t = EnsureTotals()
        if IsMounted() then t.mountedDistance = t.mountedDistance + d else t.footDistance = t.footDistance + d end
        local z = EnsureZoneRecord(zone)
        z.distance = (z.distance or 0) + d
        if activePet then
            local p = EnsurePetRecord(activePet.name)
            p.distance = (p.distance or 0) + d
            p.zones[zone] = (p.zones[zone] or 0) + d
        end
    end
    lastPos.x = x
    lastPos.y = y
end

local function UpdateZoneTime(elapsed)
    if not IS_HUNTER or not elapsed or elapsed <= 0 then return end
    local zone = GetZoneName()
    local z = EnsureZoneRecord(zone)
    z.timeSeconds = (z.timeSeconds or 0) + elapsed
end

-- ============================================================
-- TARGET INFO, BESTIARY, TROPHIES
-- ============================================================

local mobInfoByGUID = {}

local function ExtractCreatureIDFromGUID(guid)
    if type(guid) ~= "string" then return nil end
    local g = string.gsub(guid, "^0x", "")
    -- 3.3.5 creature GUIDs commonly look like F130 + 6 hex digit creature entry + spawn bits.
    if string.sub(g, 1, 4) == "F130" and string.len(g) >= 10 then
        return tonumber(string.sub(g, 5, 10), 16)
    end
    return nil
end

-- Some humanoid NPCs, especially Defias-style human mobs, do not render
-- correctly from SetCreature(entryID) in the 3.3.5 model frame. They need
-- their CreatureDisplayInfo ID instead. The addon learns creature IDs from
-- GUIDs automatically; this table supplies known display IDs for problem mobs.
local CREATURE_DISPLAY_OVERRIDES = {
    [94]  = 2361, -- Defias Cutpurse
    [95]  = 4418, -- Defias Smuggler
    [116] = 2357, -- Defias Bandit
    [504] = 2331, -- Defias Trapper
    [589] = 2338, -- Defias Pillager
    [590] = 2340, -- Defias Looter
}

local CREATURE_DISPLAY_NAME_OVERRIDES = {
    ["defias cutpurse"] = 2361,
    ["defias smuggler"] = 4418,
    ["defias bandit"] = 2357,
    ["defias trapper"] = 2331,
    ["defias pillager"] = 2338,
    ["defias looter"] = 2340,
}

-- Extra model candidates for mobs that are known to be annoying in the old
-- 3.3.5 model widget. These are not all automatically correct on every
-- private server, so the field card can now cycle them and save the one that
-- looks right. This gives us a future-proof path for custom/changed mobs too.
local CREATURE_DISPLAY_CANDIDATES = {
    [94]  = { 2361, 2360, 2359, 2362 }, -- Defias Cutpurse
    [95]  = { 4418, 2356, 2360, 2359 }, -- Defias Smuggler
    [116] = { 2357, 2356, 2358, 2360 }, -- Defias Bandit
    [504] = { 2331, 2332, 2333, 2334 }, -- Defias Trapper
    [589] = { 2338, 2337, 2339, 2340, 2357, 2360 }, -- Defias Pillager
    [590] = { 2340, 2339, 2338, 2341 }, -- Defias Looter
}

local CREATURE_DISPLAY_NAME_CANDIDATES = {
    ["defias cutpurse"] = { 2361, 2360, 2359, 2362 },
    ["defias smuggler"] = { 4418, 2356, 2360, 2359 },
    ["defias bandit"] = { 2357, 2356, 2358, 2360 },
    ["defias trapper"] = { 2331, 2332, 2333, 2334 },
    ["defias pillager"] = { 2338, 2337, 2339, 2340, 2357, 2360 },
    ["defias looter"] = { 2340, 2339, 2338, 2341 },
}

local function AddUniqueNumber(list, used, value)
    value = tonumber(value)
    if value and value > 0 and not used[value] then
        used[value] = true
        table.insert(list, value)
    end
end

local function AddCandidateTable(list, used, source)
    if type(source) ~= "table" then return end
    for _, v in ipairs(source) do AddUniqueNumber(list, used, v) end
end

local function GetDisplayIDForCreature(creatureID, name)
    local id = creatureID and CREATURE_DISPLAY_OVERRIDES[tonumber(creatureID)] or nil
    if id then return id end
    if name then return CREATURE_DISPLAY_NAME_OVERRIDES[string.lower(name)] end
    return nil
end

local function GetDisplayCandidatesForCreature(creatureID, name, bestiaryRecord)
    local out, used = {}, {}
    if type(bestiaryRecord) == "table" then
        -- Manual/player-saved display IDs always win. Old auto-filled IDs remain
        -- candidates, but are not trusted as the only answer.
        AddUniqueNumber(out, used, bestiaryRecord.manualDisplayID)
        AddUniqueNumber(out, used, bestiaryRecord.displayID)
    end
    AddUniqueNumber(out, used, GetDisplayIDForCreature(creatureID, name))
    if creatureID then AddCandidateTable(out, used, CREATURE_DISPLAY_CANDIDATES[tonumber(creatureID)]) end
    if name then AddCandidateTable(out, used, CREATURE_DISPLAY_NAME_CANDIDATES[string.lower(name)]) end
    return out
end

local function CaptureUnitInfo(unit)
    if not UnitExists(unit) then return nil end
    local guid = UnitGUID(unit)
    local name = UnitName(unit)
    if not guid or not name then return nil end
    local info = mobInfoByGUID[guid] or {}
    info.name = name
    info.level = UnitLevel(unit)
    info.classification = UnitClassification(unit)
    info.creatureType = UnitCreatureType(unit)
    info.creatureID = ExtractCreatureIDFromGUID(guid) or info.creatureID
    info.displayID = GetDisplayIDForCreature(info.creatureID, name) or info.displayID
    info.zone = GetZoneName()
    info.when = GetTime()
    if UnitIsPlayer(unit) then info.isPlayer = true end
    mobInfoByGUID[guid] = info

    if not info.isPlayer and name then
        local b = EnsureBestiaryRecord(name)
        b.lastSeen = time()
        b.lastSeenZone = info.zone
        b.level = info.level or b.level
        b.classification = info.classification or b.classification
        b.creatureType = info.creatureType or b.creatureType
        b.creatureID = info.creatureID or b.creatureID
        b.displayID = info.displayID or GetDisplayIDForCreature(b.creatureID, name) or b.displayID
        if info.creatureType == "Beast" then b.isBeast = true end
        if info.classification == "rare" or info.classification == "rareelite" then b.rare = true end
        if info.classification == "elite" or info.classification == "rareelite" or info.classification == "worldboss" then b.elite = true end
    end
    return info
end

local function GetMobInfo(guid, name)
    if guid and UnitGUID("target") == guid then return CaptureUnitInfo("target") end
    if guid and UnitExists("mouseover") and UnitGUID("mouseover") == guid then return CaptureUnitInfo("mouseover") end
    local info = guid and mobInfoByGUID[guid]
    if not info and name then info = { name = name, zone = GetZoneName() } end
    return info
end

local function RecordBestiarySeen(name, info)
    if not name then return end
    local b = EnsureBestiaryRecord(name)
    -- Do not count combat-log hits as "seen". The Bestiary now displays kills only,
    -- while this function simply keeps creature metadata fresh for lore/tame/trophy info.
    b.lastSeen = time()
    b.lastSeenZone = GetZoneName()
    if info then
        b.level = info.level or b.level
        b.classification = info.classification or b.classification
        b.creatureType = info.creatureType or b.creatureType
        b.creatureID = info.creatureID or b.creatureID
        b.displayID = info.displayID or GetDisplayIDForCreature(b.creatureID, name) or b.displayID
        if info.creatureType == "Beast" then b.isBeast = true end
        if info.classification == "rare" or info.classification == "rareelite" then b.rare = true end
        if info.classification == "elite" or info.classification == "rareelite" or info.classification == "worldboss" then b.elite = true end
    end
end

local function RecordBestiaryKill(name, who, info)
    if not name then return end
    local b = EnsureBestiaryRecord(name)
    b.kills = (b.kills or 0) + 1
    b.lastKilled = time()
    b.lastSeen = time()
    b.lastSeenZone = GetZoneName()
    if who == "pet" then b.petKills = (b.petKills or 0) + 1 else b.playerKills = (b.playerKills or 0) + 1 end
    if info then
        b.level = info.level or b.level
        b.classification = info.classification or b.classification
        b.creatureType = info.creatureType or b.creatureType
        b.creatureID = info.creatureID or b.creatureID
        b.displayID = info.displayID or GetDisplayIDForCreature(b.creatureID, name) or b.displayID
        if info.creatureType == "Beast" then b.isBeast = true end
        if info.classification == "rare" or info.classification == "rareelite" then b.rare = true end
        if info.classification == "elite" or info.classification == "rareelite" or info.classification == "worldboss" then b.elite = true end
    end
end

local function IsTrophyClassification(classification)
    return classification == "elite" or classification == "rare" or classification == "rareelite" or classification == "worldboss"
end

local function RecordTrophyKill(dstName, who, petName, info)
    if not dstName then return end
    local classification = info and info.classification
    if not IsTrophyClassification(classification) then return end

    local t = EnsureTotals()
    if classification == "rare" or classification == "rareelite" then t.rareKills = (t.rareKills or 0) + 1 end
    if classification == "elite" or classification == "rareelite" or classification == "worldboss" then t.eliteKills = (t.eliteKills or 0) + 1 end
    t.trophyKills = (t.trophyKills or 0) + 1

    local zone = GetZoneName()
    local text
    if who == "pet" and petName then
        text = string.format("Trophy kill: %s helped bring down %s in %s.", petName, dstName, zone)
    else
        text = string.format("Trophy kill: defeated %s in %s.", dstName, zone)
    end
    AddJournalEntry("trophy", text)
    table.insert(HuntersLogDB.trophies, 1, { when = time(), name = dstName, zone = zone, who = who, pet = petName, classification = classification })
    while #HuntersLogDB.trophies > 100 do table.remove(HuntersLogDB.trophies) end
end

-- ============================================================
-- TRAP TRACKING
-- ============================================================

local HUNTER_TRAPS = {
    ["Freezing Trap"] = true,
    ["Frost Trap"] = true,
    ["Explosive Trap"] = true,
    ["Immolation Trap"] = true,
    ["Snake Trap"] = true,
    ["Freezing Trap Effect"] = true,
    ["Frost Trap Aura"] = true,
}

local function NormalizeTrapName(spellName)
    if not spellName then return nil end
    if HUNTER_TRAPS[spellName] then
        if spellName == "Freezing Trap Effect" then return "Freezing Trap" end
        if spellName == "Frost Trap Aura" then return "Frost Trap" end
        return spellName
    end
    if string.find(spellName, "Trap") then return spellName end
    return nil
end

local function RecordTrapCast(spellName)
    local trap = NormalizeTrapName(spellName)
    if not trap then return end
    local tr = EnsureTrapRecord(trap)
    tr.casts = (tr.casts or 0) + 1
    tr.lastUsed = time()
    tr.lastZone = GetZoneName()
    AddJournalEntry("trap", "Set " .. trap .. " in " .. GetZoneName())
end

local function RecordTrapAffected(spellName)
    local trap = NormalizeTrapName(spellName)
    if not trap then return end
    local tr = EnsureTrapRecord(trap)
    tr.affected = (tr.affected or 0) + 1
end

local function RecordTrapDamage(spellName, amount)
    local trap = NormalizeTrapName(spellName)
    if not trap then return end
    local tr = EnsureTrapRecord(trap)
    tr.damage = (tr.damage or 0) + (amount or 0)
end

local function RecordTrapKill(spellName, dstName)
    local trap = NormalizeTrapName(spellName)
    if not trap then return end
    local tr = EnsureTrapRecord(trap)
    tr.kills = (tr.kills or 0) + 1
    EnsureTotals().trapKills = EnsureTotals().trapKills + 1
    AddJournalEntry("trapkill", trap .. " finished off " .. SafeText(dstName, "an enemy") .. " in " .. GetZoneName())
end

-- ============================================================
-- COMBAT TRACKING
-- ============================================================

local fight = {
    active = false,
    startTime = 0,
    playerDamage = 0,
    petDamage = 0,
    petName = nil,
    target = nil,
}

local function StartFight()
    if fight.active then return end
    fight.active = true
    fight.startTime = GetTime()
    fight.playerDamage = 0
    fight.petDamage = 0
    fight.petName = activePet and activePet.name or nil
    fight.target = nil
end

local function EndFight()
    if not fight.active then return end
    local elapsed = GetTime() - fight.startTime
    if elapsed > 0 then
        local r = EnsureRecords()
        local totalDmg = fight.playerDamage + fight.petDamage
        local dps = totalDmg / elapsed
        if dps > (r.highestDPS.amount or 0) then
            r.highestDPS = { amount = dps, fightTime = elapsed, target = fight.target, when = time() }
        end
        if elapsed > (r.longestFight.seconds or 0) and totalDmg > 0 then
            r.longestFight = { seconds = elapsed, target = fight.target, when = time() }
        end
        if fight.petName and fight.petDamage > 0 then
            local p = EnsurePetRecord(fight.petName)
            p.fights = (p.fights or 0) + 1
            p.totalDamage = (p.totalDamage or 0) + fight.petDamage
            local petDps = fight.petDamage / elapsed
            if petDps > (p.bestDPS or 0) then p.bestDPS = petDps end
        end
    end
    fight.active = false
end

local lastDamageByGUID = {}
local lastDamageByName = {}
local creditedKillGUIDs = {}

local PET_LAST_STAND_LINES = {
    "%s fell defending you in %s.",
    "%s gave everything in %s and would not back down.",
    "%s collapsed at your side in %s. A hunter remembers.",
    "%s's last growl faded into the noise of battle in %s.",
}

local function PruneKillTracking()
    local now = GetTime()
    for guid, rec in pairs(lastDamageByGUID) do
        if not rec or (now - (rec.when or 0)) > KILL_TRACK_TTL then lastDamageByGUID[guid] = nil end
    end
    for name, rec in pairs(lastDamageByName) do
        if not rec or (now - (rec.when or 0)) > KILL_TRACK_TTL then lastDamageByName[name] = nil end
    end
    for guid, when in pairs(creditedKillGUIDs) do
        if (now - (when or 0)) > KILL_TRACK_TTL then creditedKillGUIDs[guid] = nil end
    end
end

local function TrackLastDamage(dstGUID, dstName, owner, spellName, trapName)
    if not owner then return end
    local rec = {
        who = owner,
        petName = activePet and activePet.name or UnitName("pet"),
        dstName = dstName,
        spellName = spellName,
        trapName = trapName,
        when = GetTime(),
    }
    if dstGUID then lastDamageByGUID[dstGUID] = rec end
    if dstName then lastDamageByName[string.lower(dstName)] = rec end
end

local function GetRecentDamageRecord(dstGUID, dstName)
    local rec = dstGUID and lastDamageByGUID[dstGUID] or nil
    if not rec and dstName then rec = lastDamageByName[string.lower(dstName)] end
    if rec and (GetTime() - (rec.when or 0)) <= PET_DAMAGE_KILL_WINDOW then return rec end
    return nil
end

local function UpdateFastestKill(dstName)
    if fight.active then
        local elapsed = GetTime() - fight.startTime
        local r = EnsureRecords()
        if elapsed > 0 and ((r.fastestKill.seconds or 0) == 0 or elapsed < r.fastestKill.seconds) then
            r.fastestKill = { seconds = elapsed, target = dstName, when = time() }
        end
    end
end

local function AddPetLastStandJournal()
    local petName = activePet and activePet.name or UnitName("pet") or "Your pet"
    local zone = GetZoneName()
    local line = string.format(PET_LAST_STAND_LINES[math.random(#PET_LAST_STAND_LINES)], petName, zone)
    AddJournalEntry("petdeath", line)
    if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cffff6666" .. line .. "|r") end

    -- One optional memorial screenshot per pet, local only. This mirrors the
    -- feel of a journal snapshot without spamming screenshots every death.
    EnsureDB()
    local p = MarkPetRecordOwned(petName)
    if HuntersLogDB.settings.petMemorialScreenshots and not p.memorialScreenshotTaken and Screenshot then
        p.memorialScreenshotTaken = time()
        AddJournalEntry("memorial", "Memorial screenshot taken for " .. petName .. " in " .. zone .. ".")
        Screenshot()
    end
end

local function CreditKillOnce(dstGUID, dstName, who, petName, rec)
    if not who then return false end
    local killKey = dstGUID or ("noguid:" .. SafeText(dstName, "unknown") .. ":" .. tostring(math.floor(GetTime() * 10)))
    if creditedKillGUIDs[killKey] then return false end
    creditedKillGUIDs[killKey] = GetTime()

    local t = EnsureTotals()
    local zone = EnsureZoneRecord(GetZoneName())
    zone.kills = (zone.kills or 0) + 1

    local info = GetMobInfo(dstGUID, dstName)
    RecordBestiaryKill(dstName, who, info)

    if who == "pet" then
        local name = activePet and activePet.name or (UnitExists("pet") and UnitName("pet")) or petName
        if not name then return false end
        t.petKills = t.petKills + 1
        zone.petKills = (zone.petKills or 0) + 1
        if name then
            local p = MarkPetRecordOwned(name)
            p.kills = (p.kills or 0) + 1
            p.survivalKills = (p.survivalKills or 0) + 1
            if p.survivalKills > (p.bestSurvivalStreak or 0) then p.bestSurvivalStreak = p.survivalKills end
            p.lastKillAt = time()
            p.lastZone = GetZoneName()
            zone.pets[name] = (zone.pets[name] or 0) + 1
            local pct = GetPetHealthPct()
            if pct and pct <= 0.20 then
                p.lowHealthKills = (p.lowHealthKills or 0) + 1
                t.petLastStandKills = (t.petLastStandKills or 0) + 1
                AddJournalEntry("laststand", name .. " landed a killing blow while barely standing.")
            end
        end
        if MaybeEmote then MaybeEmote("kill", SafeText(dstName, "the target")) end
    elseif who == "player" then
        t.playerKills = t.playerKills + 1
        zone.playerKills = (zone.playerKills or 0) + 1
        if not UnitExists("pet") then t.loneWolfKills = (t.loneWolfKills or 0) + 1 end
    else
        return false
    end

    local pct = GetPetHealthPct()
    if pct and pct <= 0.10 then
        t.closeCallKills = (t.closeCallKills or 0) + 1
        AddJournalEntry("closecall", "Close call: won against " .. SafeText(dstName, "an enemy") .. " while your pet was badly wounded.")
    end

    if rec and rec.trapName then RecordTrapKill(rec.trapName, dstName) end
    RecordTrophyKill(dstName, who, petName, info)
    UpdateFastestKill(dstName)
    CheckAchievements()
    return true
end

local function HandleCombatLog(...)
    local _, subevent, srcGUID, srcName, srcFlags, dstGUID, dstName = ...
    if not subevent then return end

    local playerGUID = UnitGUID("player")
    local petGUID = UnitGUID("pet")
    local isPlayer = IsMyPlayerCombatSource(srcGUID, srcName, srcFlags)
    local isPet = IsMyPetCombatSource(srcGUID, srcName, srcFlags)

    if dstGUID and UnitGUID("target") == dstGUID then CaptureUnitInfo("target") end

    -- Deaths often have no useful source GUID, so handle UNIT_DIED before source filtering.
    if subevent == "UNIT_DIED" then
        if dstGUID == playerGUID then
            local t = EnsureTotals()
            t.playerDeaths = t.playerDeaths + 1
            EnsureZoneRecord(GetZoneName()).deaths = EnsureZoneRecord(GetZoneName()).deaths + 1
            AddJournalEntry("death", "Died in " .. GetZoneName())
            return
        elseif dstGUID == petGUID then
            local t = EnsureTotals()
            t.petDeaths = t.petDeaths + 1
            local z = EnsureZoneRecord(GetZoneName())
            z.petDeaths = (z.petDeaths or 0) + 1
            if activePet then
                local p = EnsurePetRecord(activePet.name)
                p.deaths = (p.deaths or 0) + 1
                p.lastDeathAt = time()
                p.survivalKills = 0
            end
            AddPetLastStandJournal()
            return
        end
        local rec = GetRecentDamageRecord(dstGUID, dstName)
        if rec then
            CreditKillOnce(dstGUID or (dstName and ("name:" .. string.lower(dstName))), dstName or rec.dstName, rec.who, rec.petName, rec)
        end
        if dstGUID then lastDamageByGUID[dstGUID] = nil end
        if dstName then lastDamageByName[string.lower(dstName)] = nil end
        PruneKillTracking()
        return
    end

    if subevent == "SPELL_CAST_SUCCESS" and isPlayer then
        local spellName = select(10, ...)
        if spellName == "Beast Lore" then
            local info = CaptureUnitInfo("target")
            local name = dstName or (info and info.name) or UnitName("target")
            if name then
                local b = EnsureBestiaryRecord(name)
                b.beastLore = (b.beastLore or 0) + 1
                b.lastBeastLore = time()
                RecordBestiarySeen(name, info)
                AddJournalEntry("beastlore", "Studied " .. name .. " with Beast Lore in " .. GetZoneName())
            end
        else
            RecordTrapCast(spellName)
        end
    end

    if subevent == "SPELL_AURA_APPLIED" and isPlayer then
        local spellName = select(10, ...)
        RecordTrapAffected(spellName)
    end

    if not isPlayer and not isPet then return end

    local amount, isCrit, spellName
    if subevent == "SWING_DAMAGE" then
        amount = select(9, ...)
        isCrit = select(15, ...)
    elseif subevent == "RANGE_DAMAGE" or subevent == "SPELL_DAMAGE" or subevent == "SPELL_PERIODIC_DAMAGE" then
        spellName = select(10, ...)
        amount = select(12, ...)
        isCrit = select(18, ...)
    elseif subevent == "RANGE_MISSED" then
        if isPlayer then EnsureTotals().rangedMisses = EnsureTotals().rangedMisses + 1 end
    end

    local trapName = NormalizeTrapName(spellName)
    if trapName and amount and amount > 0 then RecordTrapDamage(trapName, amount) end

    if amount and amount > 0 then
        local info = GetMobInfo(dstGUID, dstName)
        RecordBestiarySeen(dstName, info)
        if not fight.active then StartFight() end
        if not fight.target and dstName then fight.target = dstName end

        if isPlayer then
            TrackLastDamage(dstGUID, dstName, "player", spellName, trapName)
            fight.playerDamage = fight.playerDamage + amount
            local t = EnsureTotals()
            t.totalDamageDealt = t.totalDamageDealt + amount
            if subevent == "RANGE_DAMAGE" then
                t.rangedHits = t.rangedHits + 1
                if isCrit then t.rangedCrits = t.rangedCrits + 1 end
            end
            if isCrit then
                local r = EnsureRecords()
                if amount > (r.highestCrit.amount or 0) then
                    r.highestCrit = { amount = amount, spell = spellName or "Auto Shot", target = dstName, when = time(), zone = GetZoneName() }
                    AddJournalEntry("crit", string.format("Critical hit for %s on %s%s", FormatNumber(amount), SafeText(dstName, "target"), spellName and " (" .. spellName .. ")" or ""))
                end
                local z = EnsureZoneRecord(GetZoneName())
                if amount > (z.biggestCrit or 0) then
                    z.biggestCrit = amount
                    z.biggestCritTarget = dstName
                end
            end
        elseif isPet then
            TrackLastDamage(dstGUID, dstName, "pet", spellName, nil)
            fight.petDamage = fight.petDamage + amount
            EnsureTotals().totalPetDamage = EnsureTotals().totalPetDamage + amount
            if isCrit then
                local name = activePet and activePet.name or (UnitExists("pet") and UnitName("pet"))
                if name then
                    local p = MarkPetRecordOwned(name)
                    if amount > (p.bestCrit or 0) then p.bestCrit = amount end
                    local r = EnsureRecords()
                    if amount > (r.bestPetCrit.amount or 0) then
                        r.bestPetCrit = { amount = amount, pet = name, target = dstName, when = time() }
                    end
                end
            end
        end
    end

    if subevent == "PARTY_KILL" then
        -- On many 3.3.5/private-server builds, PARTY_KILL is credited to the
        -- player even when the pet dealt the actual finishing blow. Prefer the
        -- recent last-damage owner, then fall back to source GUID/flags.
        local rec = GetRecentDamageRecord(dstGUID, dstName)
        if rec then
            CreditKillOnce(dstGUID or (dstName and ("name:" .. string.lower(dstName))), dstName or rec.dstName, rec.who, rec.petName, rec)
        elseif isPet then
            CreditKillOnce(dstGUID, dstName, "pet", activePet and activePet.name or (UnitExists("pet") and UnitName("pet")), nil)
        elseif isPlayer then
            CreditKillOnce(dstGUID, dstName, "player", nil, nil)
        end
        PruneKillTracking()
    end
end

-- ============================================================
-- AMMO TRACKING
-- ============================================================

local function ClassifyAmmoFromWeapon()
    local link = GetInventoryItemLink("player", 18)
    if not link then return "arrow" end
    local _, _, _, _, _, _, subType = GetItemInfo(link)
    if subType == "Bows" or subType == "Crossbows" then return "arrow"
    elseif subType == "Guns" then return "bullet"
    elseif subType == "Thrown" then return "thrown" end
    return "arrow"
end

local function CountAmmoShot()
    if not IS_HUNTER then return end
    local kind = ClassifyAmmoFromWeapon()
    local t = EnsureTotals()
    if kind == "arrow" then t.arrowsFired = t.arrowsFired + 1
    elseif kind == "bullet" then t.bulletsFired = t.bulletsFired + 1
    elseif kind == "thrown" then t.thrownFired = t.thrownFired + 1 end
    CheckAchievements()
end

-- ============================================================
-- PET FLAVOR EMOTES
-- ============================================================

local PET_EMOTES = {
    combatStart = {
        "%s growls and bares teeth at %s.",
        "%s tenses, ready to leap at %s.",
        "%s circles %s warily.",
        "%s lets out a low warning at %s.",
    },
    kill = {
        "%s stands over the fallen %s, panting.",
        "%s sniffs at the still form of %s.",
        "%s claims its kill - %s lies defeated.",
        "%s shakes off the fight with %s.",
    },
    lowHealth = {
        "%s whimpers, hurt but still fighting.",
        "%s stumbles, wounded but still loyal.",
        "%s grits its teeth and presses on.",
    },
    ambientTown = {
        "%s pads quietly through %s, nose twitching at every shop door.",
        "%s watches the town crowd with bright, curious eyes.",
        "%s gives a soft huff, unimpressed by civilized comforts in %s.",
        "%s settles for a moment, content to rest where you rest.",
    },
    ambientWorld = {
        "%s sniffs the wind in %s and seems to choose the next trail before you do.",
        "%s trots ahead, then looks back to make sure you are following.",
        "%s watches the horizon, alert for movement beyond the grass.",
        "%s bumps your hand, then returns to watching the wilds.",
    },
    ambientDungeon = {
        "%s lowers its body and moves carefully through %s.",
        "%s lets out a quiet warning growl. Something in %s smells wrong.",
        "%s keeps close, ears sharp in the dark halls of %s.",
        "%s stares into the shadows, waiting for your signal.",
    },
    loyalty = {
        "%s leans against you for a moment. The bond feels stronger.",
        "%s looks up at you with complete trust.",
        "%s stays close, not because it must, but because it chooses to.",
    },
}

local PERSONALITY_EMOTES = {
    ["Bloodthirsty"] = {
        "%s looks far too pleased with itself after all the hunting in %s.",
        "%s licks its chops and searches %s for the next fight.",
    },
    ["Survivor"] = {
        "%s moves carefully through %s, every scar remembered.",
        "%s watches danger before danger notices you.",
    },
    ["Dungeon Beast"] = {
        "%s watches the tunnel ahead. This one has learned what waits in the dark.",
        "%s seems more comfortable in %s than any beast should be.",
    },
    ["Town Lounger"] = {
        "%s looks comfortable enough to claim a spot by the inn fire.",
        "%s gives %s the patient stare of a beast waiting for you to finish shopping.",
    },
    ["Wanderer"] = {
        "%s studies the road through %s like an old map.",
        "%s keeps walking before you even give the command.",
    },
    ["Loyal Guardian"] = {
        "%s stays close enough to throw itself between you and trouble.",
        "%s watches your back with grim patience.",
    },
}

function MaybeEmote(category, ...)
    if not IS_HUNTER then return end
    EnsureDB()
    if not HuntersLogDB.settings.emoteEnabled then return end
    if not activePet then return end
    local now = GetTime()
    if (now - lastPetEmote) < PET_EMOTE_COOLDOWN then return end

    local pool = PET_EMOTES[category]
    if category and string.find(category, "ambient") then
        local p = EnsurePetRecord(activePet.name)
        local personality = GetPetPersonality(activePet.name, p)
        if PERSONALITY_EMOTES[personality] and math.random() <= 0.45 then pool = PERSONALITY_EMOTES[personality] end
    end
    if not pool or #pool == 0 then return end
    local template = pool[math.random(#pool)]
    local msg = string.format(template, activePet.name, ...)
    DEFAULT_CHAT_FRAME:AddMessage("|cffff8800" .. msg .. "|r")
    lastPetEmote = now
end

local function GetAmbientPetCategory()
    local loc = GetLocationKind()
    if loc == "dungeon" then return "ambientDungeon" end
    if loc == "town" then return "ambientTown" end
    return "ambientWorld"
end

local function TryAmbientPetEmote()
    if not IS_HUNTER or not activePet then return end
    if not IsPetAlive() then return end
    local now = GetTime()
    if (now - lastPetEmote) < PET_EMOTE_COOLDOWN then return end
    if math.random() > PET_AMBIENT_CHANCE then return end
    MaybeEmote(GetAmbientPetCategory(), GetZoneName())
end

-- ============================================================
-- MOUSEOVER BEAST LORE TOOLTIP
-- ============================================================

local loreTooltipHooked = false

local function GetClassificationText(classification)
    if classification == "worldboss" then return "Boss" end
    if classification == "rareelite" then return "Rare Elite" end
    if classification == "rare" then return "Rare" end
    if classification == "elite" then return "Elite" end
    if classification == "trivial" then return "Trivial" end
    return "Normal"
end

local function FormatResistanceLine(unit)
    local names = { [2] = "Fire", [3] = "Nature", [4] = "Frost", [5] = "Shadow", [6] = "Arcane" }
    local parts = {}
    for school = 2, 6 do
        local base, total = UnitResistance(unit, school)
        local value = total or base or 0
        if value and value > 0 then table.insert(parts, names[school] .. " " .. value) end
    end
    if #parts == 0 then return "none known" end
    return table.concat(parts, ", ")
end

local function AddHunterLoreToTooltip(tooltip)
    if not IS_HUNTER then return end
    EnsureDB()
    if not HuntersLogDB.settings.loreTooltipEnabled then return end
    if not tooltip or not tooltip.GetUnit then return end

    if AddPetTitleToTooltip(tooltip) then return end

    local _, unit = tooltip:GetUnit()
    if not unit or not UnitExists(unit) then
        if UnitExists("mouseover") then unit = "mouseover" else return end
    end
    if UnitIsPlayer(unit) or not UnitCanAttack("player", unit) then return end

    local info = CaptureUnitInfo(unit)
    CaptureBestiaryModelSnapshot(unit)
    local name = UnitName(unit)
    if not name then return end
    local b = EnsureBestiaryRecord(name)

    tooltip:AddLine(" ")
    tooltip:AddLine("|cffffd200Hunter's Log Lore|r")

    local ctype = UnitCreatureType(unit) or b.creatureType or "Unknown"
    local family = UnitCreatureFamily and UnitCreatureFamily(unit) or nil
    if family and family ~= "" then
        tooltip:AddDoubleLine("Type", ctype .. " - " .. family, 0.8, 0.8, 0.8, 1, 1, 1)
    else
        tooltip:AddDoubleLine("Type", ctype, 0.8, 0.8, 0.8, 1, 1, 1)
    end

    local level = UnitLevel(unit) or b.level or "?"
    if level and level < 0 then level = "Boss" end
    tooltip:AddDoubleLine("Level", tostring(level) .. " " .. GetClassificationText(UnitClassification(unit)), 0.8, 0.8, 0.8, 1, 1, 1)

    local hp, hpMax = UnitHealth(unit) or 0, UnitHealthMax(unit) or 0
    if hpMax and hpMax > 0 then tooltip:AddDoubleLine("Health", FormatNumber(hp) .. " / " .. FormatNumber(hpMax), 0.8, 0.8, 0.8, 1, 1, 1) end

    local _, armor = UnitArmor(unit)
    if armor and armor > 0 then tooltip:AddDoubleLine("Armor", FormatNumber(armor), 0.8, 0.8, 0.8, 1, 1, 1) end

    local lowDmg, highDmg = UnitDamage(unit)
    local speed = UnitAttackSpeed(unit)
    if lowDmg and highDmg and highDmg > 0 then
        local dmgText = string.format("%d - %d", math.floor(lowDmg), math.floor(highDmg))
        if speed and speed > 0 then dmgText = dmgText .. string.format("  %.2fs", speed) end
        tooltip:AddDoubleLine("Damage", dmgText, 0.8, 0.8, 0.8, 1, 1, 1)
    end

    tooltip:AddDoubleLine("Resists", FormatResistanceLine(unit), 0.8, 0.8, 0.8, 1, 1, 1)

    local tameText = b.tamed and "Tamed" or (b.beastLore and "Lore studied" or "Unknown")
    tooltip:AddDoubleLine("Hunter Record", string.format("%s kills  |  %s pet", FormatNumber(b.kills or 0), FormatNumber(b.petKills or 0)), 0.8, 0.8, 0.8, 1, 0.9, 0.4)
    tooltip:AddDoubleLine("First Zone", SafeText(b.firstSeenZone, GetZoneName()), 0.8, 0.8, 0.8, 0.7, 0.9, 1)
    if ctype == "Beast" then tooltip:AddDoubleLine("Beast Notes", tameText, 0.8, 0.8, 0.8, 0.5, 1, 0.5) end
    tooltip:Show()
end

local function HookHunterLoreTooltip()
    if loreTooltipHooked then return end
    if GameTooltip and GameTooltip.HookScript then
        GameTooltip:HookScript("OnTooltipSetUnit", AddHunterLoreToTooltip)
        loreTooltipHooked = true
    end
end

-- ============================================================
-- MINIMAP BUTTON
-- ============================================================

local OUR_BUTTON_NAME = "HuntersLogButton"
local minimapBtn

local function CreateMinimapButton()
    if minimapBtn then return minimapBtn end
    local btn = CreateFrame("Button", OUR_BUTTON_NAME, Minimap)
    btn:SetSize(31, 31)
    btn:SetFrameStrata("MEDIUM")
    btn:SetFrameLevel(8)
    btn:RegisterForClicks("AnyUp")
    btn:RegisterForDrag("LeftButton")
    btn:SetMovable(true)

    local icon = btn:CreateTexture(nil, "BACKGROUND")
    icon:SetSize(20, 20)
    icon:SetPoint("CENTER", 0, 1)
    icon:SetTexture("Interface\\Icons\\Ability_Hunter_BeastTraining")
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    local border = btn:CreateTexture(nil, "OVERLAY")
    border:SetSize(54, 54)
    border:SetPoint("TOPLEFT", 0, 0)
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    btn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    local function UpdatePos()
        EnsureDB()
        local angle = math.rad(HuntersLogDB.minimap.angle or 220)
        local r = 80
        btn:ClearAllPoints()
        btn:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * r, math.sin(angle) * r)
    end
    UpdatePos()

    btn:SetScript("OnDragStart", function(self)
        self:LockHighlight()
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            cx, cy = cx / scale, cy / scale
            EnsureDB()
            HuntersLogDB.minimap.angle = math.deg(math.atan2(cy - my, cx - mx))
            UpdatePos()
        end)
    end)
    btn:SetScript("OnDragStop", function(self)
        self:UnlockHighlight()
        self:SetScript("OnUpdate", nil)
    end)

    btn:SetScript("OnClick", function(self, button)
        if button == "RightButton" then
            HuntersLogDB.settings.emoteEnabled = not HuntersLogDB.settings.emoteEnabled
            PrintHL("flavor emotes " .. (HuntersLogDB.settings.emoteEnabled and "enabled" or "disabled"))
        else
            HuntersLog_TogglePanel()
        end
    end)

    btn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("|cffffd200Hunter's Log|r")
        GameTooltip:AddLine("Pets: " .. CountOwnedPets() .. "  Beasts: " .. CountBestiaryEntries())
        local r = EnsureRecords()
        if r.highestCrit.amount > 0 then GameTooltip:AddLine("Highest crit: " .. FormatNumber(r.highestCrit.amount)) end
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("|cffffffffLeft-click:|r Open log")
        GameTooltip:AddLine("|cffffffffRight-click:|r Toggle pet emotes")
        GameTooltip:AddLine("|cffffffffDrag:|r Reposition")
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function() GameTooltip:Hide() end)

    minimapBtn = btn
    return btn
end

-- ============================================================
-- PANEL
-- ============================================================

local panel
local currentTab = "overview"
local CONTENT_W = 650

local function GetFavoritePetForZone(z)
    local best, n = nil, 0
    if type(z) == "table" and type(z.pets) == "table" then
        for pet, count in pairs(z.pets) do
            if count > n then best, n = pet, count end
        end
    end
    return best or "-"
end

local function GetDailyFact()
    EnsureDB()
    local t = EnsureTotals()
    local r = EnsureRecords()
    local facts = {}

    table.insert(facts, "Today: your pets have earned " .. FormatNumber(t.petKills or 0) .. " killing blows.")
    table.insert(facts, "Today: you have fired " .. FormatNumber((t.arrowsFired or 0) + (t.bulletsFired or 0) + (t.thrownFired or 0)) .. " shots across your career.")
    table.insert(facts, "Today: your best crit is " .. FormatNumber((r.highestCrit and r.highestCrit.amount) or 0) .. ".")
    table.insert(facts, "Today: your hunting grounds cover " .. CountTableEntries(HuntersLogDB.zones) .. " zones.")
    table.insert(facts, "Today: your bestiary remembers " .. CountBestiaryEntries() .. " creatures.")
    table.insert(facts, "Today: you have placed " .. FormatNumber(TotalTrapCasts()) .. " traps.")

    local pet, secs = nil, 0
    for n, pp in pairs(HuntersLogDB.pets) do
        if IsOwnedPetRecord(n, pp) and (pp.totalSeconds or 0) > secs then pet, secs = n, pp.totalSeconds or 0 end
    end
    if pet then
        local pp = EnsurePetRecord(pet)
        local title = GetPetTitle(pet, pp)
        table.insert(facts, "Today: " .. title .. " is your longest companion at " .. FormatHours(secs) .. ".")
        table.insert(facts, "Today: " .. pet .. " has survived a best streak of " .. FormatNumber(pp.bestSurvivalStreak or 0) .. " kills.")
    end

    local day = tonumber(date("%j")) or 1
    local year = tonumber(date("%Y")) or 0
    local idx = ((day + year) % #facts) + 1
    return facts[idx]
end


local bestiaryViewer

-- Runtime model snapshots learned from mouseover/tooltip units.
-- 3.3.5 Lua does not expose a reliable GetDisplayID() for an arbitrary NPC,
-- especially clothed humanoids. The next best fix is to keep a hidden
-- PlayerModel that was fed directly from SetUnit("mouseover") while the mob
-- was available. This works even if the Bestiary was closed at the time.
-- These snapshots are session-only; exact dressed humanoid appearances cannot
-- be serialized into SavedVariables without an external display/equipment DB.
local bestiaryModelSnapshots = {}
local bestiaryModelSnapshotOrder = {}
local BESTIARY_MODEL_SNAPSHOT_LIMIT = 80

local function BestiaryModelKey(name, creatureID)
    if creatureID then return "id:" .. tostring(creatureID) end
    return "name:" .. string.lower(SafeText(name, "unknown"))
end

local function SetupBestiaryModelDrag(model)
    if not model then return end
    model.rotation = model.rotation or 0
    model:EnableMouse(true)
    model:SetScript("OnMouseDown", function(self, button)
        if button == "LeftButton" then
            self.dragging = true
            self.lastX = GetCursorPosition()
        end
    end)
    model:SetScript("OnMouseUp", function(self)
        self.dragging = false
    end)
    model:SetScript("OnHide", function(self)
        self.dragging = false
    end)
    model:SetScript("OnUpdate", function(self)
        if self.dragging and self.SetRotation then
            local x = GetCursorPosition()
            local dx = (x or 0) - (self.lastX or x or 0)
            self.lastX = x
            self.rotation = (self.rotation or 0) + dx * 0.01
            self:SetRotation(self.rotation)
        end
    end)
end

local function PruneBestiaryModelSnapshots()
    while #bestiaryModelSnapshotOrder > BESTIARY_MODEL_SNAPSHOT_LIMIT do
        local oldKey = table.remove(bestiaryModelSnapshotOrder, 1)
        local old = oldKey and bestiaryModelSnapshots[oldKey]
        if old and old.frame then
            old.frame:Hide()
            old.frame:SetParent(UIParent)
        end
        bestiaryModelSnapshots[oldKey] = nil
    end
end

CaptureBestiaryModelSnapshot = function(unit)
    if not IS_HUNTER or not UnitExists(unit) or UnitIsPlayer(unit) then return nil end
    local name = UnitName(unit)
    if not name or name == "" then return nil end

    local info = CaptureUnitInfo(unit)
    local creatureID = info and info.creatureID or nil
    local key = BestiaryModelKey(name, creatureID)
    local isDead = UnitIsDead(unit) or UnitIsGhost(unit)

    local snap = bestiaryModelSnapshots[key]
    if snap and snap.live and isDead then
        -- Do not overwrite a good live model with a corpse/loot mouseover.
        return snap
    end

    if not snap then
        local frame = CreateFrame("PlayerModel", nil, UIParent)
        frame:SetSize(230, 250)
        frame:SetPoint("CENTER", UIParent, "CENTER", -5000, -5000)
        frame:SetFrameStrata("BACKGROUND")
        frame:Hide()
        if frame.SetCamDistanceScale then frame:SetCamDistanceScale(0.9) end
        if frame.SetPortraitZoom then frame:SetPortraitZoom(0.0) end
        SetupBestiaryModelDrag(frame)
        snap = { frame = frame, key = key }
        bestiaryModelSnapshots[key] = snap
        table.insert(bestiaryModelSnapshotOrder, key)
        PruneBestiaryModelSnapshots()
    end

    if snap.frame and snap.frame.SetUnit then
        snap.frame:SetUnit(unit)
        if snap.frame.SetRotation then snap.frame:SetRotation(0) end
        snap.frame.rotation = 0
    end
    snap.name = name
    snap.creatureID = creatureID
    snap.when = time()
    snap.zone = GetZoneName()
    snap.live = not isDead

    local b = EnsureBestiaryRecord(name)
    b.modelSnapshotLearnedAt = snap.when
    b.modelSnapshotZone = snap.zone
    b.modelSnapshotLive = snap.live
    if creatureID then b.creatureID = creatureID end
    return snap
end

local function GetBestiaryModelSnapshot(name, b)
    if not name then return nil end
    local creatureID = type(b) == "table" and b.creatureID or nil
    local snap = creatureID and bestiaryModelSnapshots[BestiaryModelKey(name, creatureID)] or nil
    if snap and snap.frame then return snap end
    snap = bestiaryModelSnapshots[BestiaryModelKey(name, nil)]
    if snap and snap.frame then return snap end
    return nil
end

local function DetachBestiaryViewerSnapshot(viewer)
    if not viewer or not viewer.snapshotFrame then return end
    viewer.snapshotFrame:Hide()
    viewer.snapshotFrame:ClearAllPoints()
    viewer.snapshotFrame:SetParent(UIParent)
    if viewer.snapshotFrame.SetFrameStrata then viewer.snapshotFrame:SetFrameStrata("BACKGROUND") end
    viewer.snapshotFrame:SetPoint("CENTER", UIParent, "CENTER", -5000, -5000)
    viewer.snapshotFrame = nil
end

local function AttachBestiaryViewerSnapshot(viewer, snap)
    if not viewer or not snap or not snap.frame or not viewer.model then return false end
    if viewer.snapshotFrame and viewer.snapshotFrame ~= snap.frame then
        DetachBestiaryViewerSnapshot(viewer)
    end
    if viewer.model.ClearModel then viewer.model:ClearModel() end
    viewer.model:Show()
    snap.frame:SetParent(viewer)
    if snap.frame.SetFrameStrata then snap.frame:SetFrameStrata(viewer:GetFrameStrata() or "DIALOG") end
    snap.frame:ClearAllPoints()
    snap.frame:SetPoint("TOPLEFT", viewer.model, "TOPLEFT", 0, 0)
    snap.frame:SetSize(viewer.model:GetWidth() or 230, viewer.model:GetHeight() or 250)
    snap.frame:SetFrameLevel((viewer.model:GetFrameLevel() or 1) + 2)
    snap.frame:Show()
    viewer.snapshotFrame = snap.frame
    viewer.currentDisplayID = nil
    viewer.modelSource = snap.live and "saved live mouseover" or "saved mouseover corpse"
    return true
end

local function CreateBestiaryViewer()
    if bestiaryViewer then return bestiaryViewer end
    local f = CreateFrame("Frame", "HuntersLogBestiaryViewer", UIParent)
    f:SetSize(590, 420)
    f:SetPoint("CENTER", UIParent, "CENTER", 0, 20)
    f:SetFrameStrata("DIALOG")
    f:SetMovable(true); f:EnableMouse(true)
    -- Do not register the whole viewer for dragging. The model area needs
    -- left-drag for rotation, so only the title bar moves the window.
    f:Hide()
    f:SetScript("OnHide", function(self) DetachBestiaryViewerSnapshot(self) end)
    f:SetBackdrop({
        bgFile = "Interface\\FrameGeneral\\UI-Background-Rock",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 32, edgeSize = 16,
        insets = { left = 4, right = 4, top = 4, bottom = 4 }
    })
    f:SetBackdropColor(0.04, 0.04, 0.04, 0.97)
    f:SetBackdropBorderColor(0.9, 0.7, 0.25, 1)

    local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -4, -4)

    f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    f.title:SetPoint("TOPLEFT", 16, -14)
    f.title:SetPoint("RIGHT", close, "LEFT", -8, 0)
    f.title:SetJustifyH("LEFT")
    f.title:SetTextColor(1, 0.82, 0)
    f.title:SetText("Bestiary")

    f.dragBar = CreateFrame("Frame", nil, f)
    f.dragBar:SetPoint("TOPLEFT", f, "TOPLEFT", 8, -8)
    f.dragBar:SetPoint("TOPRIGHT", close, "LEFT", -4, 0)
    f.dragBar:SetHeight(32)
    f.dragBar:EnableMouse(true)
    f.dragBar:RegisterForDrag("LeftButton")
    f.dragBar:SetScript("OnDragStart", function() f:StartMoving() end)
    f.dragBar:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)

    f.model = CreateFrame("PlayerModel", nil, f)
    f.model:SetPoint("TOPLEFT", 18, -48)
    f.model:SetSize(230, 250)
    f.model:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    f.model:SetBackdropColor(0, 0, 0, 0.65)
    f.model:SetBackdropBorderColor(0.35, 0.28, 0.15, 1)
    if f.model.SetCamDistanceScale then f.model:SetCamDistanceScale(0.9) end
    if f.model.SetPortraitZoom then f.model:SetPortraitZoom(0.0) end
    f.model:EnableMouse(true)
    f.model:SetFrameLevel(f:GetFrameLevel() + 4)

    f.model.rotation = 0
    f.model:SetScript("OnMouseDown", function(self, button)
        if button == "LeftButton" then
            self.dragging = true
            self.lastX = GetCursorPosition()
        end
    end)
    f.model:SetScript("OnMouseUp", function(self)
        self.dragging = false
    end)
    f.model:SetScript("OnHide", function(self)
        self.dragging = false
    end)
    f.model:SetScript("OnUpdate", function(self)
        if self.dragging and self.SetRotation then
            local x = GetCursorPosition()
            local dx = (x or 0) - (self.lastX or x or 0)
            self.lastX = x
            self.rotation = (self.rotation or 0) + dx * 0.01
            self:SetRotation(self.rotation)
        end
    end)

    f.hint = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    f.hint:SetPoint("TOPLEFT", f.model, "BOTTOMLEFT", 0, -6)
    f.hint:SetWidth(230)
    f.hint:SetJustifyH("CENTER")
    f.hint:SetTextColor(0.65, 0.65, 0.65)
    f.hint:SetText("Drag model to rotate")

    local function MakeModelButton(label, x, w)
        local btn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
        btn:SetSize(w or 58, 20)
        btn:SetPoint("TOPLEFT", f.model, "BOTTOMLEFT", x, -26)
        btn:SetText(label)
        return btn
    end
    f.prevModel = MakeModelButton("< Model", 0, 62)
    f.nextModel = MakeModelButton("Model >", 66, 62)
    f.saveModel = MakeModelButton("Save", 132, 48)
    f.targetModel = MakeModelButton("Target", 184, 52)

    f.info = {}
    for i = 1, 15 do
        local fs = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        fs:SetPoint("TOPLEFT", 270, -50 - (i - 1) * 21)
        fs:SetWidth(260)
        fs:SetJustifyH("LEFT")
        fs:SetWordWrap(false)
        fs:SetText("")
        f.info[i] = fs
    end

    bestiaryViewer = f
    return f
end

local function ViewerSetLine(viewer, idx, label, value, color)
    local fs = viewer.info[idx]
    if not fs then return end
    fs:SetText((color or "|cffffffff") .. label .. ":|r |cffaaaaaa" .. SafeText(value, "-") .. "|r")
end

local function UnitMatchesBestiaryName(unit, name)
    return UnitExists(unit) and UnitName(unit) == name
end

local function TrySetBestiaryDisplayModel(model, displayID)
    displayID = tonumber(displayID)
    if not model or not displayID then return false end

    -- On the 3.3.5 client, PlayerModel:SetCreature often expects a
    -- CreatureDisplayInfo ID, not the creature entry. This fixes the common
    -- white-robed Defias problem better than SetDisplayInfo on many private
    -- server clients.
    if model.SetCreature then
        model:SetCreature(displayID)
        return true
    end
    if model.SetDisplayInfo then
        model:SetDisplayInfo(displayID)
        return true
    end
    return false
end

local function ApplyBestiaryViewerModel(viewer, name, b, mode)
    if not viewer or not viewer.model or not name or type(b) ~= "table" then return end
    local model = viewer.model

    DetachBestiaryViewerSnapshot(viewer)
    if model.ClearModel then model:ClearModel() end
    model.rotation = 0
    if model.SetRotation then model:SetRotation(0) end

    local targetMatches = UnitMatchesBestiaryName("target", name)
    local mouseMatches = UnitMatchesBestiaryName("mouseover", name)
    local targetLive = targetMatches and not UnitIsDead("target") and not UnitIsGhost("target")
    local mouseLive = mouseMatches and not UnitIsDead("mouseover") and not UnitIsGhost("mouseover")
    local candidates = GetDisplayCandidatesForCreature(b.creatureID, name, b)

    if mode == "target" then
        if mouseMatches and model.SetUnit then
            model:SetUnit("mouseover")
            viewer.currentDisplayID = nil
            viewer.modelSource = mouseLive and "live mouseover" or "mouseover"
        elseif targetMatches and model.SetUnit then
            model:SetUnit("target")
            viewer.currentDisplayID = nil
            viewer.modelSource = targetLive and "live target" or "target"
        else
            viewer.modelSource = "target/mouseover not found"
        end
    else
        if mode == "next" then
            viewer.modelCandidateIndex = (viewer.modelCandidateIndex or 0) + 1
        elseif mode == "prev" then
            viewer.modelCandidateIndex = (viewer.modelCandidateIndex or 2) - 1
        elseif not viewer.modelCandidateIndex then
            viewer.modelCandidateIndex = 1
        end

        -- Default/auto mode prefers the live mouseover or target unit first. This is the
        -- most reliable way to render humanoids with the correct outfit and appearance.
        -- If the player already moused over this NPC while the Bestiary was closed,
        -- use the hidden saved model snapshot before falling back to raw IDs.
        if mode ~= "next" and mode ~= "prev" then
            local snap = GetBestiaryModelSnapshot(name, b)
            if snap and AttachBestiaryViewerSnapshot(viewer, snap) then
                -- modelSource is set by AttachBestiaryViewerSnapshot.
            elseif mouseLive and model.SetUnit then
                model:SetUnit("mouseover")
                viewer.currentDisplayID = nil
                viewer.modelSource = "live mouseover"
            elseif targetLive and model.SetUnit then
                model:SetUnit("target")
                viewer.currentDisplayID = nil
                viewer.modelSource = "live target"
            elseif mouseMatches and model.SetUnit then
                model:SetUnit("mouseover")
                viewer.currentDisplayID = nil
                viewer.modelSource = UnitIsDead("mouseover") and "mouseover corpse" or "mouseover"
            elseif targetMatches and model.SetUnit then
                model:SetUnit("target")
                viewer.currentDisplayID = nil
                viewer.modelSource = UnitIsDead("target") and "target corpse" or "target"
            elseif #candidates > 0 then
                if viewer.modelCandidateIndex < 1 then viewer.modelCandidateIndex = #candidates end
                if viewer.modelCandidateIndex > #candidates then viewer.modelCandidateIndex = 1 end
                local displayID = candidates[viewer.modelCandidateIndex]
                if TrySetBestiaryDisplayModel(model, displayID) then
                    viewer.currentDisplayID = displayID
                    viewer.modelSource = "model " .. tostring(viewer.modelCandidateIndex) .. "/" .. tostring(#candidates) .. " ID " .. tostring(displayID)
                end
            elseif b.creatureID and model.SetCreature then
                model:SetCreature(b.creatureID)
                viewer.currentDisplayID = nil
                viewer.modelSource = "creature entry " .. tostring(b.creatureID)
            elseif model.SetUnit and UnitExists("player") then
                model:SetUnit("player")
                viewer.currentDisplayID = nil
                viewer.modelSource = "fallback"
            else
                viewer.currentDisplayID = nil
                viewer.modelSource = nil
            end
        else
            if #candidates > 0 then
                if viewer.modelCandidateIndex < 1 then viewer.modelCandidateIndex = #candidates end
                if viewer.modelCandidateIndex > #candidates then viewer.modelCandidateIndex = 1 end
                local displayID = candidates[viewer.modelCandidateIndex]
                if TrySetBestiaryDisplayModel(model, displayID) then
                    viewer.currentDisplayID = displayID
                    viewer.modelSource = "model " .. tostring(viewer.modelCandidateIndex) .. "/" .. tostring(#candidates) .. " ID " .. tostring(displayID)
                end
            elseif mouseLive and model.SetUnit then
                model:SetUnit("mouseover")
                viewer.currentDisplayID = nil
                viewer.modelSource = "live mouseover"
            elseif targetLive and model.SetUnit then
                model:SetUnit("target")
                viewer.currentDisplayID = nil
                viewer.modelSource = "live target"
            elseif b.creatureID and model.SetCreature then
                model:SetCreature(b.creatureID)
                viewer.currentDisplayID = nil
                viewer.modelSource = "creature entry " .. tostring(b.creatureID)
            elseif model.SetUnit and UnitExists("player") then
                model:SetUnit("player")
                viewer.currentDisplayID = nil
                viewer.modelSource = "fallback"
            else
                viewer.currentDisplayID = nil
                viewer.modelSource = nil
            end
        end
    end

    if viewer.hint then
        if viewer.modelSource then
            viewer.hint:SetText("Drag model to rotate  |  " .. viewer.modelSource)
        else
            viewer.hint:SetText("Model appears after target/mouseover or saved display ID")
        end
    end
end

local function ShowBestiaryViewer(name)
    if not name then return end
    EnsureDB()
    local b = EnsureBestiaryRecord(name)
    b.displayID = b.displayID or GetDisplayIDForCreature(b.creatureID, name)
    local viewer = CreateBestiaryViewer()
    viewer.creatureName = name
    viewer.title:SetText("Hunter's Bestiary: " .. name)

    viewer.modelCandidateIndex = 1
    ApplyBestiaryViewerModel(viewer, name, b, nil)

    if viewer.prevModel then viewer.prevModel:SetScript("OnClick", function() ApplyBestiaryViewerModel(viewer, name, b, "prev") end) end
    if viewer.nextModel then viewer.nextModel:SetScript("OnClick", function() ApplyBestiaryViewerModel(viewer, name, b, "next") end) end
    if viewer.targetModel then viewer.targetModel:SetScript("OnClick", function() ApplyBestiaryViewerModel(viewer, name, b, "target") end) end
    if viewer.saveModel then
        viewer.saveModel:SetScript("OnClick", function()
            if viewer.currentDisplayID then
                b.manualDisplayID = viewer.currentDisplayID
                b.displayID = viewer.currentDisplayID
                PrintHL("saved model display ID " .. tostring(viewer.currentDisplayID) .. " for " .. name .. ".")
                ShowBestiaryViewer(name)
            else
                PrintHL("model save: use < Model / Model > until the model looks right, then Save.")
            end
        end)
    end

    for _, fs in ipairs(viewer.info) do fs:SetText("") end
    local level = b.level
    if level and level < 0 then level = "Boss" end
    ViewerSetLine(viewer, 1,  "Type", SafeText(b.creatureType, "Unknown"))
    ViewerSetLine(viewer, 2,  "Level", SafeText(level, "?"))
    ViewerSetLine(viewer, 3,  "Rank", GetClassificationText(b.classification))
    ViewerSetLine(viewer, 4,  "Kills", FormatNumber(b.kills or 0))
    ViewerSetLine(viewer, 5,  "Pet kills", FormatNumber(b.petKills or 0))
    ViewerSetLine(viewer, 6,  "Player kills", FormatNumber(b.playerKills or 0))
    ViewerSetLine(viewer, 7,  "First zone", SafeText(b.firstSeenZone, "Unknown"))
    ViewerSetLine(viewer, 8,  "Last zone", SafeText(b.lastSeenZone, "Unknown"))
    ViewerSetLine(viewer, 9,  "First seen", FormatTimestamp(b.firstSeen))
    ViewerSetLine(viewer, 10, "Last killed", b.lastKilled and FormatTimestamp(b.lastKilled) or "-")
    ViewerSetLine(viewer, 11, "Beast Lore", (b.beastLore and b.beastLore > 0) and (FormatNumber(b.beastLore) .. " studied") or "not studied")
    ViewerSetLine(viewer, 12, "Tamed", b.tamed and ("yes" .. (b.tamedZone and (" in " .. b.tamedZone) or "")) or "no")
    ViewerSetLine(viewer, 13, "Creature ID", b.creatureID or "unknown")
    ViewerSetLine(viewer, 14, "Display ID", (b.manualDisplayID or b.displayID or GetDisplayIDForCreature(b.creatureID, name) or "unknown") .. (b.manualDisplayID and " (saved)" or ""))
    ViewerSetLine(viewer, 15, "Notes", b.rare and "Rare" or (b.elite and "Elite" or "Common"), "|cffffd200")

    viewer:Show()
end

local function CreatePanel()
    if panel then return panel end
    EnsureDB()

    local p = CreateFrame("Frame", "HuntersLogPanel", UIParent)
    p:SetSize(720, 520)
    p:SetPoint("CENTER")
    p:SetFrameStrata("DIALOG")
    p:SetMovable(true); p:EnableMouse(true)
    p:RegisterForDrag("LeftButton")
    p:SetScript("OnDragStart", p.StartMoving)
    p:SetScript("OnDragStop", p.StopMovingOrSizing)
    p:Hide()

    p:SetBackdrop({
        bgFile = "Interface\\FrameGeneral\\UI-Background-Rock",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 32, edgeSize = 16,
        insets = { left = 4, right = 4, top = 4, bottom = 4 }
    })
    p:SetBackdropColor(0.06, 0.06, 0.06, 0.95)
    p:SetBackdropBorderColor(0.7, 0.6, 0.4, 1)

    local header = CreateFrame("Frame", nil, p)
    header:SetPoint("TOPLEFT", 4, -4)
    header:SetPoint("TOPRIGHT", -4, -4)
    header:SetHeight(72)
    local headerBg = header:CreateTexture(nil, "ARTWORK")
    headerBg:SetTexture("Interface\\Buttons\\WHITE8X8")
    headerBg:SetVertexColor(0.15, 0.10, 0.06, 0.95)
    headerBg:SetPoint("TOPLEFT", 4, -4)
    headerBg:SetPoint("BOTTOMRIGHT", -4, 4)

    local portrait = header:CreateTexture(nil, "OVERLAY")
    portrait:SetSize(44, 44)
    portrait:SetPoint("TOPLEFT", 8, -6)
    portrait:SetTexture("Interface\\Icons\\Ability_Hunter_BeastTraining")
    portrait:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    local title = header:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", portrait, "TOPRIGHT", 12, -4)
    title:SetText("Hunter's Log")
    title:SetTextColor(1, 0.82, 0)

    local sub = header:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -4)
    sub:SetText("|cffaaaaaaA hunter life chronicle for " .. (PLAYER_NAME or "you") .. "|r")

    local dailyFact = header:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    dailyFact:SetPoint("TOPLEFT", sub, "BOTTOMLEFT", 0, -4)
    dailyFact:SetPoint("RIGHT", header, "RIGHT", -20, 0)
    dailyFact:SetJustifyH("LEFT")
    dailyFact:SetTextColor(0.95, 0.78, 0.35)
    dailyFact:SetText("")
    p.dailyFact = dailyFact

    local close = CreateFrame("Button", nil, p, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -2, -2)

    local content = CreateFrame("ScrollFrame", "HuntersLogScroll", p, "UIPanelScrollFrameTemplate")
    content:SetPoint("TOPLEFT", 14, -86)
    content:SetPoint("BOTTOMRIGHT", -32, 40)

    local body = CreateFrame("Frame", nil, content)
    body:SetSize(CONTENT_W, 1)
    content:SetScrollChild(body)
    p.body = body
    p.lines = {}

    local tabs = {}
    local tabDefs = {
        { "overview", "Overview" }, { "pets", "Pets" }, { "records", "Records" }, { "grounds", "Grounds" },
        { "bestiary", "Beasts" }, { "traps", "Traps" }, { "achievements", "Achieve" }, { "journal", "Journal" },
    }
    local function MakeTab(id, label, idx)
        local tab = CreateFrame("Button", "HuntersLogTab" .. idx, p, "CharacterFrameTabButtonTemplate")
        tab:SetID(idx)
        tab:SetText(label)
        if idx == 1 then tab:SetPoint("TOPLEFT", p, "BOTTOMLEFT", 10, 6)
        else tab:SetPoint("LEFT", tabs[idx - 1], "RIGHT", -16, 0) end
        PanelTemplates_TabResize(tab, 0)
        tab:SetScript("OnClick", function()
            currentTab = id
            if panel then panel:Refresh() end
        end)
        tabs[idx] = tab
        return tab
    end
    for idx, def in ipairs(tabDefs) do MakeTab(def[1], def[2], idx) end

    local function NewRow()
        local row = CreateFrame("Frame", nil, body)
        row:SetSize(CONTENT_W, 18)
        row.cols = {}
        row.buttons = {}
        for c = 1, 7 do
            local fs = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            fs:SetJustifyH("LEFT")
            -- Critical: prevent wrapping. Long strings get clipped to the
            -- column width instead of wrapping into the next row's space.
            fs:SetWordWrap(false)
            fs:SetNonSpaceWrap(false)
            -- SetMaxLines exists on some clients; guard it
            if fs.SetMaxLines then fs:SetMaxLines(1) end
            row.cols[c] = fs

            local btn = CreateFrame("Button", nil, row)
            btn:SetFrameLevel(row:GetFrameLevel() + 2)
            btn:Hide()
            row.buttons[c] = btn
        end
        return row
    end

    function p:GetRow(idx)
        local row = self.lines[idx]
        if not row then row = NewRow(); self.lines[idx] = row end
        row:Show()
        for _, fs in ipairs(row.cols) do fs:SetText(""); fs:Hide() end
        if row.buttons then
            for _, btn in ipairs(row.buttons) do
                btn:Hide()
                btn:SetScript("OnClick", nil)
                btn:SetScript("OnEnter", nil)
                btn:SetScript("OnLeave", nil)
            end
        end
        return row
    end

    function p:HideAllRows()
        for _, row in ipairs(self.lines) do row:Hide() end
    end

    local function SetTextRow(row, idx, text, indent)
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", body, "TOPLEFT", indent or 0, -(idx - 1) * 18)
        local fs = row.cols[1]
        fs:ClearAllPoints()
        fs:SetPoint("LEFT", row, "LEFT", 0, 0)
        fs:SetWidth(CONTENT_W - (indent or 0))
        fs:SetJustifyH("LEFT")
        -- Full-width text rows (headers, descriptions) should NOT wrap into
        -- adjacent rows. If the text is genuinely too long, it gets clipped
        -- which is visually preferable to a row taking 2x the height.
        fs:SetWordWrap(false)
        fs:SetText(text or "")
        fs:Show()
        if row.buttons then for _, btn in ipairs(row.buttons) do btn:Hide() end end
    end

    local function SetColumnRow(row, idx, specs)
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", body, "TOPLEFT", 0, -(idx - 1) * 18)
        for c, spec in ipairs(specs) do
            local fs = row.cols[c]
            if fs then
                fs:ClearAllPoints()
                fs:SetPoint("LEFT", row, "LEFT", spec.x or 0, 0)
                fs:SetWidth(spec.w or 100)
                fs:SetJustifyH(spec.justify or "LEFT")
                fs:SetWordWrap(false)
                fs:SetText(spec.text or "")
                fs:Show()
                local btn = row.buttons and row.buttons[c]
                if btn then
                    if spec.onClick then
                        local clickFunc = spec.onClick
                        local enterFunc = spec.onEnter
                        local leaveFunc = spec.onLeave
                        local tooltipText = spec.tooltip or "Click to inspect"
                        btn:ClearAllPoints()
                        btn:SetPoint("LEFT", row, "LEFT", spec.x or 0, 0)
                        btn:SetSize(spec.w or 100, 18)
                        btn:SetScript("OnClick", clickFunc)
                        btn:SetScript("OnEnter", enterFunc or function()
                            GameTooltip:SetOwner(btn, "ANCHOR_RIGHT")
                            GameTooltip:AddLine(tooltipText)
                            GameTooltip:Show()
                        end)
                        btn:SetScript("OnLeave", leaveFunc or function() GameTooltip:Hide() end)
                        btn:Show()
                    else
                        btn:Hide()
                    end
                end
            end
        end
    end

    function p:Refresh()
        EnsureDB()
        BankPetTime()
        self:HideAllRows()
        if self.dailyFact then self.dailyFact:SetText(GetDailyFact()) end

        for idx, tab in ipairs(tabs) do
            if tabDefs[idx][1] == currentTab then PanelTemplates_SelectTab(tab) else PanelTemplates_DeselectTab(tab) end
        end

        local r = EnsureRecords()
        local t = EnsureTotals()
        local i = 0
        local function addText(text, indent) i = i + 1; SetTextRow(self:GetRow(i), i, text, indent) end
        local function addKV(label, value, valueColor)
            i = i + 1
            SetColumnRow(self:GetRow(i), i, {
                { x = 0,   w = 190, text = label, justify = "LEFT" },
                { x = 190, w = 440, text = (valueColor or "|cffffffff") .. (value or "") .. "|r", justify = "LEFT" },
            })
        end

        if currentTab == "overview" then
            addText("|cffffd200=== Career ===|r")
            addKV("Pets known:", tostring(CountOwnedPets()))
            addKV("Bestiary entries:", tostring(CountBestiaryEntries()))
            addKV("Player kills:", FormatNumber(t.playerKills))
            addKV("Pet kills:", FormatNumber(t.petKills))
            addKV("Trophy kills:", FormatNumber(t.trophyKills))
            addKV("Player deaths:", FormatNumber(t.playerDeaths))
            addKV("Pet deaths:", FormatNumber(t.petDeaths))
            addText("")
            addText("|cffffd200=== Active Pet ===|r")
            if activePet then
                local pp = EnsurePetRecord(activePet.name)
                local bond = GetPetBondInfo(pp)
                addKV("Name:", activePet.name)
                addKV("Bond:", bond .. "  |cffaaaaaa(" .. GetPetPersonality(activePet.name, pp) .. ")|r")
                addKV("Mood:", GetPetMood(activePet.name, pp))
                addKV("Time together:", FormatHours(pp.totalSeconds or 0))
            else
                addKV("Active pet:", "none", "|cff999999")
            end
            addText("")
            addText("|cffffd200=== Hunter Habits ===|r")
            local totalKills = (t.playerKills or 0) + (t.petKills or 0)
            local petShare = totalKills > 0 and ((t.petKills or 0) * 100 / totalKills) or 0
            local hitTotal = (t.rangedHits or 0) + (t.rangedMisses or 0)
            local critRate = (t.rangedHits or 0) > 0 and ((t.rangedCrits or 0) * 100 / (t.rangedHits or 0)) or 0
            local missRate = hitTotal > 0 and ((t.rangedMisses or 0) * 100 / hitTotal) or 0
            addKV("Pet kill share:", string.format("%.1f%%", petShare))
            addKV("Ranged crit rate:", string.format("%.1f%%", critRate))
            addKV("Ranged miss rate:", string.format("%.1f%%", missRate))
            addKV("Lone wolf kills:", FormatNumber(t.loneWolfKills))
            addText("")
            addText("|cffffd200=== Ammunition ===|r")
            addKV("Arrows fired:", FormatNumber(t.arrowsFired))
            addKV("Bullets fired:", FormatNumber(t.bulletsFired))
            addKV("Thrown:", FormatNumber(t.thrownFired))
            addText("")
            addText("|cffffd200=== Distance ===|r")
            addKV("On foot:", FormatDistance(t.footDistance))
            addKV("Mounted:", FormatDistance(t.mountedDistance))

        elseif currentTab == "pets" then
            addText("|cffffd200=== Stable Roster Memories ===|r")
            addText("|cff999999Active pet is marked with *. Detailed memory card is shown below the roster.|r")
            i = i + 1
            SetColumnRow(self:GetRow(i), i, {
                { x = 0,   w = 130, text = "|cff999999Name|r" },
                { x = 130, w = 80,  text = "|cff999999Bond|r" },
                { x = 215, w = 135, text = "|cff999999Persona|r" },
                { x = 355, w = 60,  text = "|cff999999Time|r" },
                { x = 420, w = 80,  text = "|cff999999Kills/Deaths|r" },
                { x = 510, w = 60,  text = "|cff999999Crit|r", justify = "RIGHT" },
                { x = 580, w = 50,  text = "|cff999999DPS|r", justify = "RIGHT" },
            })
            local list = {}
            for n, pp in pairs(HuntersLogDB.pets) do
                if IsOwnedPetRecord(n, pp) then table.insert(list, { n, pp }) end
            end
            table.sort(list, function(a, b) return (a[2].totalSeconds or 0) > (b[2].totalSeconds or 0) end)

            local selectedName, selectedPet
            if activePet and HuntersLogDB.pets[activePet.name] then
                selectedName, selectedPet = activePet.name, EnsurePetRecord(activePet.name)
            elseif list[1] then
                selectedName, selectedPet = list[1][1], list[1][2]
            end

            for _, e in ipairs(list) do
                local n, pp = e[1], e[2]
                local marker = (activePet and activePet.name == n) and "|cff00ff00*|r " or "  "
                local bond = GetPetBondInfo(pp)
                local rowName = marker .. "|cffffffff" .. ShortText(n, 15) .. "|r"
                i = i + 1
                SetColumnRow(self:GetRow(i), i, {
                    { x = 0,   w = 130, text = rowName },
                    { x = 130, w = 80,  text = "|cffffffff" .. ShortText(bond, 10) .. "|r" },
                    { x = 215, w = 135, text = "|cffaaaaaa" .. ShortText(GetPetPersonality(n, pp), 18) .. "|r" },
                    { x = 355, w = 60,  text = "|cffaaaaaa" .. FormatHours(pp.totalSeconds or 0) .. "|r" },
                    { x = 420, w = 80,  text = string.format("|cffffffff%d|r / |cffff8888%d|r", pp.kills or 0, pp.deaths or 0) },
                    { x = 510, w = 60,  text = "|cffffffff" .. FormatNumber(pp.bestCrit or 0) .. "|r", justify = "RIGHT" },
                    { x = 580, w = 50,  text = string.format("|cffffffff%.0f|r", pp.bestDPS or 0), justify = "RIGHT" },
                })
            end
            if #list == 0 then addText("|cff999999No pets recorded yet.|r") end

            addText("")
            addText("|cffffd200=== Selected Pet Memory Card ===|r")
            if selectedName and selectedPet then
                local bond = GetPetBondInfo(selectedPet)
                local titleText = GetPetTitle(selectedName, selectedPet)
                addKV("Title:", titleText)
                addKV("Bond:", bond .. "  |cffaaaaaa(" .. GetPetPersonality(selectedName, selectedPet) .. ")|r")
                addKV("Mood:", GetPetMood(selectedName, selectedPet))
                addKV("Favorite zone:", SafeText(selectedPet.lastZone, "Unknown"))
                addKV("First met:", FormatTimestamp(selectedPet.firstTamed))
                addKV("Time together:", FormatHours(selectedPet.totalSeconds or 0))
                addKV("World / Dungeon / Town:", FormatHours(selectedPet.worldSeconds or 0) .. " / " .. FormatHours(selectedPet.dungeonSeconds or 0) .. " / " .. FormatHours(selectedPet.townSeconds or 0))
                addKV("Kills / Deaths:", string.format("%d / %d", selectedPet.kills or 0, selectedPet.deaths or 0))
                addKV("Best crit / DPS:", FormatNumber(selectedPet.bestCrit or 0) .. " / " .. string.format("%.0f", selectedPet.bestDPS or 0))
                addKV("Best survival streak:", FormatNumber(selectedPet.bestSurvivalStreak or 0) .. " kills")
            else
                addText("|cff999999No pet selected yet. Summon a pet to begin its memory card.|r")
            end

        elseif currentTab == "records" then
            addText("|cffffd200=== Personal Records ===|r")
            if r.highestCrit.amount > 0 then
                addKV("Highest crit:", FormatNumber(r.highestCrit.amount))
                addText(string.format("    |cffaaaaaa%s on %s, %s|r", r.highestCrit.spell or "?", r.highestCrit.target or "?", FormatTimestamp(r.highestCrit.when)))
            else addKV("Highest crit:", "none yet", "|cff999999") end
            if r.bestPetCrit.amount > 0 then
                addKV("Best pet crit:", FormatNumber(r.bestPetCrit.amount) .. " |cffaaaaaaby " .. SafeText(r.bestPetCrit.pet, "pet") .. "|r")
            else addKV("Best pet crit:", "none yet", "|cff999999") end
            if r.highestDPS.amount > 0 then
                addKV("Highest DPS:", string.format("%.0f", r.highestDPS.amount) .. string.format(" |cffaaaaaaover %.1fs|r", r.highestDPS.fightTime or 0))
                addText(string.format("    |cffaaaaaavs %s, %s|r", r.highestDPS.target or "?", FormatTimestamp(r.highestDPS.when)))
            else addKV("Highest DPS:", "none yet", "|cff999999") end
            if r.fastestKill.seconds > 0 then addKV("Fastest kill:", string.format("%.1fs", r.fastestKill.seconds) .. " |cffaaaaaavs " .. (r.fastestKill.target or "?") .. "|r")
            else addKV("Fastest kill:", "none yet", "|cff999999") end
            if r.longestFight.seconds > 0 then addKV("Longest fight:", string.format("%.1fs", r.longestFight.seconds) .. " |cffaaaaaavs " .. (r.longestFight.target or "?") .. "|r") end
            addText("")
            addText("|cffffd200=== Recent Trophies ===|r")
            local shown = 0
            for _, tr in ipairs(HuntersLogDB.trophies) do
                shown = shown + 1
                addText(string.format("|cffaaaaaa%s|r  %s in %s", date("%m-%d", tr.when), SafeText(tr.name, "?"), SafeText(tr.zone, "?")))
                if shown >= 8 then break end
            end
            if shown == 0 then addText("|cff999999No trophy kills yet.|r") end

        elseif currentTab == "grounds" then
            addText("|cffffd200=== Hunting Grounds ===|r")
            i = i + 1
            SetColumnRow(self:GetRow(i), i, {
                { x = 0,   w = 170, text = "|cff999999Zone|r" },
                { x = 170, w = 70,  text = "|cff999999Kills|r", justify = "RIGHT" },
                { x = 250, w = 80,  text = "|cff999999Pet Kills|r", justify = "RIGHT" },
                { x = 340, w = 80,  text = "|cff999999Deaths|r", justify = "RIGHT" },
                { x = 430, w = 90,  text = "|cff999999Distance|r", justify = "RIGHT" },
                { x = 530, w = 110, text = "|cff999999Fav Pet|r" },
            })
            local list = {}
            for zn, zz in pairs(HuntersLogDB.zones) do if type(zz) == "table" then table.insert(list, { zn, zz }) end end
            table.sort(list, function(a, b) return ((a[2].kills or 0) + (a[2].distance or 0) * 100) > ((b[2].kills or 0) + (b[2].distance or 0) * 100) end)
            for _, e in ipairs(list) do
                local zn, zz = e[1], e[2]
                i = i + 1
                SetColumnRow(self:GetRow(i), i, {
                    { x = 0,   w = 170, text = "|cffffffff" .. zn .. "|r" },
                    { x = 170, w = 70,  text = FormatNumber(zz.kills or 0), justify = "RIGHT" },
                    { x = 250, w = 80,  text = FormatNumber(zz.petKills or 0), justify = "RIGHT" },
                    { x = 340, w = 80,  text = FormatNumber((zz.deaths or 0) + (zz.petDeaths or 0)), justify = "RIGHT" },
                    { x = 430, w = 90,  text = FormatDistance(zz.distance or 0), justify = "RIGHT" },
                    { x = 530, w = 110, text = "|cffaaaaaa" .. GetFavoritePetForZone(zz) .. "|r" },
                })
            end
            if #list == 0 then addText("|cff999999No hunting grounds recorded yet.|r") end

        elseif currentTab == "bestiary" then
            local filter = HuntersLogDB.settings.bestiaryFilter or "all"
            local sortMode = HuntersLogDB.settings.bestiarySort or "kills"

            local function isDisplayableBestiaryEntry(bb)
                return type(bb) == "table" and ((bb.kills or 0) > 0 or bb.tamed or bb.beastLore)
            end

            local function isRareOrElite(bb)
                return bb and (bb.rare or bb.elite or bb.classification == "rare" or bb.classification == "rareelite" or bb.classification == "elite" or bb.classification == "worldboss")
            end

            local function bestiaryFilterMatch(bb)
                if not isDisplayableBestiaryEntry(bb) then return false end
                local ctype = bb.creatureType or "Unknown"
                if filter == "beast" then return ctype == "Beast" end
                if filter == "humanoid" then return ctype == "Humanoid" end
                if filter == "rare" then return isRareOrElite(bb) end
                if filter == "tamed" then return bb.tamed or bb.beastLore end
                if filter == "other" then return ctype ~= "Beast" and ctype ~= "Humanoid" end
                return true
            end

            local counts = { total = 0, beast = 0, humanoid = 0, rare = 0, tamed = 0, other = 0 }
            local list = {}
            for bn, bb in pairs(HuntersLogDB.bestiary) do
                if isDisplayableBestiaryEntry(bb) then
                    counts.total = counts.total + 1
                    local ctype = bb.creatureType or "Unknown"
                    if ctype == "Beast" then counts.beast = counts.beast + 1
                    elseif ctype == "Humanoid" then counts.humanoid = counts.humanoid + 1
                    else counts.other = counts.other + 1 end
                    if isRareOrElite(bb) then counts.rare = counts.rare + 1 end
                    if bb.tamed or bb.beastLore then counts.tamed = counts.tamed + 1 end
                    if bestiaryFilterMatch(bb) then table.insert(list, { bn, bb }) end
                end
            end

            local function activeColor(id)
                return (filter == id) and "|cffffd200" or "|cffaaaaaa"
            end
            local function sortColor(id)
                return (sortMode == id) and "|cffffd200" or "|cffaaaaaa"
            end
            local function setFilter(id)
                HuntersLogDB.settings.bestiaryFilter = id
                if panel then panel:Refresh() end
            end
            local function setSort(id)
                HuntersLogDB.settings.bestiarySort = id
                if panel then panel:Refresh() end
            end

            addText("|cffffd200=== Bestiary ===|r")
            addText("|cff999999Click a creature name to open its Hunter's Log field card and 3D model.|r")

            i = i + 1
            SetColumnRow(self:GetRow(i), i, {
                { x = 0,   w = 50,  text = "|cff999999View:|r" },
                { x = 55,  w = 62,  text = activeColor("all") .. "All|r",       tooltip = "Show all recorded creatures", onClick = function() setFilter("all") end },
                { x = 120, w = 72,  text = activeColor("beast") .. "Beasts|r",  tooltip = "Show beasts only", onClick = function() setFilter("beast") end },
                { x = 195, w = 92,  text = activeColor("humanoid") .. "Humanoids|r", tooltip = "Show humanoids only", onClick = function() setFilter("humanoid") end },
                { x = 290, w = 95,  text = activeColor("rare") .. "Rare/Elite|r", tooltip = "Show rare, elite, and boss entries", onClick = function() setFilter("rare") end },
                { x = 390, w = 95,  text = activeColor("tamed") .. "Tamed/Lore|r", tooltip = "Show tamed or Beast Lore entries", onClick = function() setFilter("tamed") end },
                { x = 490, w = 70,  text = activeColor("other") .. "Other|r",   tooltip = "Show non-beast, non-humanoid entries", onClick = function() setFilter("other") end },
            })

            i = i + 1
            SetColumnRow(self:GetRow(i), i, {
                { x = 0,   w = 50,  text = "|cff999999Sort:|r" },
                { x = 55,  w = 62,  text = sortColor("kills") .. "Kills|r", tooltip = "Sort by total kills", onClick = function() setSort("kills") end },
                { x = 120, w = 62,  text = sortColor("name") .. "Name|r",  tooltip = "Sort by creature name", onClick = function() setSort("name") end },
                { x = 185, w = 62,  text = sortColor("type") .. "Type|r",  tooltip = "Group by creature type", onClick = function() setSort("type") end },
                { x = 250, w = 62,  text = sortColor("zone") .. "Zone|r",  tooltip = "Group by first zone", onClick = function() setSort("zone") end },
            })

            addText(string.format("|cffaaaaaaShowing %d of %d.|r  |cff777777Beasts %d  Humanoids %d  Rare/Elite %d  Tamed/Lore %d  Other %d|r",
                #list, counts.total, counts.beast, counts.humanoid, counts.rare, counts.tamed, counts.other))
            addText("")

            table.sort(list, function(a, b)
                local an, ab = a[1], a[2]
                local bn, bb = b[1], b[2]
                if sortMode == "name" then
                    return string.lower(an) < string.lower(bn)
                elseif sortMode == "type" then
                    local at, bt = SafeText(ab.creatureType, "Unknown"), SafeText(bb.creatureType, "Unknown")
                    if at == bt then return (ab.kills or 0) > (bb.kills or 0) end
                    return at < bt
                elseif sortMode == "zone" then
                    local az, bz = SafeText(ab.firstSeenZone, "Unknown"), SafeText(bb.firstSeenZone, "Unknown")
                    if az == bz then return (ab.kills or 0) > (bb.kills or 0) end
                    return az < bz
                end
                if (ab.kills or 0) == (bb.kills or 0) then return string.lower(an) < string.lower(bn) end
                return (ab.kills or 0) > (bb.kills or 0)
            end)

            i = i + 1
            SetColumnRow(self:GetRow(i), i, {
                { x = 0,   w = 190, text = "|cff999999Creature|r" },
                { x = 190, w = 95,  text = "|cff999999Type|r" },
                { x = 290, w = 55,  text = "|cff999999Kills|r", justify = "RIGHT" },
                { x = 350, w = 55,  text = "|cff999999Pet|r", justify = "RIGHT" },
                { x = 415, w = 90,  text = "|cff999999Flags|r" },
                { x = 510, w = 135, text = "|cff999999First Zone|r" },
            })

            local lastGroup = nil
            for _, e in ipairs(list) do
                local bn, bb = e[1], e[2]
                local group = nil
                if sortMode == "type" then group = SafeText(bb.creatureType, "Unknown") end
                if sortMode == "zone" then group = SafeText(bb.firstSeenZone, "Unknown") end
                if group and group ~= lastGroup then
                    lastGroup = group
                    i = i + 1
                    SetTextRow(self:GetRow(i), i, "|cff777777-- " .. group .. " --|r", 0)
                end

                local creatureName = bn
                local flags = {}
                if bb.tamed then table.insert(flags, "|cff00ff00Tamed|r") end
                if bb.beastLore then table.insert(flags, "|cff88ff88Lore|r") end
                if bb.rare then table.insert(flags, "|cffff66ffRare|r") end
                if bb.elite then table.insert(flags, "|cffffaa00Elite|r") end
                local flagText = (#flags > 0) and table.concat(flags, " ") or "|cff777777-|r"

                i = i + 1
                SetColumnRow(self:GetRow(i), i, {
                    { x = 0,   w = 190, text = "|cffffee99" .. ShortText(bn, 23) .. "|r", tooltip = "Click to inspect " .. bn, onClick = function() ShowBestiaryViewer(creatureName) end },
                    { x = 190, w = 95,  text = "|cffaaaaaa" .. ShortText(SafeText(bb.creatureType, "?"), 13) .. "|r" },
                    { x = 290, w = 55,  text = FormatNumber(bb.kills or 0), justify = "RIGHT" },
                    { x = 350, w = 55,  text = FormatNumber(bb.petKills or 0), justify = "RIGHT" },
                    { x = 415, w = 90,  text = flagText },
                    { x = 510, w = 135, text = "|cffaaaaaa" .. ShortText(SafeText(bb.firstSeenZone, "?"), 18) .. "|r" },
                })
            end
            if #list == 0 then addText("|cff999999No matching bestiary entries yet.|r") end

        elseif currentTab == "traps" then
            addText("|cffffd200=== Trap Tracker ===|r")
            addKV("Total traps placed:", FormatNumber(TotalTrapCasts()))
            addKV("Trap kills:", FormatNumber(t.trapKills))
            addText("")
            i = i + 1
            SetColumnRow(self:GetRow(i), i, {
                { x = 0,   w = 180, text = "|cff999999Trap|r" },
                { x = 190, w = 80,  text = "|cff999999Casts|r", justify = "RIGHT" },
                { x = 280, w = 80,  text = "|cff999999Affected|r", justify = "RIGHT" },
                { x = 370, w = 80,  text = "|cff999999Kills|r", justify = "RIGHT" },
                { x = 460, w = 90,  text = "|cff999999Damage|r", justify = "RIGHT" },
                { x = 560, w = 80,  text = "|cff999999Last Used|r" },
            })
            local list = {}
            for tn, tr in pairs(HuntersLogDB.traps) do if type(tr) == "table" then table.insert(list, { tn, tr }) end end
            table.sort(list, function(a, b) return (a[2].casts or 0) > (b[2].casts or 0) end)
            for _, e in ipairs(list) do
                local tn, tr = e[1], e[2]
                i = i + 1
                SetColumnRow(self:GetRow(i), i, {
                    { x = 0,   w = 180, text = "|cffffffff" .. tn .. "|r" },
                    { x = 190, w = 80,  text = FormatNumber(tr.casts or 0), justify = "RIGHT" },
                    { x = 280, w = 80,  text = FormatNumber(tr.affected or 0), justify = "RIGHT" },
                    { x = 370, w = 80,  text = FormatNumber(tr.kills or 0), justify = "RIGHT" },
                    { x = 460, w = 90,  text = FormatNumber(tr.damage or 0), justify = "RIGHT" },
                    { x = 560, w = 80,  text = tr.lastUsed and tr.lastUsed > 0 and date("%m-%d", tr.lastUsed) or "-" },
                })
            end
            if #list == 0 then addText("|cff999999No traps recorded yet.|r") end

        elseif currentTab == "achievements" then
            addText("|cffffd200=== Hunter Achievements ===|r")
            local unlocked = 0
            for _, a in ipairs(ACHIEVEMENTS) do if IsAchievementUnlocked(a.key) then unlocked = unlocked + 1 end end
            addKV("Progress:", unlocked .. " / " .. #ACHIEVEMENTS)
            addText("")
            for _, a in ipairs(ACHIEVEMENTS) do
                local got = HuntersLogDB.achievements[a.key]
                local mark = got and "|cff00ff00[Done]|r " or "|cff777777[----]|r "
                addText(mark .. "|cffffffff" .. a.name .. "|r - |cffaaaaaa" .. a.desc .. "|r")
                if got then addText("    |cff777777Earned " .. date("%Y-%m-%d", got.when) .. "|r") end
            end

        elseif currentTab == "journal" then
            addText("|cffffd200=== Journal ===|r")
            local count = 0
            for _, e in ipairs(HuntersLogDB.journal) do
                count = count + 1
                i = i + 1
                SetColumnRow(self:GetRow(i), i, {
                    { x = 0,   w = 90,  text = "|cff999999" .. date("%m-%d %H:%M", e.when) .. "|r" },
                    { x = 100, w = 540, text = e.text or "" },
                })
                if count >= 150 then addText("|cff666666(showing latest 150 entries)|r"); break end
            end
            if count == 0 then addText("|cff999999Your story has yet to be written.|r") end
        end

        body:SetHeight(math.max(1, i * 18 + 10))
    end

    p:HookScript("OnShow", function(self) self:Refresh() end)
    p:SetScript("OnKeyDown", function(self, key) if key == "ESCAPE" then self:Hide() end end)
    p:HookScript("OnShow", function(self) self:EnableKeyboard(true) end)
    p:HookScript("OnHide", function(self) self:EnableKeyboard(false) end)

    panel = p
    return p
end

function HuntersLog_TogglePanel()
    local p = CreatePanel()
    if p:IsShown() then p:Hide() else p:Show() end
end

local panelTicker = CreateFrame("Frame")
panelTicker.acc = 0
panelTicker:SetScript("OnUpdate", function(self, elapsed)
    if not panel or not panel:IsShown() then return end
    self.acc = self.acc + elapsed
    if self.acc >= 1 then self.acc = 0; EnsureDB(); panel:Refresh() end
end)

-- ============================================================
-- TICKER
-- ============================================================

local mainTicker = CreateFrame("Frame")
mainTicker.acc = 0
mainTicker.distAcc = 0
mainTicker.ambientAcc = 0
mainTicker.achAcc = 0
mainTicker:SetScript("OnUpdate", function(self, elapsed)
    self.acc = self.acc + elapsed
    self.distAcc = self.distAcc + elapsed
    self.ambientAcc = self.ambientAcc + elapsed
    self.achAcc = self.achAcc + elapsed

    if self.distAcc >= 0.5 then self.distAcc = 0; UpdateDistance() end
    if self.acc >= 5 then
        local tickElapsed = self.acc
        self.acc = 0
        EnsureDB()
        CheckHunterPet()
        BankPetTime()
        if ApplyPetTitleOverride then ApplyPetTitleOverride() end
        UpdateZoneTime(tickElapsed)
        if UnitExists("target") then CaptureUnitInfo("target") end
        if IsPetAlive() then
            local pct = GetPetHealthPct()
            if pct and pct <= 0.30 then MaybeEmote("lowHealth") end
        end
    end
    if self.ambientAcc >= PET_AMBIENT_CHECK_INTERVAL then self.ambientAcc = 0; TryAmbientPetEmote() end
    if self.achAcc >= 30 then self.achAcc = 0; CheckAchievements() end
end)

-- ============================================================
-- EVENTS
-- ============================================================

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("PLAYER_ENTERING_WORLD")
f:RegisterEvent("PLAYER_TARGET_CHANGED")
f:RegisterEvent("UPDATE_MOUSEOVER_UNIT")
f:RegisterEvent("UNIT_PET")
f:RegisterEvent("PLAYER_LOGOUT")
f:RegisterEvent("PLAYER_REGEN_ENABLED")
f:RegisterEvent("PLAYER_REGEN_DISABLED")
f:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
f:RegisterEvent("UNIT_RANGEDDAMAGE")
f:RegisterEvent("START_AUTOREPEAT_SPELL")
f:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")

f:SetScript("OnEvent", function(self, event, ...)
    EnsureDB()
    if event == "PLAYER_LOGIN" then
        if not IS_HUNTER then
            print("|cff999999Hunter's Log: not loaded (this character is not a hunter).|r")
            return
        end
        PLAYER_NAME = UnitName("player")
        EnsureTotals().sessionsPlayed = EnsureTotals().sessionsPlayed + 1
        CreateMinimapButton()
        HookHunterLoreTooltip()
        HookPetTitleOverride()
        CheckHunterPet()
        local cleanedPets = CleanForeignPetRecords()
        if cleanedPets > 0 then PrintHL("cleaned " .. cleanedPets .. " non-player pet/summon records from the stable roster.") end
        if ApplyPetTitleOverride then ApplyPetTitleOverride() end
        CheckAchievements()
        PrintHL("loaded. Click the minimap button or type |cffffff00/hl|r.")
        return
    end
    if not IS_HUNTER then return end

    if event == "PLAYER_ENTERING_WORLD" then
        CheckHunterPet()
        if ApplyPetTitleOverride then ApplyPetTitleOverride() end
        EnsureZoneRecord(GetZoneName())
        lastPetEmote = 0
        return
    end
    if event == "PLAYER_TARGET_CHANGED" then
        CaptureUnitInfo("target")
        return
    end
    if event == "UPDATE_MOUSEOVER_UNIT" then
        local info = CaptureUnitInfo("mouseover")
        local snap = CaptureBestiaryModelSnapshot("mouseover")
        if info and info.name then
            local b = EnsureBestiaryRecord(info.name)
            RecordBestiarySeen(info.name, info)
            b.lastMouseover = time()
            b.lastMouseoverZone = GetZoneName()
            if snap then
                b.modelSnapshotLearnedAt = snap.when
                b.modelSnapshotZone = snap.zone
                b.modelSnapshotLive = snap.live
            end
            if bestiaryViewer and bestiaryViewer:IsShown() and bestiaryViewer.creatureName == info.name then
                ShowBestiaryViewer(info.name)
            end
        end
        return
    end
    if event == "UNIT_PET" then
        local unit = ...
        if unit == "player" then CheckHunterPet(); if ApplyPetTitleOverride then ApplyPetTitleOverride() end end
        return
    end
    if event == "PLAYER_LOGOUT" then
        StopPet()
        EndFight()
        return
    end
    if event == "PLAYER_REGEN_DISABLED" then
        StartFight()
        MaybeEmote("combatStart", UnitName("target") or "an enemy")
        return
    end
    if event == "PLAYER_REGEN_ENABLED" then
        EndFight()
        return
    end
    if event == "UNIT_SPELLCAST_SUCCEEDED" then
        local unit, spell = ...
        if unit == "player" and spell == "Beast Lore" then
            local info = CaptureUnitInfo("target")
            local name = info and info.name or UnitName("target")
            if name then
                local b = EnsureBestiaryRecord(name)
                b.beastLore = (b.beastLore or 0) + 1
                b.lastBeastLore = time()
                RecordBestiarySeen(name, info)
                AddJournalEntry("beastlore", "Studied " .. name .. " with Beast Lore in " .. GetZoneName())
            end
        end
        return
    end
    if event == "COMBAT_LOG_EVENT_UNFILTERED" then
        HandleCombatLog(...)
        local subevent = select(2, ...)
        local srcGUID = select(3, ...)
        if subevent == "RANGE_DAMAGE" and srcGUID == UnitGUID("player") then CountAmmoShot() end
        return
    end
end)

-- ============================================================
-- RESUME + SLASH
-- ============================================================

local function GetMostUsedPet()
    local best, secs = nil, 0
    for n, p in pairs(HuntersLogDB.pets) do
        if IsOwnedPetRecord(n, p) and (p.totalSeconds or 0) > secs then best, secs = n, p.totalSeconds or 0 end
    end
    return best, secs
end

local function GetFavoriteHuntingGround()
    local best, score = nil, -1
    for z, rec in pairs(HuntersLogDB.zones) do
        if type(rec) == "table" then
            local s = (rec.kills or 0) + UnitsToMiles(rec.distance or 0)
            if s > score then best, score = z, s end
        end
    end
    return best
end

local function PrintResume()
    local t = EnsureTotals()
    local r = EnsureRecords()
    local pet, secs = GetMostUsedPet()
    local ground = GetFavoriteHuntingGround()
    local petText = pet and (pet .. " - " .. FormatHours(secs)) or "none"
    local bondText = ""
    if pet then
        local p = EnsurePetRecord(pet)
        local bond = GetPetBondInfo(p)
        bondText = " | Bond: " .. bond .. " | " .. GetPetPersonality(pet, p)
    end
    local line1 = string.format("%s, Hunter - %s kills, %s pet kills, %s ammo fired", PLAYER_NAME or UnitName("player") or "Hunter", FormatNumber((t.playerKills or 0) + (t.petKills or 0)), FormatNumber(t.petKills or 0), FormatNumber((t.arrowsFired or 0) + (t.bulletsFired or 0) + (t.thrownFired or 0)))
    local line2 = string.format("Longest companion: %s%s | Biggest crit: %s | Favorite ground: %s", petText, bondText, FormatNumber(r.highestCrit.amount or 0), ground or "unknown")
    DEFAULT_CHAT_FRAME:AddMessage("|cffff8800Hunter's Resume:|r " .. line1)
    DEFAULT_CHAT_FRAME:AddMessage("|cffff8800Hunter's Resume:|r " .. line2)
end

local function RefreshHuntersLogPanel()
    if panel and panel:IsShown() and panel.Refresh then panel:Refresh() end
end

local function ResetHuntersLogAchievements()
    HuntersLogDB.achievements = {}
    achievementToastQueue = {}
    if achievementToast then achievementToast:Hide(); achievementToast:SetAlpha(0) end
    AddJournalEntry("debug", "Debug reset: achievements cleared.")
    RefreshHuntersLogPanel()
    PrintHL("debug: achievements reset.")
end

local function ResetHuntersLogBestiary()
    HuntersLogDB.bestiary = {}
    mobInfoByGUID = {}
    AddJournalEntry("debug", "Debug reset: bestiary cleared.")
    RefreshHuntersLogPanel()
    PrintHL("debug: bestiary reset.")
end

local function CleanHuntersLogPetsCommand()
    local removed = CleanForeignPetRecords()
    AddJournalEntry("debug", "Debug clean: removed " .. removed .. " non-player pet/summon records.")
    RefreshHuntersLogPanel()
    PrintHL("debug: cleaned " .. removed .. " non-player pet/summon records.")
end


local function PrintBestiaryModelDebug()
    local unit = nil
    if UnitExists("mouseover") then unit = "mouseover" elseif UnitExists("target") then unit = "target" end
    if not unit then
        PrintHL("debug model: target or mouseover a creature first.")
        return
    end
    local info = CaptureUnitInfo(unit)
    if not info then
        PrintHL("debug model: could not read unit info.")
        return
    end
    local displayID = info.displayID or GetDisplayIDForCreature(info.creatureID, info.name)
    local dead = UnitIsDead(unit) and "dead/corpse" or "alive"
    PrintHL(string.format("debug model: %s | unit=%s | %s | creatureID=%s | displayID=%s | type=%s",
        SafeText(info.name, "?"), unit, dead, SafeText(info.creatureID, "unknown"), SafeText(displayID, "unknown"), SafeText(info.creatureType, "?")))
end

local function SetBestiaryDisplayDebug(displayID)
    displayID = tonumber(displayID)
    if not displayID then
        PrintHL("debug display: use /hl debug display 2338")
        return
    end
    local name = nil
    if bestiaryViewer and bestiaryViewer:IsShown() and bestiaryViewer.creatureName then name = bestiaryViewer.creatureName end
    if not name and UnitExists("mouseover") then name = UnitName("mouseover") end
    if not name and UnitExists("target") then name = UnitName("target") end
    if not name then
        PrintHL("debug display: open a bestiary card, target a creature, or mouseover a creature first.")
        return
    end
    local b = EnsureBestiaryRecord(name)
    b.manualDisplayID = displayID
    b.displayID = displayID
    PrintHL("debug display: saved display ID " .. displayID .. " for " .. name .. ".")
    if bestiaryViewer and bestiaryViewer:IsShown() and bestiaryViewer.creatureName == name then ShowBestiaryViewer(name) end
    RefreshHuntersLogPanel()
end

local function PrintDebugHelp()
    PrintHL("debug commands: /hl debug reset achievements, /hl debug reset bestiary, /hl debug reset both, /hl debug clean pets, /hl debug toast, /hl debug model, /hl debug display <id>.")
end

SLASH_HUNTERSLOG1 = "/hl"
SLASH_HUNTERSLOG2 = "/hunterslog"
SlashCmdList["HUNTERSLOG"] = function(msg)
    msg = msg and msg:lower() or ""
    EnsureDB()
    if not IS_HUNTER then
        print("|cff999999Hunter's Log only works on hunters.|r")
        return
    end
    if msg == "debug" or msg == "debug help" then
        PrintDebugHelp()
        return
    end
    if msg == "debug reset achievements" or msg == "reset achievements" then
        ResetHuntersLogAchievements()
        return
    end
    if msg == "debug reset bestiary" or msg == "reset bestiary" or msg == "debug reset beasts" or msg == "reset beasts" then
        ResetHuntersLogBestiary()
        return
    end
    if msg == "debug clean pets" or msg == "clean pets" or msg == "debug clean stable" then
        CleanHuntersLogPetsCommand()
        return
    end
    if msg == "debug reset both" then
        ResetHuntersLogAchievements()
        ResetHuntersLogBestiary()
        return
    end
    if msg == "debug toast" then
        ShowAchievementToast({ name = "Toast Test", desc = "Hunter's Log achievement popup position test.", icon = "Interface\\Icons\\Achievement_General" })
        return
    end
    if msg == "debug model" then
        PrintBestiaryModelDebug()
        return
    end
    local debugDisplayID = string.match(msg, "^debug display%s+(%d+)$")
    if debugDisplayID then
        SetBestiaryDisplayDebug(debugDisplayID)
        return
    end
    if msg == "emote" then
        HuntersLogDB.settings.emoteEnabled = not HuntersLogDB.settings.emoteEnabled
        PrintHL("flavor emotes " .. (HuntersLogDB.settings.emoteEnabled and "enabled" or "disabled"))
        return
    end
    if msg == "test" then
        lastPetEmote = 0
        MaybeEmote(GetAmbientPetCategory(), GetZoneName())
        return
    end
    if msg == "resume" then
        PrintResume()
        return
    end
    if msg == "lore" then
        HuntersLogDB.settings.loreTooltipEnabled = not HuntersLogDB.settings.loreTooltipEnabled
        PrintHL("mouseover lore tooltips " .. (HuntersLogDB.settings.loreTooltipEnabled and "enabled" or "disabled"))
        return
    end
    if msg == "titles" then
        HuntersLogDB.settings.petTitlesEnabled = not HuntersLogDB.settings.petTitlesEnabled
        if ApplyPetTitleOverride then ApplyPetTitleOverride() end
        PrintHL("pet UI titles " .. (HuntersLogDB.settings.petTitlesEnabled and "enabled" or "disabled"))
        return
    end
    if msg == "toasts" then
        HuntersLogDB.settings.achievementToasts = not HuntersLogDB.settings.achievementToasts
        PrintHL("achievement toasts " .. (HuntersLogDB.settings.achievementToasts and "enabled" or "disabled"))
        return
    end
    if msg == "memorial" then
        HuntersLogDB.settings.petMemorialScreenshots = not HuntersLogDB.settings.petMemorialScreenshots
        PrintHL("pet memorial screenshots " .. (HuntersLogDB.settings.petMemorialScreenshots and "enabled" or "disabled"))
        return
    end
    if msg == "help" then
        PrintHL("/hl opens the log. /hl emote, /hl lore, /hl titles, /hl toasts, /hl memorial, /hl test, /hl resume. Debug: /hl debug clean pets, /hl debug reset achievements, /hl debug reset bestiary, /hl debug toast, /hl debug model, /hl debug display <id>.")
        return
    end
    HuntersLog_TogglePanel()
end
